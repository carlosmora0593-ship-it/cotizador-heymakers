# -*- coding: utf-8 -*-
"""Tema Papel y azulejos por seccion en Makers Restaurant.

   El restaurante no tenia selector de tema: la paleta estaba escrita a mano
   en :root. Se agrega la misma pareja que el cotizador —Tecnologia y
   Papel— escribiendo las variables sobre el elemento raiz, que es lo que
   permite cambiarla sin recargar.

   Y las secciones con muchas tarjetas se abren con azulejos, como el
   Catalogo: Ajustes traia OCHO tarjetas apiladas."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones

R = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
t = R.read_text(encoding='utf-8')
hechos = []
def uno(v, n, et):
    global t
    c = t.count(v)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (et, c))
    t = t.replace(v, n, 1); hechos.append(et)

CSS_REST = secciones.CSS.replace("var(--surface)", "var(--surface)").replace("var(--line)", "var(--line)")

# ---------- estilos ----------
uno("""*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);""",
    CSS_REST + """
/* ---- azulejos ---- */
.lanzador{display:grid;grid-template-columns:repeat(auto-fill,minmax(146px,1fr));gap:14px;
  padding:22px;border-radius:var(--radio);background:var(--surface);
  border:1px solid var(--line);margin-bottom:18px}
.lzApp{display:flex;flex-direction:column;align-items:center;gap:9px;padding:16px 10px 14px;
  border:1px solid transparent;border-radius:16px;background:transparent;cursor:pointer;font:inherit;
  color:inherit;text-align:center;transition:background .16s,border-color .16s,transform .12s}
.lzApp:hover{background:var(--surface-2);border-color:var(--line);transform:translateY(-2px)}
.lzIco{position:relative;display:grid;place-items:center;width:60px;height:60px;border-radius:17px;
  background:color-mix(in oklab, var(--lzc) 20%, transparent);
  border:1px solid color-mix(in oklab, var(--lzc) 38%, transparent);color:var(--lzc)}
.lzIco svg{width:30px;height:30px}
.lzN{position:absolute;top:-7px;right:-9px;min-width:22px;height:22px;padding:0 6px;border-radius:999px;
  display:grid;place-items:center;font-style:normal;font-size:11px;font-weight:700;line-height:1;
  font-family:"IBM Plex Mono",monospace;background:var(--surface-2);color:var(--ink-2);
  border:1px solid var(--line)}
.lzEt{font-family:"Fredoka",system-ui,sans-serif;font-weight:500;font-size:13.5px;line-height:1.2}
.lzSub{font-size:10.5px;color:var(--ink-3);line-height:1.35;min-height:1.35em}
[data-theme="light"] .lzIco{background:color-mix(in oklab, var(--lzc) 13%, #fff);
  border-color:color-mix(in oklab, var(--lzc) 30%, #fff)}
[data-theme="light"] .lzN{background:#fff}
@media (max-width:560px){
  .lanzador{grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:8px;padding:14px}
  .lzIco{width:52px;height:52px;border-radius:15px}
  .lzIco svg{width:26px;height:26px}
  .lzEt{font-size:12px} .lzSub{display:none}
}
/* ---- selector de tema ---- */
.temaFila{display:flex;gap:10px;flex-wrap:wrap}
.temaCard{display:flex;align-items:center;gap:11px;border:1px solid var(--line);
  background:var(--surface-2);border-radius:14px;padding:12px 16px;cursor:pointer;font:inherit;color:inherit}
.temaCard[aria-pressed="true"]{border-color:var(--accent);box-shadow:0 0 0 2px color-mix(in oklab,var(--accent) 25%,transparent)}
.temaMuestra{display:flex;gap:3px}
.temaMuestra i{width:13px;height:26px;border-radius:4px;display:block}
.temaCard b{font-family:"Fredoka";font-weight:500;font-size:13.5px}

*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);""",
    "estilos")

# ---------- el motor y las paletas ----------
uno("""function appsPorDefecto(){""",
    secciones.JS + """
/* ---------- temas ---------- */
/* Las mismas dos paletas del cotizador. Papel es la clara: fondo crema en
   vez de blanco puro, que en pantalla grande cansa menos. Las cuatro series
   son las validadas con el script de dataviz. */
const TEMAS_REST = {
  tecno: {nombre:"Tecnología", muestra:["#0E1226","#D6127F","#22D3EE"], modo:"dark", vars:{
    "--bg":"#0E1226","--panel":"#171C35","--panel-2":"#1E2442","--linea":"#2F3660",
    "--ink":"#E8ECFB","--ink-2":"#A8B0D0","--ink-3":"#7C85A8",
    "--acento":"#D6127F","--cyan":"#22D3EE","--good":"#34D399","--warn":"#FBBF24","--mal":"#F472B6",
    "--sombra":"0 1px 2px rgba(0,0,0,.5), 0 14px 34px -18px rgba(0,0,0,.9)"}},
  papel: {nombre:"Papel", muestra:["#F6F4EF","#D2541F","#0E7C57"], modo:"light", vars:{
    "--bg":"#F6F4EF","--panel":"#FFFFFF","--panel-2":"#F1EEE7","--linea":"#E2DED4",
    "--ink":"#1C1A17","--ink-2":"#55514A","--ink-3":"#8A857B",
    "--acento":"#D2541F","--cyan":"#0680AB","--good":"#0E7C57","--warn":"#B26A00","--mal":"#C62828",
    "--sombra":"0 1px 2px rgba(28,26,23,.06), 0 12px 28px -20px rgba(28,26,23,.30)"}}
};
const LS_TEMA_REST = "makersrest_tema";
function temaRest(){ try{ return localStorage.getItem(LS_TEMA_REST) || "tecno"; }catch(e){ return "tecno"; } }
function aplicaTemaRest(){
  const k = temaRest(), t2 = TEMAS_REST[k] || TEMAS_REST.tecno;
  const raiz = document.documentElement;
  Object.keys(t2.vars).forEach(v=> raiz.style.setProperty(v, t2.vars[v]));
  raiz.setAttribute("data-theme", t2.modo);
  raiz.style.colorScheme = t2.modo;
}
function ponTemaRest(k){
  try{ localStorage.setItem(LS_TEMA_REST, k); }catch(e){}
  aplicaTemaRest(); pintaTemaRest();
}
function pintaTemaRest(){
  const w = $("#temaFila"); if(!w) return;
  const act = temaRest();
  w.innerHTML = Object.keys(TEMAS_REST).map(k=>{
    const t2 = TEMAS_REST[k];
    return '<button type="button" class="temaCard" data-temarest="'+k+'" aria-pressed="'+(act===k)+'">' +
      '<span class="temaMuestra">' + t2.muestra.map(c=>'<i style="background:'+c+'"></i>').join("") + '</span>' +
      '<b>'+esc(t2.nombre)+'</b></button>';
  }).join("");
}
document.addEventListener("click", e=>{
  const b = e.target.closest("[data-temarest]"); if(!b) return;
  ponTemaRest(b.dataset.temarest);
});

function appsPorDefecto(){""",
    "el motor y las paletas")

R.write_text(t, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
