# -*- coding: utf-8 -*-
"""Consumibles anclados a materiales, tecnicas y articulos.

   Se aplica sobre trabajo/cotizador.html, que es el cuerpo del index.html
   que ya estaba publicado en la computadora de Carlos."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import insumos

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# 1. estilos
uno(""".avisoStock{""", insumos.CSS + """
.avisoStock{""", "estilos")

# 2. semilla
uno(""" tecnicas:[
  {id:"t1",nombre:"DTF Textil",""",
    """ insumos:[
  {id:"i1",nombre:"Tinta DTF (blanco y color)",unidad:"ml",costo:0.9,existencia:0,minimo:0},
  {id:"i2",nombre:"Polvo termoadhesivo",unidad:"g",costo:0.28,existencia:0,minimo:0},
  {id:"i3",nombre:"Bolsa de celofán",unidad:"pza",costo:1.2,existencia:0,minimo:0},
  {id:"i4",nombre:"Hilo de bordado",unidad:"m",costo:0.05,existencia:0,minimo:0}
 ],
 /* 50 ml de tinta y 100 g de polvo por metro cuadrado IMPRESO, que son los
    promedios del oficio que ya usa la calculadora de costos. El polvo solo
    se pega donde hay tinta, por eso va por area impresa y no por comprada. */
 consumos:[
  {id:"c1",ancla:"servicio",anclaId:"sv1",insumoId:"i1",cant:50,por:"m2"},
  {id:"c2",ancla:"servicio",anclaId:"sv1",insumoId:"i2",cant:100,por:"m2"}
 ],
 tecnicas:[
  {id:"t1",nombre:"DTF Textil",""",
    "semilla de consumibles")

# 3. colecciones para cuentas viejas
uno("""function svcDe(id){ return (cat.servicios||[]).find(s=>s.id===id) || null; }""",
    """function svcDe(id){ return (cat.servicios||[]).find(s=>s.id===id) || null; }
/* Las cuentas que ya existian no traen estas colecciones. Se crean vacias:
   sembrar consumos en una cuenta vieja seria inventarle gastos que nadie
   capturo, y el primer pedido le descontaria material que no sabe que tiene. */
if(!Array.isArray(cat.insumos))  cat.insumos  = [];
if(!Array.isArray(cat.consumos)) cat.consumos = [];""",
    "colecciones para cuentas viejas")

# 4. el armado expone su servicio y su area
uno("""    armado.push({id:row.id, appId:row.appId||"", principal:!!row.principal, nombre:A.s.nombre, unidad:A.unidad,""",
    """    armado.push({id:row.id, appId:row.appId||"", principal:!!row.principal, nombre:A.s.nombre, unidad:A.unidad,
                 servicioId:row.servicioId, areaPiezasM2:A.areaPiezasM2, areaCompradaM2:A.areaCompradaM2,""",
    "el armado lleva su servicio y su área")

# 5. el motor
uno("""function svcDe(id){ return (cat.servicios||[]).find(s=>s.id===id) || null; }
/* Las cuentas que ya existian""",
    insumos.JS + """
function svcDe(id){ return (cat.servicios||[]).find(s=>s.id===id) || null; }
/* Las cuentas que ya existian""",
    "el motor de consumibles")

# 6. la interfaz
uno("""function renderResumen(){""", insumos.JS_UI + """
function renderResumen(){""", "la interfaz de consumibles")

# 7. el aviso en el resumen
uno("""          <div class="avisoStock" id="r_stock" hidden></div>""",
    """          <div class="avisoStock" id="r_stock" hidden></div>
          """ + insumos.AVISO, "el aviso en el resumen")

# 8. las tarjetas del catálogo
uno("""  <div class="card">
    <header><h2>Historial de cambios de precio</h2><button class="btn sm ghost" id="clearHist" style="margin-left:auto">Vaciar</button></header>""",
    insumos.CATALOGO + """  <div class="card">
    <header><h2>Historial de cambios de precio</h2><button class="btn sm ghost" id="clearHist" style="margin-left:auto">Vaciar</button></header>""",
    "las tarjetas del catálogo")

# 9. la tarjeta del inventario
uno("""  <div class="card">
    <header><h2>Lo que ya pediste</h2><span class="hint" id="ivSolResumen" style="margin-left:auto"></span></header>""",
    insumos.INVENTARIO + """  <div class="card">
    <header><h2>Lo que ya pediste</h2><span class="hint" id="ivSolResumen" style="margin-left:auto"></span></header>""",
    "la tarjeta del inventario")

# 10. pintar con el catálogo
uno("""  catqPintaPie();
  renderInventario();""",
    """  catqPintaPie();
  renderInsumos(); renderConsumos();
  renderInventario();""", "se pintan con el catálogo")

# 11. pintar con el inventario
uno("""function renderInvTaller(){""",
    """function renderInvTaller(){
  renderInvInsumos();""", "se pintan con el inventario")

# 12. el aviso sale junto al de existencia
uno("""function renderAvisoStock(){
  const w = $("#r_stock"); if(!w) return;""",
    """function renderAvisoStock(){
  /* calcDe, no calc: una cotizacion con varios articulos tiene un armado y
     unas aplicaciones por articulo, y calc() solo ve el que esta abierto. */
  try{ renderAvisoInsumos(calcDe(cot)); }catch(e){}
  const w = $("#r_stock"); if(!w) return;""",
    "el aviso sale con el de existencia")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
