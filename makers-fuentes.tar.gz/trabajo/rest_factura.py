# -*- coding: utf-8 -*-
"""Mete la facturacion al restaurante: tarjeta en Ajustes, tarjeta y
   azulejo en Ventas, la ventana de captura y la hoja para el contador."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import facturarest

RUTA = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno('''  <div class="card secOculta" data-set="folios">''',
    facturarest.HTML_SET + '''  <div class="card secOculta" data-set="folios">''',
    "la tarjeta de facturación en ajustes")

uno('''  <div class="card secOculta" data-ven="turnos">''',
    facturarest.HTML_VEN + '''  <div class="card secOculta" data-ven="turnos">''',
    "la tarjeta de facturas en ventas")

uno('''<div class="modal" id="modalMods" hidden>''',
    facturarest.HTML_MODAL + '''<div class="modal" id="modalMods" hidden>''',
    "la ventana de facturar")

# ---- azulejos ----
uno('''    {id:"folios", nombre:"Folios", sub:"cómo se numeran", color:"#B26A00",''',
    '''    {id:"fiscal", nombre:"Facturación", sub:"RFC, régimen y tu PAC", color:"#0E7C57",
     icono:'<path d="M4 4h16v13l-2.7-1.6L14.7 17 12 15.4 9.3 17 6.7 15.4 4 17Z"/><path d="M8 9h8M8 12h5"/>',
     card:'[data-set="fiscal"]', alAbrir:()=>renderSetFiscal()},
    {id:"folios", nombre:"Folios", sub:"cómo se numeran", color:"#B26A00",''',
    "el azulejo de facturación")

uno('''    {id:"cancel", nombre:"Cancelaciones", sub:"el dinero que no entró", color:"#C62828",''',
    '''    {id:"factura", nombre:"Facturas", sub:"cuando te piden factura", color:"#0E7C57",
     icono:'<path d="M4 4h16v13l-2.7-1.6L14.7 17 12 15.4 9.3 17 6.7 15.4 4 17Z"/><path d="M8 9h8M8 12h5"/>',
     card:'[data-ven="factura"]',
     cuenta:()=>porFacturar().length, alAbrir:()=>renderFacturas()},
    {id:"cancel", nombre:"Cancelaciones", sub:"el dinero que no entró", color:"#C62828",''',
    "el azulejo de facturas")

# ---- el codigo ----
uno('''/* ---------------- respaldo ---------------- */''',
    facturarest.JS.rstrip() + '''

/* ---------------- respaldo ---------------- */''',
    "el código de facturación")

uno('''  renderEstacion(); pintaNotaRespaldo();''',
    '''  renderSetFiscal();
  renderEstacion(); pintaNotaRespaldo();''',
    "pintar los datos fiscales al entrar a ajustes")

uno('''  renderCancelaciones();''',
    '''  renderCancelaciones();
  renderFacturas();''',
    "refrescar las facturas con las ventas")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
