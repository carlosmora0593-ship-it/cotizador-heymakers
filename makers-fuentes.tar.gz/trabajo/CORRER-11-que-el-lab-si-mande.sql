-- ============================================================
--  11 · QUE EL LAB SÍ MANDE (de verdad esta vez)
--  Correr después de los demás. Es seguro repetirlo.
-- ============================================================
--  EL BUG, en la sección 3 del archivo 08:
--
--    create or replace function public.protege_suscripcion() ...
--      if auth.role() = 'authenticated' then
--        new.plan := old.plan; new.estado := old.estado; ...
--
--  Y arriba, este comentario:
--
--    "las funciones de arriba son security definer y no corren como
--     'authenticated', así que pasan sin que haya que abrirle la mano
--     a nadie más."
--
--  Eso es FALSO, y es lo que tenía muerto al Lab.
--
--  SECURITY DEFINER cambia quién es el DUEÑO de la función
--  (current_user), pero auth.role() no lee eso: lee el claim del token
--  de la petición. Una función security definer llamada desde el
--  navegador por alguien con sesión sigue viendo auth.role() =
--  'authenticated', porque el token es el mismo para toda la petición.
--
--  Resultado: staff_cambia_plan hacía su UPDATE, el disparador se
--  despertaba, veía 'authenticated' y REGRESABA plan, estado, vence y
--  ciclo a como estaban. El update "funcionaba", la función contestaba
--  ok:true con los valores viejos, y hasta dejaba un renglón en la
--  bitácora diciendo que no cambió nada.
--
--  Por eso "no me deja reactivar suscripciones": sí la reactivaba, y el
--  disparador la desreactivaba medio milisegundo después.
--
--  EL ARREGLO: la puerta autorizada avisa que va pasando, con una
--  bandera que sólo existe mientras dura esa transacción. El disparador
--  la respeta. Para todo lo demás, el candado queda igual de cerrado:
--  el navegador sigue sin poder tocar la suscripción por su cuenta,
--  aunque su token diga 'authenticated'.
-- ============================================================


-- ---------- 1. El disparador, ahora sí ----------

create or replace function public.protege_suscripcion()
returns trigger language plpgsql as $$
begin
  --  La bandera la pone staff_cambia_plan con set_config(..., true), o
  --  sea LOCAL a la transacción: en cuanto termina, desaparece sola. No
  --  hay forma de dejarla prendida desde el navegador.
  if coalesce(current_setting('makers.cambio_autorizado', true), '') = 'si' then
    return new;
  end if;

  --  Todo lo demás que entre por el navegador con su propia sesión no
  --  toca la suscripción. Esto no cambió.
  if auth.role() = 'authenticated' then
    new.plan   := old.plan;
    new.estado := old.estado;
    new.vence  := old.vence;
    new.ciclo  := old.ciclo;
    new.mp_preapproval_id := old.mp_preapproval_id;
  end if;
  return new;
end $$;


-- ---------- 2. La puerta levanta la bandera al pasar ----------
--  Es la misma función del archivo 08 con dos renglones nuevos: uno que
--  prende la bandera antes del update y otro que la apaga después.

create or replace function public.staff_cambia_plan(
  p_cuenta    uuid,
  p_plan      text default null,     -- null = no lo toques
  p_vence     timestamptz default null,
  p_estado    text default null,
  p_ciclo     text default null,
  p_es_prueba boolean default null,
  p_motivo    text default null
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare antes public.cuentas%rowtype; despues public.cuentas%rowtype; mi_correo text;
begin
  if not public.es_staff() then
    raise exception 'Solo el equipo de Hey Makers puede cambiar un plan';
  end if;

  select * into antes from public.cuentas where id = p_cuenta;
  if not found then
    return jsonb_build_object('ok', false, 'motivo', 'Esa cuenta no existe.');
  end if;

  if p_plan is not null and p_plan not in ('ninguno','basico','maker','pro','prueba') then
    return jsonb_build_object('ok', false, 'motivo', 'Plan desconocido: ' || p_plan);
  end if;
  if p_estado is not null and p_estado not in ('activa','vencida','cancelada') then
    return jsonb_build_object('ok', false, 'motivo', 'Estado desconocido: ' || p_estado);
  end if;

  --  Aquí se avisa al disparador que este cambio viene de la puerta buena.
  perform set_config('makers.cambio_autorizado', 'si', true);

  update public.cuentas
     set plan      = coalesce(p_plan, plan),
         vence     = coalesce(p_vence, vence),
         estado    = coalesce(p_estado, estado),
         ciclo     = coalesce(p_ciclo, ciclo),
         es_prueba = coalesce(p_es_prueba, es_prueba)
   where id = p_cuenta
   returning * into despues;

  --  Y aquí se baja, para que lo que siga en esta misma transacción no
  --  herede el permiso.
  perform set_config('makers.cambio_autorizado', '', true);

  select u.email into mi_correo from auth.users u where u.id = auth.uid();

  insert into public.lab_bitacora (cuenta_id, quien, correo, que, antes, despues)
  values (p_cuenta, auth.uid(), mi_correo,
          coalesce(p_motivo, 'Cambio de suscripción desde Makers Lab'),
          jsonb_build_object('plan', antes.plan,   'estado', antes.estado,
                             'vence', antes.vence, 'ciclo', antes.ciclo, 'es_prueba', antes.es_prueba),
          jsonb_build_object('plan', despues.plan, 'estado', despues.estado,
                             'vence', despues.vence,'ciclo', despues.ciclo,'es_prueba', despues.es_prueba));

  --  Si el disparador volviera a estorbar, la función lo dice en vez de
  --  contestar ok:true con los valores viejos. Un "sí se pudo" falso es
  --  peor que un error.
  if p_plan   is not null and despues.plan   is distinct from p_plan   then
    return jsonb_build_object('ok', false, 'motivo',
      'El cambio no se guardó: algo lo está revirtiendo. Falta correr CORRER-11.');
  end if;
  if p_estado is not null and despues.estado is distinct from p_estado then
    return jsonb_build_object('ok', false, 'motivo',
      'El cambio no se guardó: algo lo está revirtiendo. Falta correr CORRER-11.');
  end if;

  return jsonb_build_object('ok', true, 'plan', despues.plan, 'estado', despues.estado,
                            'vence', despues.vence);
end $$;

grant execute on function public.staff_cambia_plan(uuid, text, timestamptz, text, text, boolean, text) to authenticated;


-- ---------- 3. Confirmación ----------
--  Esto solo mira; no cambia nada y no depende de quién lo corra.

select 'Disparador con la bandera' as que,
       case when pg_get_functiondef(p.oid) like '%makers.cambio_autorizado%'
            then 'sí' else 'NO — vuelve a correr este archivo' end as respuesta
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
 where n.nspname = 'public' and p.proname = 'protege_suscripcion'
union all
select 'Puerta que levanta la bandera',
       case when pg_get_functiondef(p.oid) like '%makers.cambio_autorizado%'
            then 'sí' else 'NO — vuelve a correr este archivo' end
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
 where n.nspname = 'public' and p.proname = 'staff_cambia_plan'
union all
select 'Gente en la tabla staff', count(*)::text from public.staff;
