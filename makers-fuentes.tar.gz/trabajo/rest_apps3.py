# -*- coding: utf-8 -*-
"""Pedidos por app, parte 3: el reporte, el ticket y los ajustes.

   La pregunta que este reporte contesta y que hoy ningun restaurante puede:
   de lo que vendiste hoy, cuanto fue tuyo, cuanto se quedaron las apps, y
   despues de la comision Y del costo del platillo, cuanto te quedo."""
import pathlib
R = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
t = R.read_text(encoding='utf-8')
hechos = []
def uno(v, n, et):
    global t
    c = t.count(v)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (et, c))
    t = t.replace(v, n, 1); hechos.append(et)

# tiles con la comision
uno("""  $("#venTiles").innerHTML =
    '<div class="tile destacada"><span class="et">Hoy</span><span class="v">' + mx(total) + '</span>' +
      '<span class="sub">' + hoy.length + ' cuenta(s)</span></div>' +
    '<div class="tile"><span class="et">Costo de hoy</span><span class="v">' + mx(costo) + '</span>' +
      '<span class="sub">' + (costo ? "de lo que capturaste" : "falta capturar costos") + '</span></div>' +
    '<div class="tile"><span class="et">Utilidad de hoy</span><span class="v">' + mx(total - costo) + '</span>' +
      '<span class="sub">' + (total ? Math.round((total-costo)/total*100) + "% del total" : "sin ventas") + '</span></div>' +
    '<div class="tile"><span class="et">Históricas</span><span class="v">' + todas.length + '</span>' +
      '<span class="sub">cuentas cerradas</span></div>';""",
    """  /* La comision va antes de la utilidad porque es un costo mas, solo que
     invisible: no llega en ninguna factura del pedido. */
  const comHoy = hoy.reduce((s,c)=> s + comisionDe(c), 0);
  const porApp = hoy.filter(c=>c.appId).reduce((s,c)=> s + num(c.total), 0);
  $("#venTiles").innerHTML =
    '<div class="tile destacada"><span class="et">Hoy</span><span class="v">' + mx(total) + '</span>' +
      '<span class="sub">' + hoy.length + ' cuenta(s)' +
        (porApp ? ' · ' + mx(porApp) + ' por app' : '') + '</span></div>' +
    '<div class="tile"><span class="et">Costo de hoy</span><span class="v">' + mx(costo) + '</span>' +
      '<span class="sub">' + (costo ? "de lo que capturaste" : "falta capturar costos") + '</span></div>' +
    '<div class="tile"><span class="et">Comisión de apps</span><span class="v">' + mx(comHoy) + '</span>' +
      '<span class="sub">' + (porApp ? Math.round(comHoy/porApp*100) + "% de lo vendido por app" : "sin pedidos de app") + '</span></div>' +
    '<div class="tile"><span class="et">Utilidad de hoy</span><span class="v">' + mx(total - costo - comHoy) + '</span>' +
      '<span class="sub">' + (total ? Math.round((total-costo-comHoy)/total*100) + "% del total, ya sin comisión" : "sin ventas") + '</span></div>';
  pintaPorCanal(hoy);""",
    "los tiles con la comisión")

uno("""function renderVentas(){""",
    """/* Mostrador contra apps, una linea por plataforma. El margen de la derecha
   es el real: ya le quito la comision Y el costo de los platillos. Es normal
   que una plataforma salga en rojo; de eso se trata verlo. */
function pintaPorCanal(lista){
  const w = $("#venCanal"); if(!w) return;
  const costoDe = c => (c.lineas||[]).reduce((x,l)=>{
    const p = (MENU.plats||[]).find(y=>y.id === l.platId);
    return x + num(p && p.costo) * num(l.cant,1);
  }, 0);
  const grupos = [];
  const propias = lista.filter(c=>!c.appId);
  if(propias.length) grupos.push({nombre:"Mostrador y para llevar", color:"#7A8A99", cs:propias});
  (P.apps||[]).forEach(a=>{
    const cs = lista.filter(c=>c.appId === a.id);
    if(cs.length) grupos.push({nombre:a.nombre, color:a.color, cs:cs});
  });
  if(!grupos.length){ w.innerHTML = '<div class="empty">Todavía no hay ventas hoy.</div>'; return; }
  w.innerHTML = grupos.map(g=>{
    const vendido = g.cs.reduce((s,c)=>s+num(c.total), 0);
    const com     = g.cs.reduce((s,c)=>s+comisionDe(c), 0);
    const cost    = g.cs.reduce((s,c)=>s+costoDe(c), 0);
    const queda   = vendido - com - cost;
    const pct     = vendido ? Math.round(queda/vendido*100) : 0;
    return '<div class="appRen"><span class="nom"><i style="background:'+esc(g.color||"#888")+'"></i>' +
      esc(g.nombre)+' <small style="color:var(--ink-3);font-size:11px">'+g.cs.length+' pedido(s)</small></span>' +
      '<span class="ci">'+mx(vendido)+'<small>vendido</small></span>' +
      '<span class="ci'+(com?" mal":"")+'">'+(com?"−"+mx(com):"—")+'<small>comisión</small></span>' +
      '<span class="ci '+(queda>0?"bien":"mal")+'">'+mx(queda)+'<small>te queda '+pct+'%</small></span></div>';
  }).join("");
}

function renderVentas(){""",
    "pintaPorCanal")

# columna canal
uno("""  $("#t_ventas").innerHTML = '<thead><tr><th>Folio</th><th>Mesa</th><th>Fecha</th><th>Cerró</th>' +""",
    """  $("#t_ventas").innerHTML = '<thead><tr><th>Folio</th><th>Mesa</th><th>Canal</th><th>Fecha</th><th>Cerró</th>' +""",
    "encabezado con canal")

uno("""      return '<tr data-tk="'+esc(c.id)+'"><td class="mono">'+esc(c.folio)+'</td><td>'+esc(c.mesaNombre)+'</td>' +
        '<td class="mono">'+esc(c.fecha)+'</td><td class="mono">'+esc(c.cierra||"")+'</td>' +""",
    """      const canal = c.appId
        ? '<span class="appPill"><i style="background:'+esc(c.appColor||"#888")+'"></i>'+esc(c.appNombre||"")+
          ' '+pct1(c.comisionPct)+'</span>'
        : '<span style="color:var(--ink-3);font-size:11.5px">Propia</span>';
      return '<tr data-tk="'+esc(c.id)+'"><td class="mono">'+esc(c.folio)+'</td><td>'+esc(c.mesaNombre)+'</td>' +
        '<td>'+canal+'</td>' +
        '<td class="mono">'+esc(c.fecha)+'</td><td class="mono">'+esc(c.cierra||"")+'</td>' +""",
    "celda de canal")

uno("""    }).join("") : '<tr><td colspan="9"><div class="empty">Nada con ese filtro.</div></td></tr>') + '</tbody>';""",
    """    }).join("") : '<tr><td colspan="10"><div class="empty">Nada con ese filtro.</div></td></tr>') + '</tbody>';""",
    "colspan")

# tarjeta de canales en Ventas
uno("""  <div class="tiles" id="venTiles"></div>
  <div class="card">
    <header><h2>Tickets cobrados</h2><span class="hint" id="venHint"></span></header>""",
    """  <div class="tiles" id="venTiles"></div>
  <div class="card">
    <header><h2>De dónde salió la venta de hoy</h2></header>
    <div class="body">
      <p class="note" style="margin:0 0 14px">Vender por app no es lo mismo que vender en mesa. La columna de la
        derecha es lo que <b>de verdad te queda</b> después de la comisión y del costo del platillo. Si una
        plataforma te sale en rojo, no estás vendiendo: estás trabajando gratis.</p>
      <div class="appResumen" id="venCanal"></div>
    </div>
  </div>
  <div class="card">
    <header><h2>Tickets cobrados</h2><span class="hint" id="venHint"></span></header>""",
    "tarjeta de canales")

# el ticket dice de que app es
uno("""  cuerpo += '<div class="c g">'+(c.mesaId === "llevar" ? "PARA LLEVAR" : esc(c.mesaNombre).toUpperCase())+'</div>';""",
    """  cuerpo += '<div class="c g">'+(c.appId ? esc(c.appNombre).toUpperCase() :
    c.mesaId === "llevar" ? "PARA LLEVAR" : esc(c.mesaNombre).toUpperCase())+'</div>';""",
    "el ticket dice la app")

# ajustes
uno("""  <div class="card">
    <header><h2>Respaldo</h2><span class="hint" id="respHint"></span></header>""",
    """  <div class="card">
    <header><h2>Apps de reparto</h2><span class="hint">Uber Eats · Rappi · DiDi Food</span></header>
    <div class="body">
      <p class="note" style="margin:0 0 14px">Pon <b>la comisión que tú negociaste</b>, no la que trae de fábrica.
        Cambiarla aquí no toca los pedidos ya cobrados: cada pedido se queda con la comisión que tenía el día
        que entró, para que los reportes viejos sigan diciendo la verdad.</p>
      <div id="appsEdit"></div>
      <div class="fila" style="margin-top:12px">
        <button class="btn sm" id="appsAgrega">+ Agregar otra plataforma</button>
      </div>
    </div>
  </div>
  <div class="card">
    <header><h2>Respaldo</h2><span class="hint" id="respHint"></span></header>""",
    "tarjeta de apps en Ajustes")

uno("""function renderSet(){""",
    """function pintaAppsEdit(){
  const w = $("#appsEdit"); if(!w) return;
  w.innerHTML = (P.apps||[]).map(a=>
    '<div class="appRen" style="grid-template-columns:auto 1fr 96px auto auto">' +
      '<input type="color" value="'+esc(a.color||"#888888")+'" data-appcolor="'+esc(a.id)+'" ' +
        'style="width:34px;height:34px;padding:2px;border-radius:9px;border:1px solid var(--line);background:var(--surface-2)">' +
      '<input value="'+esc(a.nombre)+'" data-appnom="'+esc(a.id)+'" placeholder="Nombre de la plataforma">' +
      '<input type="number" min="0" max="100" step="0.5" value="'+num(a.comision)+'" data-appcom="'+esc(a.id)+'">' +
      '<span style="font-size:12.5px;color:var(--ink-3)">% de comisión</span>' +
      '<label class="sw" style="white-space:nowrap"><input type="checkbox" data-appact="'+esc(a.id)+'"' +
        (a.activa !== false ? " checked" : "") + '> La uso</label>' +
    '</div>').join("") || '<div class="empty">Sin plataformas. Agrega una.</div>';
}
document.addEventListener("input", e=>{
  const t2 = e.target;
  const id = t2.dataset && (t2.dataset.appnom || t2.dataset.appcom || t2.dataset.appcolor);
  if(!id) return;
  const a = appDe(id); if(!a) return;
  if(t2.dataset.appnom)   a.nombre   = t2.value;
  if(t2.dataset.appcom)   a.comision = num(t2.value);
  if(t2.dataset.appcolor) a.color    = t2.value;
  persist(); pintaAppsFila();
});
document.addEventListener("change", e=>{
  const id = e.target.dataset && e.target.dataset.appact; if(!id) return;
  const a = appDe(id); if(!a) return;
  a.activa = e.target.checked; persist(); pintaAppsFila();
});
document.addEventListener("click", e=>{
  if(!e.target.closest("#appsAgrega")) return;
  P.apps = (P.apps||[]).concat([{id:uid(), nombre:"", comision:0, color:"#7A8A99", activa:true}]);
  persist(); pintaAppsEdit(); pintaAppsFila();
});

function renderSet(){""",
    "editor de apps")

uno("""  $("#p_iva").value = num(P.iva,16); $("#p_propina").value = num(P.propina,10);""",
    """  pintaAppsEdit();
  $("#p_iva").value = num(P.iva,16); $("#p_propina").value = num(P.propina,10);""",
    "pintar el editor al abrir Ajustes")

R.write_text(t, encoding='utf-8')
print("Parte 3 lista. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
