# -*- coding: utf-8 -*-
"""Azulejos en Ventas y El menu del restaurante.

   Caja se queda como esta: son dos tarjetas y las dos se miran juntas
   —el turno y sus movimientos—. Partirlas seria esconder la mitad de una
   sola idea, que es justo lo contrario de lo que arreglan los azulejos.

   Costos tampoco: ya tiene su propio selector simple/profesional arriba,
   que hace el mismo trabajo. Dos formas de ordenar la misma pantalla se
   estorban."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones

R = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
t = R.read_text(encoding='utf-8')
hechos = []
def uno(v, n, et):
    global t
    c = t.count(v)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (et, c))
    t = t.replace(v, n, 1); hechos.append(et)

# ---------------- VENTAS ----------------
uno("""  <div class="tiles" id="venTiles"></div>
  <div class="card">
    <header><h2>De dónde salió la venta de hoy</h2></header>""",
    """  """ + secciones.barra("ventas", "Ventas") + """
  <div class="tiles" id="venTiles"></div>
  """ + secciones.lanzador("ventas") + """
  <div class="card secOculta" data-ven="canal">
    <header><h2>De dónde salió la venta de hoy</h2></header>""",
    "lanzador en Ventas")

for v, n, et in [
 ('  <div class="card">\n    <header><h2>Tickets cobrados</h2>',
  '  <div class="card secOculta" data-ven="tickets">\n    <header><h2>Tickets cobrados</h2>', "tickets"),
 ('  <div class="card">\n    <header><h2>Cancelaciones</h2>',
  '  <div class="card secOculta" data-ven="cancel">\n    <header><h2>Cancelaciones</h2>', "cancelaciones"),
 ('  <div class="card">\n    <header><h2>Turnos cerrados</h2>',
  '  <div class="card secOculta" data-ven="turnos">\n    <header><h2>Turnos cerrados</h2>', "turnos"),
]: uno(v, n, et)

# ---------------- EL MENÚ ----------------
uno("""<section id="tab-menu" hidden>
  <div class="card">
    <header><h2>Categorías</h2>""",
    """<section id="tab-menu" hidden>
  """ + secciones.barra("menu", "El menú") + """
  """ + secciones.lanzador("menu") + """
  <div class="card secOculta" data-men="cats">
    <header><h2>Categorías</h2>""",
    "lanzador en El menú")

for v, n, et in [
 ('  <div class="card">\n    <header><h2>Platillos</h2>',
  '  <div class="card secOculta" data-men="plats">\n    <header><h2>Platillos</h2>', "platillos"),
 ('  <div class="card">\n    <header><h2>Grupos de modificadores</h2>',
  '  <div class="card secOculta" data-men="mods">\n    <header><h2>Grupos de modificadores</h2>', "modificadores"),
]: uno(v, n, et)

# ---------------- el registro ----------------
uno("""  registraLanzador("personal", [""",
    """  registraLanzador("ventas", [
    {id:"canal", nombre:"De dónde salió", sub:"mostrador contra apps", color:"#D2541F",
     icono:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
     card:'[data-ven="canal"]'},
    {id:"tickets", nombre:"Tickets cobrados", sub:"y volver a imprimirlos", color:"#0680AB",
     icono:'<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2Z"/><path d="M9 8h6M9 12h6"/>',
     card:'[data-ven="tickets"]',
     cuenta:()=>COMANDAS.filter(c=>c.estado==="cerrada").length},
    {id:"cancel", nombre:"Cancelaciones", sub:"el dinero que no entró", color:"#C62828",
     icono:'<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>',
     card:'[data-ven="cancel"]',
     cuenta:()=>COMANDAS.reduce((s,c)=>s+((c.cancelaciones||[]).length),0)},
    {id:"turnos", nombre:"Turnos cerrados", sub:"con su diferencia", color:"#0E7C57",
     icono:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/>',
     card:'[data-ven="turnos"]',
     cuenta:()=>TURNOS.filter(x=>!x.abierto).length}
  ], "Ventas");

  registraLanzador("menu", [
    {id:"plats", nombre:"Platillos", sub:"precio y costo", color:"#D2541F",
     icono:'<path d="M4 3v8a3 3 0 0 0 6 0V3M7 11v10"/><path d="M17 3c-1.6 1.6-2 3-2 5s.5 3 2 3v10"/>',
     card:'[data-men="plats"]', cuenta:()=>(MENU.plats||[]).length},
    {id:"cats", nombre:"Categorías", sub:"cómo se agrupa la carta", color:"#0680AB",
     icono:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 10v10"/>',
     card:'[data-men="cats"]', cuenta:()=>(MENU.cats||[]).length},
    {id:"mods", nombre:"Modificadores", sub:"término, extras, sin qué", color:"#8B5CF6",
     icono:'<path d="M5 6h14M5 12h14M5 18h9"/><circle cx="17" cy="18" r="2.4"/>',
     card:'[data-men="mods"]', cuenta:()=>(MENU.mods||[]).length}
  ], "El menú");

  registraLanzador("personal", [""",
    "el registro de los tres")

uno("""  if(k === "set" || k === "personal"){""",
    """  if(k === "set" || k === "personal" || k === "ventas" || k === "menu"){""",
    "al entrar a las secciones nuevas")

R.write_text(t, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
