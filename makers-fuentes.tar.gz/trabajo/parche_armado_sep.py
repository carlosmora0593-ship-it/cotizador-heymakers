# -*- coding: utf-8 -*-
"""Separacion y orilla a la mano, dentro del armado.

   Ya estaban: viven en el material, en Catalogo. Pero son justo los dos
   numeros con los que uno juega cuando quiere ver si el rollo alcanza, y
   tenerlos a tres pantallas de distancia significa que nadie los toca.

   Ojo con lo que son: cambiarlos aqui cambia EL MATERIAL, no solo esta
   cotizacion. Por eso se dice con todas sus letras debajo del campo."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""        '<label class="armCampo armAncho"><span>Nota para producción</span><input data-ark="nota" value="'+esc(row.nota||"")+'" placeholder="Ej. dejar 1 cm de sangrado"></label>'+
      '</div>'+""",
"""        '<label class="armCampo armAncho"><span>Nota para producción</span><input data-ark="nota" value="'+esc(row.nota||"")+'" placeholder="Ej. dejar 1 cm de sangrado"></label>'+
      '</div>'+
      /* Los dos números con los que de verdad se juega para ver si el rollo
         alcanza. Estaban en Catálogo, a tres pantallas de aquí, así que
         nadie los movía. Cambiarlos cambia EL MATERIAL, no esta cotización
         nada más, y por eso se dice abajo. */
      (svcDeArmado(row)
        ? '<div class="armCampos armSepOri">'+
            '<label class="armCampo"><span>Separación (cm)</span>'+
              '<input type="number" min="0" step="0.1" data-arksvc="separacion" value="'+num(svcDeArmado(row).separacion)+'"></label>'+
            '<label class="armCampo"><span>Orilla (cm)</span>'+
              '<input type="number" min="0" step="0.1" data-arksvc="orilla" value="'+num(svcDeArmado(row).orilla)+'"></label>'+
            '<label class="armCampo"><span>Ancho útil</span>'+
              '<input type="text" value="'+(num(svcDeArmado(row).ancho) - 2*num(svcDeArmado(row).orilla))+' cm de '+num(svcDeArmado(row).ancho)+'" readonly></label>'+
            '<span class="armSepNota">Esto le cambia el material a <b>'+esc(svcDeArmado(row).nombre)+'</b> en tu catálogo, no sólo a esta cotización.</span>'+
          '</div>'
        : '')+""",
    "separación y orilla dentro del armado")

uno("""/* Repinta sólo lo que cambia, para no robarle el foco a quien está escribiendo. */
function pintaArmado(){""",
"""const svcDeArmado = row => (cat.servicios||[]).find(s=>s.id === (row && row.servicioId)) || null;

/* Repinta sólo lo que cambia, para no robarle el foco a quien está escribiendo. */
function pintaArmado(){""",
    "el material del renglón")

uno("""  const k = e.target.dataset.ark; if(!k) return;
  it[k] = (k==="nota") ? e.target.value : num(e.target.value);
  pintaArmado(); renderServicio(); renderResumen();""",
"""  const ks = e.target.dataset.arksvc;
  if(ks){
    const s = svcDeArmado(it);
    if(s){ s[ks] = Math.max(0, num(e.target.value)); persist(); pintaArmado(); renderServicio(); renderResumen(); }
    return;
  }
  const k = e.target.dataset.ark; if(!k) return;
  it[k] = (k==="nota") ? e.target.value : num(e.target.value);
  pintaArmado(); renderServicio(); renderResumen();""",
    "guardar separación y orilla")

uno("""/* ---- lanzador dentro de una sección ---- */""",
""".armSepOri{align-items:end;gap:10px}
.armSepOri .armCampo input[readonly]{background:var(--surface-2);color:var(--ink-2);border-style:dashed}
.armSepNota{flex-basis:100%;font-size:11.5px;color:var(--ink-3);line-height:1.45}
/* ---- lanzador dentro de una sección ---- */""",
    "estilos de separación y orilla")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
