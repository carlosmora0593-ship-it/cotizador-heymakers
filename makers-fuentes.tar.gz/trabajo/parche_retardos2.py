# -*- coding: utf-8 -*-
"""Los retardos y las faltas llegan a la nomina.

   Se ENSENAN siempre y se descuentan con un boton. Un descuento que
   aparece solo, sin que nadie lo decida, es como se pierden los juicios
   laborales: el patron tiene que poder explicar de donde salio cada peso
   que no pago."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# 1. el renglón trae su conteo
uno("""  return {id, nombre: (u && u.nombre) || e.nombre || "Sin nombre",
          puesto: e.puesto || "", modo, diario, porHora, trabajo: t, comoSeCalculo,""",
    """  const falt = descuentoDe(id, R);
  return {id, nombre: (u && u.nombre) || e.nombre || "Sin nombre",
          puesto: e.puesto || "", modo, diario, porHora, trabajo: t, comoSeCalculo,
          faltas: falt,""",
    "el renglón trae retardos y faltas")

# 2. los tiles de la nómina
uno("""  $("#nmKpis").innerHTML =
    kpi("A pagar", mx(total), true) +
    kpi("Personas", rs.length) +
    kpi("Horas extra", mx(extra)) +
    kpi("Deducciones", mx(bruto - total));""",
    """  const retTot = rs.reduce((s,r)=>s + ((r.faltas&&r.faltas.retardos)||0), 0);
  const falTot = rs.reduce((s,r)=>s + ((r.faltas&&r.faltas.faltas)||0), 0);
  $("#nmKpis").innerHTML =
    kpi("A pagar", mx(total), true) +
    kpi("Personas", rs.length) +
    kpi("Retardos", retTot + (falTot ? " · " + falTot + " falta(s)" : "")) +
    kpi("Deducciones", mx(bruto - total));""",
    "los tiles cuentan retardos y faltas")

# 3. el renglón de la lista lo dice
uno("""        '<small>'+esc(MODOS_PAGO[r.modo]||"")+' · '+esc(r.comoSeCalculo)+
        (r.trabajo.dias ? ' · '+r.trabajo.dias+' día(s) checado(s)' : ' · sin checadas')+'</small></span>'+""",
    """        '<small>'+esc(MODOS_PAGO[r.modo]||"")+' · '+esc(r.comoSeCalculo)+
        (r.trabajo.dias ? ' · '+r.trabajo.dias+' día(s) checado(s)' : ' · sin checadas')+
        (r.faltas && r.faltas.retardos ? ' · <b style="color:var(--warn)">'+r.faltas.retardos+' retardo(s)</b>' : '')+
        (r.faltas && r.faltas.faltas ? ' · <b style="color:var(--guinda-2,var(--accent))">'+r.faltas.faltas+' falta(s)</b>' : '')+
        '</small></span>'+""",
    "el renglón dice los retardos")

# 4. la ficha de la persona ofrece el descuento
uno("""    '<div class="nmRenSub">'+r.trabajo.dias+' día(s) checado(s) · '+horasTxt(r.trabajo.minutos)+' en el reloj</div>';""",
    """    '<div class="nmRenSub">'+r.trabajo.dias+' día(s) checado(s) · '+horasTxt(r.trabajo.minutos)+' en el reloj</div>' +
    bloqueRetardos(r);""",
    "la ficha ofrece el descuento")

uno("""/* ---------- el renglón de una persona ---------- */""",
    """/* Lo que se vio en el reloj contra lo que decía el horario. Se ensena
   SIEMPRE, y el descuento se agrega con un boton: nunca solo. */
function bloqueRetardos(r){
  const f = r.faltas; if(!f) return "";
  if(!f.retardos && !f.faltas){
    const hay = Object.keys(horarioDe(r.id)).some(k=>horarioDe(r.id)[k].entra);
    return hay ? '<div class="nmRenSub">Sin retardos ni faltas en el periodo.</div>'
               : '<div class="nmRenSub">Sin horario capturado: no hay con qué medir retardos. ' +
                 'Se pone en el expediente.</div>';
  }
  const ya = (r.deduc||[]).some(d=>d.porRetardos);
  return '<div class="nmRet"><span class="txt">' +
    (f.faltas ? '<b>'+f.faltas+' falta(s)</b> sin justificar — '+mx(f.montoFaltas) : '') +
    (f.faltas && f.retardos ? ' · ' : '') +
    (f.retardos ? '<b>'+f.retardos+' retardo(s)</b>, '+minutosTxt(f.minutos)+' — '+mx(f.montoRetardos) : '') +
    '</span>' +
    (ya ? '<span class="pill good">Ya descontado</span>'
        : '<button class="btn sm" data-nmret="'+esc(r.id)+'">Descontar '+mx(f.total)+'</button>') +
    '<button class="btn sm ghost" data-nmretver="'+esc(r.id)+'">Ver los días</button></div>';
}
document.addEventListener("click", e=>{
  const d = e.target.closest("[data-nmret]");
  if(d){
    const R = rangoNomina(nmPer, nmRef);
    const r = renglonNomina(d.dataset.nmret, R);
    const f = r.faltas; if(!f.total) return;
    const deduc = (r.deduc||[]).slice();
    deduc.push({id:uid(), concepto:"Retardos y faltas", monto:f.total, porRetardos:true});
    apuntaNomina(r.id, R, {percep:r.percep, deduc});
    renderNomina();
    if(typeof abreRenglonNom === "function" && nmAbierto === r.id) abreRenglonNom(r.id);
    toast("Descontado "+mx(f.total)+" · se puede quitar del renglón");
    return;
  }
  const v = e.target.closest("[data-nmretver]");
  if(v){
    const R = rangoNomina(nmPer, nmRef);
    const det = retardosDe(v.dataset.nmretver, R);
    const txt = det.retardos.map(x=>"· "+x.fecha+": debía entrar "+x.debia+", llegó "+x.llego+
                 " ("+minutosTxt(x.min)+" tarde)").join("\\n") +
      (det.faltas.length ? "\\n\\nFaltas:\\n" + det.faltas.map(x=>"· "+x.fecha).join("\\n") : "");
    alert(txt || "Sin retardos ni faltas en el periodo.");
  }
});

/* ---------- el renglón de una persona ---------- */""",
    "el bloque de retardos")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
