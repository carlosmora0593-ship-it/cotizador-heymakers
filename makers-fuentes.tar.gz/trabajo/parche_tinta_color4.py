# -*- coding: utf-8 -*-
"""Dos remates: el punto negro no se veia en tema oscuro, y el rollo de
   30 cm no descontaba tinta porque los amarres solo colgaban del de 60."""
import io
RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []
def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1: raise SystemExit("ANCLA '%s': %d coincidencias" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno(
""".gotaIns{display:inline-block;width:11px;height:11px;border-radius:50%;
  margin-right:7px;vertical-align:middle;box-shadow:0 0 0 1px var(--linea) inset,
  0 0 0 1px color-mix(in srgb, var(--ink-1) 18%, transparent)}""",
"""/* El aro no es adorno: el punto negro sobre tema oscuro y el blanco sobre
   tema claro desaparecen sin el. */
.gotaIns{display:inline-block;width:11px;height:11px;border-radius:50%;
  margin-right:7px;vertical-align:middle;
  box-shadow:0 0 0 1.5px color-mix(in srgb, var(--ink-2) 55%, transparent)}""",
    "el punto de color se ve en los dos temas")

uno(
"""  {id:"c2",ancla:"servicio",anclaId:"sv1",insumoId:"i2",cant:100,por:"m2"},""",
"""  {id:"c2",ancla:"servicio",anclaId:"sv1",insumoId:"i2",cant:100,por:"m2"},
  /* El rollo de 30 cm gasta la misma tinta por metro cuadrado que el de 60.
     Sin estos renglones, quien imprime en el chico no veia bajar nada. */
  {id:"c3c",ancla:"servicio",anclaId:"sv2",insumoId:"i1c",cant:6,por:"m2"},
  {id:"c3m",ancla:"servicio",anclaId:"sv2",insumoId:"i1m",cant:6,por:"m2"},
  {id:"c3y",ancla:"servicio",anclaId:"sv2",insumoId:"i1y",cant:6,por:"m2"},
  {id:"c3k",ancla:"servicio",anclaId:"sv2",insumoId:"i1k",cant:7,por:"m2"},
  {id:"c3w",ancla:"servicio",anclaId:"sv2",insumoId:"i1w",cant:25,por:"m2"},
  {id:"c3p",ancla:"servicio",anclaId:"sv2",insumoId:"i2",cant:100,por:"m2"},""",
    "el rollo de 30 cm también descuenta tinta y polvo")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  · " + h)
