# -*- coding: utf-8 -*-
"""Lineas de credito por cliente.

   Lo que pidio Carlos, en sus palabras:
     - linea de credito para clientes
     - en el tablero, los que mas deben
     - no se puede facturar si ya tiene vencido
     - solo con autorizacion se puede facturar si paga la ultima vencida,
       pero se vuelve a bloquear si su credito no da

   Esa ultima frase es la regla fina: la autorizacion perdona lo VENCIDO,
   nunca el LIMITE. Por eso son dos candados distintos y el permiso solo
   abre uno."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


# ============================================================ 1. el motor
MOTOR = r"""
/* ==================== LÍNEAS DE CRÉDITO ====================
   Dos candados que no son el mismo:

     · VENCIDO — ya se le pasó el plazo de algo. Esto se perdona con una
       autorización, y sólo si ya pagó lo más viejo que debía.
     · LÍMITE  — lo que debe más lo nuevo se pasa de su línea. Esto NO se
       perdona nunca: es el tope que tú pusiste.

   Por eso una autorización puede dejar pasar una factura y la siguiente
   volver a frenarse. No es un error: es que el crédito ya no da. */

function clienteDe(id){ return (clientes||[]).find(c=>c.id === id) || null; }
/* El plazo propio le gana al del taller: hay clientes a 30 días y clientes
   de contado, y meterlos a todos en el mismo cajón no refleja el trato. */
function plazoDeCliente(c){
  const p = num(c && c.plazo, 0);
  return p > 0 ? p : plazoCxc();
}
/* Las ventas de un cliente. Se busca por su id, y si la venta es vieja y no
   lo trae, por el nombre: así las de antes de este cambio también cuentan. */
function ventasDeCliente(c){
  if(!c) return [];
  const nom = (c.nombre||"").trim().toLowerCase();
  return (ventas||[]).filter(v=>{
    if(v.clienteId) return v.clienteId === c.id;
    return nom && (v.cliente||"").trim().toLowerCase() === nom;
  });
}
function vencidaDe(v, c){
  return saldoDe(v) > 0 && diasDe(v.fecha) > plazoDeCliente(c);
}
/* La foto completa de un cliente: cuánto debe, cuánto de eso ya se venció,
   cuánto le queda de línea y qué lo está frenando. */
function creditoDe(c){
  const r = {limite:num(c && c.credito, 0), deuda:0, vencido:0, disponible:0,
             conSaldo:[], vencidas:[], masVieja:null, dias:0, plazo:plazoDeCliente(c),
             bloqueo:null, motivo:"", autoriza:autorizacionVigente(c)};
  if(!c) return r;
  const vs = ventasDeCliente(c);
  vs.forEach(v=>{
    const sal = saldoDe(v);
    if(sal <= 0) return;
    r.deuda += sal;
    r.conSaldo.push(v);
    if(vencidaDe(v, c)){
      r.vencido += sal;
      r.vencidas.push(v);
    }
  });
  r.deuda = Math.round(r.deuda*100)/100;
  r.vencido = Math.round(r.vencido*100)/100;
  r.vencidas.sort((a,b)=> (a.fecha<b.fecha?-1:a.fecha>b.fecha?1:0));
  r.masVieja = r.vencidas[0] || null;
  r.dias = r.masVieja ? diasDe(r.masVieja.fecha) : 0;
  r.disponible = r.limite > 0 ? Math.round((r.limite - r.deuda)*100)/100 : 0;
  if(r.vencido > 0 && !r.autoriza){
    r.bloqueo = "vencido";
    r.motivo = "Debe " + mx(r.vencido) + " vencido" +
      (r.masVieja ? " · lo más viejo lleva " + r.dias + " día(s)" : "");
  }else if(r.limite > 0 && r.disponible <= 0){
    r.bloqueo = "limite";
    r.motivo = "Ya se pasó de su línea de " + mx(r.limite) + ": debe " + mx(r.deuda);
  }
  return r;
}
/* La autorización vale para HOY y para una sola cosa. Un permiso que dura
   para siempre deja de ser permiso y se vuelve un agujero. */
function autorizacionVigente(c){
  const a = c && c.autoriza;
  if(!a || !a.dia) return null;
  return a.dia === hoyISO() ? a : null;
}
/* ¿Se puede facturar? Devuelve el porqué, no sólo sí o no: un "no" sin
   razón obliga a adivinar, y aquí hay dinero de por medio. */
function puedeFacturar(c, monto){
  if(!c) return {ok:true};
  const r = creditoDe(c);
  const m = num(monto, 0);
  if(r.bloqueo === "vencido")
    return {ok:false, tipo:"vencido", cred:r,
            motivo:"Tiene " + mx(r.vencido) + " vencido" +
                   (r.masVieja ? ", lo más viejo de hace " + r.dias + " día(s)" : "") + "."};
  /* El límite se revisa SIEMPRE, con autorización o sin ella. */
  if(r.limite > 0 && (r.deuda + m) > r.limite + 0.004)
    return {ok:false, tipo:"limite", cred:r,
            motivo:"Su línea es de " + mx(r.limite) + " y ya debe " + mx(r.deuda) +
                   (m > 0 ? ". Con esta factura de " + mx(m) + " se pasa por " +
                            mx(r.deuda + m - r.limite) + "." : ".")};
  return {ok:true, cred:r};
}
/* El semáforo que se pinta junto al nombre. */
function chipCredito(c){
  const r = creditoDe(c);
  if(!r.limite && !r.deuda) return "";
  const cls = r.bloqueo === "vencido" ? "warn" : r.bloqueo === "limite" ? "pend" : "part";
  const txt = r.bloqueo === "vencido" ? "vencido " + mx(r.vencido)
            : r.bloqueo === "limite"  ? "sin cupo"
            : r.limite ? "le quedan " + mx(r.disponible)
                       : "debe " + mx(r.deuda);
  return '<span class="pill '+cls+' cliCred">'+esc(txt)+'</span>';
}

/* ---------- autorizar una factura con vencido ---------- */
function autorizaFactura(idCliente){
  const c = clienteDe(idCliente); if(!c) return;
  const r = creditoDe(c);
  if(!r.masVieja && !r.vencido){ toast("Este cliente no tiene nada vencido"); return; }
  /* La condición de Carlos: la autorización sólo existe si ya pagó lo más
     viejo. Mientras eso siga abierto, el botón no sirve. */
  if(r.masVieja && saldoDe(r.masVieja) > 0){
    alert("Todavía no se puede autorizar.\n\n" +
          "Lo más viejo que debe es el folio " + (r.masVieja.folio||"—") + " del " +
          (r.masVieja.fecha||"—") + ", con " + mx(saldoDe(r.masVieja)) + " pendientes " +
          "desde hace " + r.dias + " día(s).\n\n" +
          "Regístrale ese abono en Ventas → Cuentas por cobrar y vuelve aquí.");
    return;
  }
  const nota = prompt("¿Por qué se autoriza?\n\nQueda escrito con tu nombre y la fecha.",
                      "Pagó lo más viejo y se le factura hoy");
  if(nota === null) return;
  c.autoriza = {dia:hoyISO(), quien:(usuarioActual().nombre || "—"),
                nota:(nota||"").trim(), cuando:new Date().toISOString()};
  guardaCliente(c);
  renderClientes();
  toast("Autorizado por hoy. El límite sigue aplicando.");
}
function quitaAutorizacion(idCliente){
  const c = clienteDe(idCliente); if(!c) return;
  c.autoriza = null; guardaCliente(c); renderClientes();
  toast("Autorización retirada");
}

/* ---------- el bloque que se pinta en la ficha ---------- */
function bloqueCredito(c){
  const r = creditoDe(c);
  const a = r.autoriza;
  const barra = r.limite > 0
    ? '<div class="credBarra"><i style="width:'+
      Math.min(100, Math.round(r.deuda / r.limite * 100))+'%;background:'+
      (r.bloqueo ? "var(--warn)" : "var(--good)")+'"></i></div>'
    : '';
  return '<div class="credCaja'+(r.bloqueo ? " frenado" : "")+'">' +
    '<div class="credNums">' +
      '<div><span>Línea</span><b>'+(r.limite ? mx(r.limite) : "sin línea")+'</b></div>' +
      '<div><span>Debe hoy</span><b>'+mx(r.deuda)+'</b></div>' +
      '<div><span>Vencido</span><b class="'+(r.vencido?"mal":"")+'">'+mx(r.vencido)+'</b></div>' +
      '<div><span>Le queda</span><b>'+(r.limite ? mx(r.disponible) : "—")+'</b></div>' +
    '</div>' + barra +
    (r.bloqueo
      ? '<p class="credAviso"><b>No se le puede facturar.</b> '+esc(r.motivo)+'</p>'
      : '<p class="credBien">Puede facturar.' +
        (a ? ' <b>Autorizado hoy</b> por '+esc(a.quien)+(a.nota?' — '+esc(a.nota):'')+'.' : '') +
        '</p>') +
    '<div class="credAcc">' +
      (r.bloqueo === "vencido"
        ? '<button class="btn sm" data-credauth="'+esc(c.id)+'">Autorizar una factura</button>'
        : '') +
      (a ? '<button class="btn sm ghost" data-credquita="'+esc(c.id)+'">Quitar la autorización</button>' : '') +
      (r.masVieja
        ? '<span class="hint">Lo más viejo: folio '+esc(r.masVieja.folio||"—")+' del '+
          esc(r.masVieja.fecha||"—")+' · '+mx(saldoDe(r.masVieja))+' · '+r.dias+' día(s)</span>'
        : '') +
    '</div></div>';
}

/* ---------- quién debe más, en el tablero ---------- */
function renderDeben(){
  const w = $("#tbDeben"); if(!w) return;
  const filas = (clientes||[]).map(c=>({c, r:creditoDe(c)}))
    .filter(x=> x.r.deuda > 0)
    .sort((a,b)=> (b.r.vencido - a.r.vencido) || (b.r.deuda - a.r.deuda))
    .slice(0, 6);
  const cnt = $("#tbDebenCuenta");
  const totalVenc = (clientes||[]).reduce((s,c)=> s + creditoDe(c).vencido, 0);
  if(cnt) cnt.textContent = totalVenc > 0 ? mx(totalVenc)+" vencido" : "nadie debe de más";
  w.innerHTML = filas.length
    ? filas.map(x=>
        '<button class="tbDebe" data-debe="'+esc(x.c.id)+'">' +
          '<span class="tbDebeNom"><b>'+esc(x.c.nombre||"Sin nombre")+'</b>' +
            '<small>'+(x.r.vencido > 0
              ? mx(x.r.vencido)+' vencido · '+x.r.dias+' día(s)'
              : (x.r.limite ? 'al corriente · le quedan '+mx(x.r.disponible) : 'al corriente'))+
            '</small></span>' +
          '<span class="tbDebeMonto'+(x.r.vencido>0?" mal":"")+'">'+mx(x.r.deuda)+'</span>' +
        '</button>').join("")
    : '<div class="tbVacio">Nadie te debe nada. Así se ve un taller sano.</div>';
}
document.addEventListener("click", e=>{
  const a = e.target.closest("[data-credauth]");
  if(a){ autorizaFactura(a.dataset.credauth); return; }
  const q = e.target.closest("[data-credquita]");
  if(q){ quitaAutorizacion(q.dataset.credquita); return; }
  const d = e.target.closest("[data-debe]");
  if(d){
    clienteSel = d.dataset.debe;
    const b = document.querySelector('[data-tab="cli"]'); if(b) b.click();
    setTimeout(()=>{ if(typeof renderClientes === "function") renderClientes(); }, 60);
    return;
  }
});
"""

uno(
"""function saldoDe(v){ return Math.max(0, Math.round((num(v.total) - num(v.recibido))*100)/100); }""",
"""function saldoDe(v){ return Math.max(0, Math.round((num(v.total) - num(v.recibido))*100)/100); }"""
    + MOTOR,
    "el motor del crédito")

# ======================================== 2. los campos en la ficha
uno(
"""   '<div style="margin-top:12px"><label class="f">Notas</label><textarea data-ck="notas" rows="2">'+esc(c.notas)+'</textarea></div>'+""",
"""   '<div class="grid g3" style="margin-top:12px">'+
   '<div><label class="f">Línea de crédito</label><input type="number" min="0" step="100" data-ck="credito" value="'+num(c.credito,0)+'"></div>'+
   '<div><label class="f">Días de crédito</label><input type="number" min="0" step="1" data-ck="plazo" value="'+num(c.plazo,0)+'" placeholder="'+plazoCxc()+'"></div>'+
   '<div style="display:flex;flex-direction:column"><label class="f">&nbsp;</label>'+
   '<span class="hint" style="margin-top:auto;min-height:44px;display:flex;align-items:center">'+
   'Línea en cero = sólo de contado. Días en cero = usa los '+plazoCxc()+' del taller.</span></div></div>'+
   bloqueCredito(c)+
   '<div style="margin-top:12px"><label class="f">Notas</label><textarea data-ck="notas" rows="2">'+esc(c.notas)+'</textarea></div>'+""",
    "la línea de crédito en la ficha")

uno(
"""  c[k] = k==="rfc" ? e.target.value.toUpperCase() : e.target.value;""",
"""  c[k] = k==="rfc" ? e.target.value.toUpperCase()
       : (k==="credito" || k==="plazo") ? Math.max(0, num(e.target.value))
       : e.target.value;""",
    "la línea se guarda como número")

uno(
"""    '<b>'+esc(c.nombre||"Sin nombre")+'</b><small>'+esc(c.rfc||"sin RFC")+""",
"""    '<b>'+esc(c.nombre||"Sin nombre")+'</b>'+chipCredito(c)+'<small>'+esc(c.rfc||"sin RFC")+""",
    "el semáforo en la lista de clientes")

# ====================================== 3. el candado al facturar
uno(
"""function abreGeneraFactura(folio){
  const g = guardadas.find(g=>g.folio===folio) || (cot.folio===folio ? cot : null);
  if(!g){ toast("No encuentro esa cotización"); return; }""",
"""function abreGeneraFactura(folio){
  const g = guardadas.find(g=>g.folio===folio) || (cot.folio===folio ? cot : null);
  if(!g){ toast("No encuentro esa cotización"); return; }
  /* El candado del crédito. Antes de timbrarle a alguien hay que mirar lo
     que ya debe: una factura más a quien no ha pagado la anterior es cómo
     se juntan las carteras incobrables. */
  const cli = clienteDe(g.clienteId);
  if(cli){
    const vta = (ventas||[]).find(v=>v.folio === folio);
    const monto = vta ? num(vta.total) : 0;
    const paso = puedeFacturar(cli, monto);
    if(!paso.ok){
      const r = paso.cred;
      if(paso.tipo === "vencido"){
        alert("No se le puede facturar a " + (cli.nombre||"este cliente") + ".\\n\\n" +
              paso.motivo + "\\n\\n" +
              "Para destrabarlo: que pague lo más viejo (folio " +
              ((r.masVieja && r.masVieja.folio) || "—") + ") y después autorízalo " +
              "en Clientes → su ficha.");
      }else{
        alert("No se le puede facturar a " + (cli.nombre||"este cliente") + ".\\n\\n" +
              paso.motivo + "\\n\\n" +
              "Esto no se autoriza: o cobra algo de lo que debe, o súbele la " +
              "línea de crédito en su ficha si así lo decidiste.");
      }
      return;
    }
  }""",
    "no se factura con vencido ni sin cupo")

# ====================================== 4. el panel del tablero
uno(
"""      <div class="tbPanel">
        <header><h2>Lo que urge</h2><span class="tbCuenta" id="tbUrgeCuenta"></span></header>
        <div class="tbPanelBody"><div id="tbUrge"></div></div>
      </div>""",
"""      <div class="tbPanel">
        <header><h2>Lo que urge</h2><span class="tbCuenta" id="tbUrgeCuenta"></span></header>
        <div class="tbPanelBody"><div id="tbUrge"></div></div>
      </div>
      <div class="tbPanel" id="tbPanelDeben" data-solo-admin>
        <header><h2>Quién debe más</h2><span class="tbCuenta" id="tbDebenCuenta"></span></header>
        <div class="tbPanelBody"><div id="tbDeben"></div></div>
      </div>""",
    "el panel de quién debe más")

uno(
"""function renderTablero(){""",
"""function renderTablero(){
  if(typeof renderDeben === "function") renderDeben();""",
    "el tablero lo pinta")

# ====================================== 5. la ropa
uno(
"""/* ---- la luz que sigue al cursor ---- */""",
"""/* ---- líneas de crédito ---- */
.cliCred{margin-left:7px;font-size:10.5px;vertical-align:middle}
.credCaja{margin-top:14px;padding:13px 15px;border:1.5px solid var(--line);
  border-radius:var(--radio-sm,12px);background:var(--surface-2)}
.credCaja.frenado{border-color:var(--warn);
  background:color-mix(in srgb, var(--warn) 9%, var(--surface-2))}
.credNums{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px}
.credNums span{display:block;font-size:10.5px;font-weight:700;letter-spacing:.05em;
  text-transform:uppercase;color:var(--ink-3)}
.credNums b{display:block;font-family:"IBM Plex Mono",monospace;font-size:17px;margin-top:2px}
.credNums b.mal{color:var(--warn)}
.credBarra{height:7px;border-radius:999px;background:var(--surface);overflow:hidden;margin:11px 0 0;
  box-shadow:inset 0 0 0 1px var(--line-soft)}
.credBarra i{display:block;height:100%;border-radius:999px;transition:width .3s}
.credAviso{margin:11px 0 0;font-size:12.5px;line-height:1.5;color:var(--warn)}
.credBien{margin:11px 0 0;font-size:12.5px;line-height:1.5;color:var(--ink-2)}
.credAcc{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-top:11px}
.credAcc .hint{font-size:11.5px}
.tbDebe{display:flex;align-items:center;gap:10px;width:100%;text-align:left;cursor:pointer;
  padding:10px 11px;border:1px solid var(--line);border-radius:var(--radio-sm,11px);
  background:var(--surface-2);color:inherit;font:inherit;margin-bottom:7px;
  transition:border-color .16s,transform .12s}
.tbDebe:hover{border-color:var(--accent);transform:translateY(-1px)}
.tbDebeNom{flex:1;min-width:0}
.tbDebeNom b{display:block;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tbDebeNom small{display:block;font-size:11px;color:var(--ink-3);margin-top:1px}
.tbDebeMonto{font-family:"IBM Plex Mono",monospace;font-size:14px;font-weight:650}
.tbDebeMonto.mal{color:var(--warn)}
.tbVacio{font-size:12.5px;color:var(--ink-3);padding:6px 2px}

/* ---- la luz que sigue al cursor ---- */""",
    "los estilos del crédito")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
