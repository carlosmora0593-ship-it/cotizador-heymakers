# -*- coding: utf-8 -*-
"""Que el Lab diga en la cara si le falta la puerta.

   El boton de plan ya llama a staff_cambia_plan. Pero si esa funcion no
   esta en la base, el error sale hasta que alguien hace clic, y si el
   navegador se quedo con el lab.html viejo ni eso: se ve que no pasa nada.

   Esto lo pregunta al entrar, con una llamada que NO cambia nada —una
   cuenta que no existe— y deja un letrero fijo arriba si falta. Un
   programa que no puede hacer su trabajo tiene que decirlo solo."""
import io

RUTA = "lab.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


uno(
"""/* La única puerta que la base acepta para mover una suscripción.""",
"""/* ¿Está puesta la puerta? Se pregunta con una cuenta que no existe: la
   función revisa que seas del equipo, no encuentra la cuenta y contesta
   "no existe" sin tocar un solo renglón. Si la función no está, Postgres
   contesta que no la encuentra, y eso es justo lo que queremos saber. */
let PUERTA_PLAN = null;      /* null = sin preguntar, true/false = respuesta */
async function revisaPuertaPlan(){
  if(PUERTA_PLAN !== null || !window.SB) return PUERTA_PLAN;
  try{
    const r = await SB.rpc("staff_cambia_plan",
      {p_cuenta:"00000000-0000-0000-0000-000000000000", p_motivo:"revisión"});
    const m = String((r && r.error && r.error.message) || "");
    PUERTA_PLAN = !/could not find|does not exist|schema cache|staff_cambia_plan/i.test(m);
    if(!PUERTA_PLAN) console.warn("staff_cambia_plan no está en la base:", m);
  }catch(e){ PUERTA_PLAN = null; }   /* sin red: no se concluye nada */
  pintaAvisoPuerta();
  return PUERTA_PLAN;
}
function pintaAvisoPuerta(){
  const viejo = document.getElementById("avisoPuerta");
  if(viejo) viejo.remove();
  if(PUERTA_PLAN !== false) return;
  const d = document.createElement("div");
  d.id = "avisoPuerta";
  d.style.cssText = "margin:0 0 14px;padding:12px 15px;border-radius:12px;" +
    "border:1px solid #e0b24a;background:#fff8e8;color:#5c4410;font-size:13px;line-height:1.5";
  d.innerHTML = "<b>Los botones de plan no van a llegar a la base.</b> " +
    "Falta correr en Supabase el SQL <b>CORRER-5-lab-manda.sql</b> " +
    "(aquí sale como 08-lab-manda.sql). Mientras no esté, puedes mirar las " +
    "cuentas pero no cambiarles el plan, la vigencia ni darlas de baja: la " +
    "base rechaza cualquier intento desde el navegador, a propósito.";
  const cont = document.querySelector("main") || document.body;
  cont.insertBefore(d, cont.firstChild);
}

/* La única puerta que la base acepta para mover una suscripción.""",
    "la revisión de la puerta")

# que se pregunte al entrar
uno(
"""  revisaMigraciones().catch(() => {});""",
"""  revisaMigraciones().catch(() => {});
  /* Sin await: si la base tarda, el Lab abre igual y el letrero aparece
     cuando haya respuesta. */
  revisaPuertaPlan().catch(() => {});""",
    "se pregunta al arrancar")

# y que el boton lo deje claro tambien
uno(
"""  if (!window.SB) { aviso("Sin conexión con la base: el cambio no se mandó."); return; }""",
"""  if (!window.SB) { aviso("Sin conexión con la base: el cambio no se mandó."); return; }
  if (PUERTA_PLAN === false) {
    aviso("Falta correr CORRER-5-lab-manda.sql en Supabase: sin eso el cambio no llega a la base.");
    pintaAvisoPuerta();
    return;
  }""",
    "el botón tampoco finge")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
