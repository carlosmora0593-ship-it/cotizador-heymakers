# -*- coding: utf-8 -*-
"""El diseno del archivo de ChatGPT, traido a la casa.

   Los colores entran como UNA PALETA MAS en Apariencia, no como un cambio
   a la fuerza: Carlos la escoge si le gusta y quien prefiera el oscuro lo
   deja como esta. Los detalles de diseno —la palomita del azulejo elegido,
   el aro de foco, el icono que se ladea— si van para todos, porque no son
   de ningun color: son de como responde la pantalla."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


# ------------------------------------------------------ 1. la paleta nueva
uno(
"""  heymakers:{nombre:"Hey Makers", acento:"#D6127F", amb:["#06A1D7","#F51B95","#FFEC30"]},""",
"""  estudio:  {nombre:"Estudio",     acento:"#173E36", amb:["#173E36","#508B6E","#D7FA75"],
             modo:"light", vars:{
    "--bg":"#F4F3ED", "--surface":"#FFFEFA", "--surface-2":"#F4F6EF",
    "--line":"#E5E2D8", "--line-soft":"#EDEBE2",
    "--ink":"#202724", "--ink-2":"#4C5C51", "--ink-3":"#858C83",
    "--cyan":"#1F6E7A", "--cyan-soft":"#E3EFF1",
    "--good":"#347856", "--good-soft":"#EAF4EB",
    "--warn":"#9B6A12", "--warn-soft":"#FFF6DF",
    "--yellow":"#C79A14", "--yellow-ink":"#231A00",
    "--guinda":"#B45B3C", "--guinda-2":"#8F4328",
    "--guinda-tenue":"#FFF0E9", "--guinda-medio":"#F6DDD1",
    "--serie-1":"#173E36", "--serie-2":"#508B6E", "--serie-3":"#B45B3C", "--serie-4":"#9B6A12",
    "--shadow":"0 1px 2px rgba(23,62,54,.05), 0 16px 42px -24px rgba(23,62,54,.38)"
  }},
  heymakers:{nombre:"Hey Makers", acento:"#D6127F", amb:["#06A1D7","#F51B95","#FFEC30"]},""",
    "la paleta Estudio")

# ------------------------------- 2. los detalles de diseno, para toda paleta
CSS = """
/* ---- detalles de diseño ---- */
/* La palomita del elegido. El borde de color solo no basta: en una rejilla
   de dieciséis artículos hay que poder ver cuál es de un vistazo. */
.azIt,.cpAz,.arrOpc{position:relative}
.azIt[aria-pressed="true"]::after,.cpAz[aria-pressed="true"]::after{
  content:"\\2713";position:absolute;right:8px;top:8px;width:18px;height:18px;
  border-radius:50%;display:grid;place-items:center;font-size:11px;line-height:1;
  background:var(--azc,var(--cpc,var(--accent)));color:#fff;
  box-shadow:0 0 0 2px var(--surface-2)}
/* El aro de foco: quien se mueve con el teclado tiene que ver dónde está. */
.azIt:focus-visible,.cpAz:focus-visible,.lzApp:focus-visible,.arrOpc:focus-visible,
.guiaTira .guiaP:focus-visible,.cpPaso .cpCab:focus-visible{
  outline:3px solid color-mix(in srgb, var(--accent) 45%, transparent);
  outline-offset:2px}
/* El icono se ladea un poco cuando el puntero entra. Es el detalle que hace
   que el azulejo se sienta un botón y no una estampa. */
.azIco,.cpIco,.lzIco,.tbAccIco,.arrOpc .arrIco{
  transition:transform .25s cubic-bezier(.2,.8,.3,1),background .2s,color .2s}
.azIt:hover .azIco,.cpAz:hover .cpIco,.lzApp:hover .lzIco,
.tbAcceso:hover .tbAccIco,.arrOpc:hover .arrIco{transform:scale(1.07) rotate(-4deg)}
@media (prefers-reduced-motion: reduce){
  .azIco,.cpIco,.lzIco,.tbAccIco,.arrOpc .arrIco{transition:none!important}
  .azIt:hover .azIco,.cpAz:hover .cpIco,.lzApp:hover .lzIco,
  .tbAcceso:hover .tbAccIco,.arrOpc:hover .arrIco{transform:none}
}
"""

uno(
"""/* ============ EL MOVIMIENTO ============""",
CSS + """
/* ============ EL MOVIMIENTO ============""",
    "la palomita, el aro de foco y el icono que se ladea")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
