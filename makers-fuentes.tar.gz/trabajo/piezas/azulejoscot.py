# -*- coding: utf-8 -*-
"""Los azulejos del cotizador por pasos.

   La pinta del artefacto, encima de la pantalla de siempre: el cliente con
   buscador y alta, el articulo con su foto, la tecnica y el tamano como
   mosaicos. No hay motor nuevo: cada azulejo escribe en el MISMO campo que
   ya existia y dispara su evento, asi que todo lo que funcionaba sigue
   funcionando. Apagando el interruptor de Ajustes no queda rastro."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


# ------------------------------------------------------------------ estilos
uno(
"""/* ---- cotizar por pasos ---- */""",
"""/* ---- los azulejos del cotizador ---- */
.azBloque{margin:0 0 16px}
.azBloque>.f{display:block;margin-bottom:8px}
.azBarra{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
.azBarra input{flex:1 1 180px;min-width:150px}
.azBarra .hint{white-space:nowrap}
.azChips{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}
.azChips button{font:inherit;font-size:12px;padding:5px 11px;border-radius:999px;
  border:1px solid var(--line);background:var(--surface-2);color:var(--ink-2);cursor:pointer}
.azChips button:hover{border-color:var(--accent);color:var(--accent)}
.azChips button[aria-pressed="true"]{background:var(--accent);border-color:var(--accent);color:#fff}
.azRej{display:grid;grid-template-columns:repeat(auto-fill,minmax(164px,1fr));gap:9px}
.azRej.chica{grid-template-columns:repeat(auto-fill,minmax(128px,1fr))}
.azIt{position:relative;display:flex;flex-direction:column;align-items:flex-start;gap:5px;
  text-align:left;border:1.5px solid var(--line);background:var(--surface-2);border-radius:13px;
  padding:11px;cursor:pointer;font:inherit;color:var(--ink);min-width:0;
  transition:border-color .15s,background .15s,transform .1s}
.azIt:hover{border-color:var(--azc,var(--accent));transform:translateY(-1px)}
.azIt[aria-pressed="true"]{border-color:var(--azc,var(--accent));
  background:color-mix(in srgb, var(--azc,var(--accent)) 11%, var(--surface-2))}
.azIt b{font-family:"Fredoka",system-ui,sans-serif;font-weight:500;font-size:13px;line-height:1.2;
  width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.azIt small{color:var(--ink-3);font-size:11px;line-height:1.35;width:100%;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.azIt .artMini{width:100%;height:62px;object-fit:cover;border-radius:9px}
.azIt .azIco{width:30px;height:30px;border-radius:9px;display:grid;place-items:center;
  background:color-mix(in srgb, var(--azc,var(--accent)) 20%, transparent);color:var(--azc,var(--accent))}
.azIt .azIco svg{width:17px;height:17px}
.azNuevo{border-style:dashed;align-items:center;justify-content:center;text-align:center}
.azVacio{font-size:12.5px;color:var(--ink-3);margin:2px 0 0}
.azMas{font-size:12px;color:var(--ink-3);margin:9px 0 0}
/* ---- cotizar por pasos ---- */""",
    "los estilos de los azulejos")

# ------------------------------------------------------------------- motor
MOTOR = r"""
/* ============ LOS AZULEJOS DEL COTIZADOR ============
   Sólo viven en el modo guiado. Cada azulejo escribe en el campo que ya
   existía y dispara su evento: ni un cálculo nuevo, ni una verdad nueva. */
let AZ = {cliBusca:"", artBusca:"", artCat:"", cliTodos:false};
const AZ_TOPE = 12;   /* cuántos se enseñan antes del «ver todos» */

function azIco(d){
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+d+'</svg>';
}
function azCaja(id, padre, donde){
  let c = document.getElementById(id);
  if(!c){
    const p = document.querySelector(padre); if(!p) return null;
    p.insertAdjacentHTML(donde || "afterbegin", '<div class="azBloque" id="'+id+'"></div>');
    c = document.getElementById(id);
  }
  return c;
}
function azQuita(id){ const c = document.getElementById(id); if(c) c.remove(); }

/* ---------- 1. el cliente ---------- */
function azClientes(){
  const c = azCaja("azCli", '[data-paso="cliente"] .body', "afterbegin'".slice(0,10));
  if(!c) return;
  const q = (AZ.cliBusca||"").trim().toLowerCase();
  const todos = (typeof clientes !== "undefined" && Array.isArray(clientes)) ? clientes : [];
  const ls = todos.filter(x=> !q ||
    ((x.nombre||"")+" "+(x.razon||"")+" "+(x.rfc||"")+" "+(x.tel||"")+" "+(x.mail||"")).toLowerCase().indexOf(q) >= 0);
  const vista = AZ.cliTodos ? ls : ls.slice(0, AZ_TOPE);
  c.innerHTML =
    '<label class="f" for="azCliBusca">¿Para quién es?</label>' +
    '<div class="azBarra"><input id="azCliBusca" placeholder="Buscar cliente por nombre, teléfono o RFC" value="'+esc(AZ.cliBusca||"")+'">' +
      '<span class="hint">'+ls.length+' de '+todos.length+'</span></div>' +
    '<div class="azRej">' +
      '<button type="button" class="azIt azNuevo" data-azcli="" style="--azc:var(--accent)" aria-pressed="'+(!cot.clienteId)+'">' +
        '<span class="azIco">'+azIco('<path d="M12 5v14M5 12h14"/>')+'</span>' +
        '<b>Cliente nuevo</b><small>lo escribes abajo</small></button>' +
      vista.map(x=>{
        const cont = x.tel || x.mail || "";
        return '<button type="button" class="azIt" data-azcli="'+esc(x.id)+'" style="--azc:#0680AB" ' +
          'aria-pressed="'+(cot.clienteId===x.id)+'">' +
          '<span class="azIco">'+azIco('<circle cx="12" cy="8" r="3.6"/><path d="M5 20a7 7 0 0 1 14 0"/>')+'</span>' +
          '<b>'+esc(x.nombre||x.razon||"Sin nombre")+'</b>' +
          '<small>'+esc(cont || x.rfc || "sin datos")+'</small></button>';
      }).join("") +
    '</div>' +
    (ls.length > vista.length
      ? '<p class="azMas"><button type="button" class="btn sm ghost" id="azCliTodos">Ver los '+ls.length+'</button></p>'
      : '') +
    (todos.length ? '' : '<p class="azVacio">Todavía no tienes clientes guardados. Escribe el nombre abajo y usa «Guardar como cliente».</p>');
}
/* ---------- 2. el artículo ---------- */
function azArticulos(){
  /* En modo servicio no hay artículo que escoger: ahí manda el material. */
  if(cot.modo === "servicio"){ azQuita("azArt"); return; }
  const c = azCaja("azArt", '[data-paso="articulo"] .body', "afterbegin");
  if(!c) return;
  const q = (AZ.artBusca||"").trim().toLowerCase();
  let ls = (cat.articulos||[]).slice();
  if(AZ.artCat) ls = ls.filter(a=>(a.cat||"Otros") === AZ.artCat);
  if(q) ls = ls.filter(a=> ((a.nombre||"")+" "+(a.cat||"")).toLowerCase().indexOf(q) >= 0);
  const cats = (typeof categoriasArt === "function") ? categoriasArt() : [];
  c.innerHTML =
    '<label class="f" for="azArtBusca">¿Qué se va a personalizar?</label>' +
    '<div class="azBarra"><input id="azArtBusca" placeholder="Buscar artículo" value="'+esc(AZ.artBusca||"")+'">' +
      '<span class="hint">'+ls.length+' de '+(cat.articulos||[]).length+'</span></div>' +
    (cats.length > 1
      ? '<div class="azChips" id="azArtCats"><button type="button" data-azartcat=""'+(AZ.artCat?'':' aria-pressed="true"')+'>Todos</button>' +
        cats.map(x=>'<button type="button" data-azartcat="'+esc(x)+'"'+(AZ.artCat===x?' aria-pressed="true"':'')+'>'+esc(x)+'</button>').join("") +
        '</div>'
      : '') +
    '<div class="azRej">' +
      '<button type="button" class="azIt azNuevo" data-artpick="" aria-pressed="'+(!cot.articuloId)+'">' +
        '<span class="azIco">'+azIco('<path d="M12 5v14M5 12h14"/>')+'</span>' +
        '<b>A mi manera</b><small>nombre y costo a mano</small></button>' +
      ls.map(a=>
        '<button type="button" class="azIt" data-artpick="'+esc(a.id)+'" style="--azc:#D6127F" ' +
        'aria-pressed="'+(cot.articuloId===a.id)+'">' + miniArt(a) +
        '<b>'+esc(a.nombre)+'</b><small>'+esc(a.cat||"Sin familia")+' · '+mx(num(a.costo))+'</small></button>'
      ).join("") +
    '</div>' +
    (ls.length ? '' : '<p class="azVacio">Nada con ese nombre. Puedes capturarlo a mano aquí abajo.</p>');
}
/* ---------- 3. la técnica y el tamaño, dentro de cada aplicación ---------- */
const AZ_COLTEC = {area:"#0680AB", tintas:"#8B5CF6", puntadas:"#D2541F", tiempo:"#14B8A6"};
function azAplicaciones(){
  document.querySelectorAll("#apps [data-app]").forEach(row=>{
    const a = cot.apps.find(x=>x.id === row.dataset.app); if(!a) return;
    if(row.querySelector(".azBloque")) return;          // ya los tiene
    const selTec = row.querySelector('[data-k="tecnicaId"]');
    const selTam = row.querySelector('[data-k="tamanoId"]');
    let h = '<div class="azBloque">' +
      '<label class="f">¿Cómo se decora?</label><div class="azRej chica">' +
      (cat.tecnicas||[]).map(t=>
        '<button type="button" class="azIt" data-aztec="'+esc(a.id)+'|'+esc(t.id)+'" ' +
        'style="--azc:'+(AZ_COLTEC[t.modo]||"#0680AB")+'" aria-pressed="'+(a.tecnicaId===t.id)+'">' +
        '<span class="azIco">'+azIco('<circle cx="12" cy="12" r="8"/><path d="M12 8v8M8 12h8"/>')+'</span>' +
        '<b>'+esc(t.nombre)+'</b></button>').join("") +
      '</div>';
    if(selTam){
      h += '<label class="f" style="margin-top:12px">¿De qué tamaño?</label><div class="azRej chica">' +
        '<button type="button" class="azIt azNuevo" data-aztam="'+esc(a.id)+'|" aria-pressed="'+(!a.tamanoId)+'">' +
          '<b>A la medida</b><small>lo escribes abajo</small></button>' +
        (cat.tamanos||[]).map(x=>
          '<button type="button" class="azIt" data-aztam="'+esc(a.id)+'|'+esc(x.id)+'" ' +
          'style="--azc:#14B8A6" aria-pressed="'+(a.tamanoId===x.id)+'">' +
          '<b>'+esc(x.nombre)+'</b><small>'+num(x.ancho)+' × '+num(x.alto)+' cm</small></button>').join("") +
        '</div>';
    }
    h += '</div>';
    /* Los desplegables se quedan: son los que guardan el dato y los que oye
       el programa. Nada más dejan de verse. */
    const rej = row.querySelector(".grid.g4");
    if(rej) rej.insertAdjacentHTML("beforebegin", h);
    [selTec, selTam].forEach(sel=>{
      if(!sel) return;
      const caja = sel.closest("div");
      if(caja) caja.hidden = true;
    });
  });
}
function azPinta(){
  if(typeof guiado !== "function" || !guiado()){
    azQuita("azCli"); azQuita("azArt");
    return;
  }
  azClientes(); azArticulos(); azAplicaciones();
}
/* Los clics. Todo termina en el campo de siempre. */
document.addEventListener("click", e=>{
  const cl = e.target.closest("[data-azcli]");
  if(cl){
    const id = cl.dataset.azcli;
    const sel = $("#c_clienteSel");
    if(!id){
      cot.clienteId = ""; cot.cliente = ""; cot.contacto = "";
      if($("#c_cliente"))  $("#c_cliente").value  = "";
      if($("#c_contacto")) $("#c_contacto").value = "";
      if(sel) sel.value = "";
      azClientes();
      const n = $("#c_cliente"); if(n) n.focus();
    }else if(sel){
      sel.value = id;
      sel.dispatchEvent(new Event("change", {bubbles:true}));
      azClientes();
    }
    if(typeof persist === "function") persist();
    if(typeof resumenPasos === "function") resumenPasos();
    if(typeof guiaRevisa === "function") guiaRevisa();
    return;
  }
  if(e.target.closest("#azCliTodos")){ AZ.cliTodos = true; azClientes(); return; }
  const ac = e.target.closest("[data-azartcat]");
  if(ac){ AZ.artCat = ac.dataset.azartcat; azArticulos(); return; }
  const tc = e.target.closest("[data-aztec]");
  if(tc){
    const p = tc.dataset.aztec.split("|");
    const row = document.querySelector('#apps [data-app="'+p[0]+'"]');
    const sel = row && row.querySelector('[data-k="tecnicaId"]');
    if(sel){ sel.value = p[1]; sel.dispatchEvent(new Event("change", {bubbles:true})); }
    return;
  }
  const tm = e.target.closest("[data-aztam]");
  if(tm){
    const p = tm.dataset.aztam.split("|");
    const row = document.querySelector('#apps [data-app="'+p[0]+'"]');
    const sel = row && row.querySelector('[data-k="tamanoId"]');
    if(sel){ sel.value = p[1] || ""; sel.dispatchEvent(new Event("change", {bubbles:true})); }
    return;
  }
});
document.addEventListener("input", e=>{
  if(e.target.id === "azCliBusca"){
    AZ.cliBusca = e.target.value; AZ.cliTodos = false; azClientes();
    const b = $("#azCliBusca"); if(b){ b.focus(); b.setSelectionRange(b.value.length, b.value.length); }
    return;
  }
  if(e.target.id === "azArtBusca"){
    AZ.artBusca = e.target.value; azArticulos();
    const b = $("#azArtBusca"); if(b){ b.focus(); b.setSelectionRange(b.value.length, b.value.length); }
    return;
  }
});
"""

uno(
"""/* ==================== COTIZAR POR PASOS ====================""",
MOTOR + """
/* ==================== COTIZAR POR PASOS ====================""",
    "el motor de los azulejos")

# ---------------------------------------------------- engancharlo al guiado
uno(
"""  if(typeof resumenPasos === "function") resumenPasos();
}
/* Mientras se escribe, el aviso y el botón de Continuar se refrescan sin""",
"""  if(typeof azPinta === "function") azPinta();
  if(typeof resumenPasos === "function") resumenPasos();
}
/* Mientras se escribe, el aviso y el botón de Continuar se refrescan sin""",
    "la guía pinta los azulejos")

uno(
"""  if(!guiado()){
    if(tira) tira.remove();""",
"""  if(!guiado()){
    if(tira) tira.remove();
    if(typeof azPinta === "function") azPinta();""",
    "al apagar el modo los azulejos se van")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
