# -*- coding: utf-8 -*-
"""Cotizaciones, pedidos, facturas y cobranza, separados.

   El renglon de antes traia siete botones a la vista —Abrir, Ver orden,
   Avisar, Enviar, Facturar, Cobrar, borrar— y los traia TODOS en TODAS las
   cotizaciones, estuvieran o no disponibles. Facturar una cotizacion que ni
   se ha confirmado no hace nada util, pero el boton estaba ahi ocupando
   lugar y haciendo dudar.

   Ahora: cada ficha ensena la accion que de verdad sigue segun donde esta
   la cotizacion, y lo demas se guarda detras de un boton de tres puntos.
   Y arriba hay azulejos que separan lo que es una cotizacion de lo que ya
   es un pedido, una factura o una cuenta por cobrar."""

CSS = """
/* ---- fichas de cotización ---- */
.cotFicha{display:grid;grid-template-columns:1fr auto auto;gap:14px;align-items:center;
  padding:15px 17px;border:1px solid var(--line);border-radius:var(--radio-sm,13px);
  background:var(--surface);margin-bottom:10px;position:relative;
  transition:border-color .16s,box-shadow .16s}
.cotFicha:hover{border-color:var(--accent);box-shadow:var(--shadow)}
.cotQue{min-width:0}
.cotQue b{display:block;font-family:"Fredoka",system-ui,sans-serif;font-weight:500;font-size:15px;
  line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cotQue small{display:block;font-size:11.5px;color:var(--ink-3);margin-top:3px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cotChips{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}
.cotChip{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:600;
  border-radius:999px;padding:3px 10px;line-height:1.5;white-space:nowrap}
.cotChip.pedido{background:var(--cyan-soft);color:var(--cyan)}
.cotChip.vendida{background:var(--good-soft);color:var(--good)}
.cotChip.porfact{background:var(--warn-soft);color:var(--warn)}
.cotChip.facturada{background:var(--good-soft);color:var(--good)}
.cotChip.debe{background:var(--guinda-tenue);color:var(--guinda-2)}
.cotMonto{font-family:"IBM Plex Mono",monospace;font-size:18px;font-weight:600;
  text-align:right;white-space:nowrap}
.cotMonto i{display:block;font-style:normal;font-family:"Nunito Sans",sans-serif;font-size:10px;
  font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-3);margin-top:4px}
.cotAcc{display:flex;align-items:center;gap:8px}
.cotMas{position:relative}
.cotMasBtn{width:34px;height:34px;border-radius:10px;border:1px solid var(--line);
  background:var(--surface);color:var(--ink-2);cursor:pointer;font-size:17px;line-height:1;
  display:grid;place-items:center}
.cotMasBtn:hover{border-color:var(--accent);color:var(--accent)}
.cotMenu{position:absolute;right:0;top:40px;z-index:40;min-width:186px;padding:6px;
  border:1px solid var(--line);border-radius:13px;background:var(--surface);
  box-shadow:0 18px 40px -20px rgba(0,0,0,.45)}
.cotMenu button{display:flex;align-items:center;gap:9px;width:100%;text-align:left;border:0;
  background:transparent;color:inherit;font:inherit;font-size:13px;padding:9px 11px;
  border-radius:9px;cursor:pointer}
.cotMenu button:hover{background:var(--surface-2)}
.cotMenu button.mal{color:var(--guinda-2)}
.cotMenu hr{border:0;border-top:1px solid var(--line);margin:5px 2px}
@media (max-width:720px){
  .cotFicha{grid-template-columns:1fr auto;gap:10px}
  .cotAcc{grid-column:1/-1;justify-content:flex-end}
}
"""

JS = r"""
/* ---------- cotizaciones, pedidos, facturas y cobranza ---------- */
let savFiltro = "todas";
const SAV_ET = {todas:"Todas", cot:"Cotizaciones", ped:"Pedidos",
                fac:"Facturas", cxc:"Por cobrar"};

/* Dónde está cada cotización. Una sola función, para que el azulejo, el
   contador y la ficha no puedan contar cosas distintas. */
function estadoCot(g){
  const esPedido  = g.estado === "confirmada" && !!g.op;
  const vendida   = ventas.some(v=>v.folio === g.folio);
  const f         = facturaDe(g);
  const facturada = !!(f && f.estado === "facturada");
  const porFact   = !!(f && f.estado !== "facturada");
  return {esPedido, vendida, facturada, porFact};
}
function savPasa(g, filtro){
  const e = estadoCot(g);
  if(filtro === "cot") return !e.esPedido;
  if(filtro === "ped") return e.esPedido;
  if(filtro === "fac") return e.facturada || e.porFact;
  if(filtro === "cxc") return e.vendida && !e.facturada;
  return true;
}
function savCuenta(filtro){ return guardadas.filter(g=>savPasa(g, filtro)).length; }

/* La acción que de verdad sigue. Un pedido listo se avisa; una cotización
   sin mandar se envía; lo vendido se factura. Lo demás baja al menú. */
function accionPrincipal(g){
  const e = estadoCot(g);
  if(e.esPedido && !e.vendida) return {et:"Avisar",  attr:'data-avisar="'+esc(g.folio)+'|entrega"',
                                       ti:"Avisarle que su pedido está listo"};
  if(e.vendida && !e.facturada) return {et:"Facturar", attr:'data-facturar="'+esc(g.folio)+'"', ti:""};
  if(!e.esPedido) return {et:"Enviar", attr:'data-enviar="'+esc(g.folio)+'"', ti:"Mandársela al cliente"};
  return {et:"Cobrar", attr:'data-cobrar="'+esc(g.folio)+'"', ti:""};
}

function renderSaved(){
  const lista = guardadas.slice().reverse().filter(g=>savPasa(g, savFiltro));
  const c = $("#savCount");
  if(c) c.textContent = lista.length + " de " + guardadas.length;
  const t = $("#savTitulo");
  if(t) t.textContent = SAV_ET[savFiltro] || "Cotizaciones y pedidos";
  if(typeof pintaLanzadorSec === "function") pintaLanzadorSec("sav");
  const w = $("#savedList"); if(!w) return;
  if(!guardadas.length){
    w.innerHTML = '<div class="empty">Aún no guardas cotizaciones. Arma una y presiona <b>Guardar</b>.</div>';
    return;
  }
  if(!lista.length){
    w.innerHTML = '<div class="empty">Nada en «'+esc(SAV_ET[savFiltro]||"")+'» por ahora.</div>';
    return;
  }
  w.innerHTML = lista.map(g=>{
    const e = estadoCot(g);
    const r = calcDe(g);
    const chips =
      (e.esPedido  ? '<span class="cotChip pedido">Pedido '+esc(g.op.folio)+'</span>' : '') +
      (e.vendida   ? '<span class="cotChip vendida">Vendida</span>' : '') +
      (e.facturada ? '<span class="cotChip facturada">Facturada</span>' :
       e.porFact   ? '<span class="cotChip porfact">Por facturar</span>' : '');
    const a = accionPrincipal(g);
    return '<div class="cotFicha">' +
      '<div class="cotQue"><b>'+esc(g.cliente||"Sin cliente")+'</b>' +
        '<small>'+esc(g.folio)+' · '+esc(g.fecha)+(g.ref? ' · '+esc(g.ref) : '')+' · ' +
          r.qty+' pzas'+(r.varios ? ' · '+r.partes.length+' artículos' : '')+'</small>' +
        (chips ? '<div class="cotChips">'+chips+'</div>' : '') + '</div>' +
      '<div class="cotMonto">'+mx(g._total||0)+'<i>total</i></div>' +
      '<div class="cotAcc">' +
        '<button class="btn sm" data-load="'+esc(g.folio)+'">Abrir</button>' +
        '<button class="btn sm primary" '+a.attr+(a.ti?' title="'+esc(a.ti)+'"':'')+'>'+esc(a.et)+'</button>' +
        '<span class="cotMas"><button class="cotMasBtn" data-cotmas="'+esc(g.folio)+'" ' +
          'aria-label="Más opciones">&#8943;</button></span>' +
      '</div></div>';
  }).join("");
}

/* El menú de los tres puntos. Se arma al abrirlo y no antes: así nunca
   ofrece «Ver orden» de un pedido que todavía no existe. */
function cierraMenusCot(){ document.querySelectorAll(".cotMenu").forEach(m=>m.remove()); }
document.addEventListener("click", e=>{
  const b = e.target.closest("[data-cotmas]");
  if(!b){ if(!e.target.closest(".cotMenu")) cierraMenusCot(); return; }
  const folio = b.dataset.cotmas;
  const abierto = b.parentElement.querySelector(".cotMenu");
  cierraMenusCot();
  if(abierto) return;
  const g = guardadas.find(x=>x.folio === folio); if(!g) return;
  const e2 = estadoCot(g);
  const m = document.createElement("div");
  m.className = "cotMenu";
  m.innerHTML =
    (e2.esPedido ? '<button data-verdoc-op="'+esc(folio)+'">Ver la orden</button>' : '') +
    '<button data-enviar="'+esc(folio)+'">Enviar al cliente</button>' +
    '<button data-facturar="'+esc(folio)+'">Facturar</button>' +
    '<button data-cobrar="'+esc(folio)+'">Cobrar</button>' +
    (e2.esPedido ? '<button data-avisar="'+esc(folio)+'|entrega">Avisar que está lista</button>' : '') +
    '<hr><button class="mal" data-delcot="'+esc(folio)+'">Borrar</button>';
  b.parentElement.appendChild(m);
});
"""
