# -*- coding: utf-8 -*-
"""Tres cosas que pidio Carlos:

   1. Dos modos y ya: Dia y Oscuro. Nueve paletas era un menu de decoracion
      en un programa de trabajo. Se quita Estudio —que yo acababa de meter—
      y el selector queda con dos tarjetas. Las demas paletas siguen en el
      codigo por si algun dia vuelven, pero no se ensenan.
   2. Los dibujos de articulo que hizo ChatGPT: una playera es una playera y
      no la letra P en un cuadrito.
   3. La luz que sigue al cursor dentro de cada boton."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


# ===================================================== 1. dos modos y ya
# fuera la paleta que yo habia metido
i = s.index('  estudio:  {nombre:"Estudio"')
j = s.index('  heymakers:{nombre:"Hey Makers"')
s = s[:i] + s[j:]
hechos.append("fuera la paleta Estudio")

uno(
"""const VIDRIOS   = [["nitido","Nítido"],["normal","Normal"],["vidrio","Vidrio"]];""",
"""/* Dos modos, no nueve paletas. Un taller no necesita escoger decoración:
   necesita ver bien de día y no quemarse los ojos de noche. Las demás
   paletas siguen arriba por si algún día vuelven, pero no se enseñan, y a
   quien tenía una escogida se le respeta el modo —claro o oscuro— que ya
   traía. El color de acento se sigue eligiendo aparte. */
const MODOS = [["papel","Día","el fondo claro, para el taller de día"],
               ["tecno","Oscuro","el fondo oscuro, para la noche y la pantalla grande"]];
const esModo = k => MODOS.some(m=>m[0]===k);
function modoDe(k){
  if(esModo(k)) return k;
  const t = TEMAS[k];
  return (t && t.modo === "light") ? "papel" : "tecno";
}
const VIDRIOS   = [["nitido","Nítido"],["normal","Normal"],["vidrio","Vidrio"]];""",
    "los dos modos")

uno(
"""function leeTema(){
  try{
    const crudo = JSON.parse(localStorage.getItem(LS_TEMA)||"null") || {};
    return migraTema(Object.assign(temaPorOmision(), crudo), crudo);
  }catch(e){ return temaPorOmision(); }
}""",
"""function leeTema(){
  try{
    const crudo = JSON.parse(localStorage.getItem(LS_TEMA)||"null") || {};
    const t = migraTema(Object.assign(temaPorOmision(), crudo), crudo);
    /* Quien traía Guinda, Océano o cualquier otra se queda en el modo que
       esa paleta tenía: claro con claro, oscuro con oscuro. Nadie abre el
       programa y se lo encuentra del otro color. */
    t.preset = modoDe(t.preset);
    return t;
  }catch(e){ return temaPorOmision(); }
}""",
    "las paletas viejas caen en su modo")

uno(
"""  const rej = $("#temaRejilla"); if(!rej) return;
  rej.innerHTML = Object.keys(TEMAS).map(k=>{
    const t = TEMAS[k];
    return '<button type="button" class="temaCard" data-tema="'+k+'" aria-pressed="'+(TEMA.preset===k)+'">'+
      '<span class="temaMuestra">'+t.amb.map(c=>'<i style="background:'+c+'"></i>').join("")+
        '<i style="background:'+t.acento+';flex:1.4"></i></span>'+
      '<b>'+esc(t.nombre)+'</b></button>';
  }).join("");""",
"""  const rej = $("#temaRejilla"); if(!rej) return;
  rej.innerHTML = MODOS.map(m=>{
    const k = m[0], t = TEMAS[k];
    return '<button type="button" class="temaCard" data-tema="'+k+'" aria-pressed="'+(TEMA.preset===k)+'">'+
      '<span class="temaMuestra">'+t.amb.map(c=>'<i style="background:'+c+'"></i>').join("")+
        '<i style="background:'+t.acento+';flex:1.4"></i></span>'+
      '<b>'+esc(m[1])+'</b><small>'+esc(m[2])+'</small></button>';
  }).join("");""",
    "el selector enseña dos tarjetas")

uno(
""".temaCard{""",
""".temaCard small{display:block;margin-top:3px;font-size:11px;font-weight:400;color:var(--ink-3);line-height:1.35}
.temaCard{""",
    "la tarjeta de modo lleva su explicación")

# ============================== 2. los dibujos de articulo de ChatGPT
uno(
"""function miniArt(a, clase){
  const f = fotoDe(a);
  return f
    ? '<img class="'+(clase||"artMini")+'" src="'+esc(f)+'" alt="'+esc(a.nombre||"")+'" loading="lazy">'
    : '<span class="'+(clase||"artMini")+' artSinFoto" aria-hidden="true">'+
      esc(((a&&a.nombre)||"?").trim().charAt(0).toUpperCase())+'</span>';
}""",
"""/* El dibujo de cada artículo. Sin foto, antes salía la inicial en un
   cuadrito: dieciséis cuadritos con letras no se leen de un vistazo. Estos
   dibujos son los que hizo ChatGPT y se escogen por lo que dice el nombre
   o la familia, así que un artículo capturado a mano también lo recibe.
   Llevan color propio a propósito —como un emoji—: se ven igual en los dos
   modos y no compiten con el acento del taller. */
const ART_SIN_ACENTO = s => String(s||"").toLowerCase()
  .normalize("NFD").replace(/[\\u0300-\\u036f]/g, "");
const ART_DIBUJOS = [
  [/taza|termo|anfora|vaso|tarro/,
   '<path fill="#b9a8ed" stroke="#65528f" stroke-width="1.1" d="M6 7h11v10a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3z"/><path fill="none" stroke="#65528f" stroke-width="1.4" d="M17 10h2a3 3 0 0 1 0 6h-2M9 4h5"/><path fill="none" stroke="#eee8ff" stroke-width="1.3" d="M8 9v7"/>'],
  [/gorra|cap\\b|visera/,
   '<path fill="#f4a782" stroke="#93513c" stroke-width="1.1" d="M3 15h18l-3 3H7a4 4 0 0 1-4-3Z"/><path fill="#ffd2ae" stroke="#93513c" stroke-width="1.1" d="M5 15a7 7 0 0 1 14 0z"/><path fill="none" stroke="#93513c" stroke-width="1.2" d="M11 8V5"/>'],
  [/tote|bolsa|morral|mochila/,
   '<path fill="#e6b578" stroke="#805a34" stroke-width="1.1" d="M5 9h14l1 12H4z"/><path fill="none" stroke="#805a34" stroke-width="1.4" d="M8 9V6a4 4 0 0 1 8 0v3"/><path fill="none" stroke="#ffe5bd" stroke-width="1.2" d="M7 11h10"/>'],
  [/sudader|hoodie|chamarra/,
   '<path fill="#d99b72" stroke="#80533f" stroke-width="1.1" d="m8 5-4.4 2.4L5 13l3-1v8.5h8V12l3 1 1.4-5.6L16 5c-.4 2-1.8 3.1-4 3.1S8.4 7 8 5Z"/><path fill="#f1c3a5" stroke="#80533f" stroke-width="1" d="M8.7 5.1C9 2.9 10.3 1.8 12 1.8s3 1.1 3.3 3.3c-.8 1.3-1.9 2-3.3 2s-2.5-.7-3.3-2Z"/><path fill="none" stroke="#80533f" stroke-width="1" d="m10 7 1 3m3-3-1 3"/><path fill="#efbd99" stroke="#80533f" stroke-width=".9" d="M9 15h6v3H9z"/>'],
  [/playera|camiseta|polo|textil|camisa/,
   '<path fill="#92d47a" stroke="#386c48" stroke-width="1.1" d="m8 4-5 3 2 5 3-1v9h8v-9l3 1 2-5-5-3-3 2a3 3 0 0 1-5 0Z"/><path fill="none" stroke="#386c48" stroke-width="1.1" d="M9 4c.4 1.5 1.4 2.3 3 2.3S14.6 5.5 15 4"/><path fill="none" stroke="#dff4d2" stroke-width="1.2" d="M8.5 16h7"/>'],
  [/lona|vinil|rollo|papel|couche/,
   '<path fill="#8fc5e8" stroke="#2f5f80" stroke-width="1.1" d="M4 6h16v12H4z"/><path fill="none" stroke="#2f5f80" stroke-width="1.2" d="M8 6v12M16 6v12"/><path fill="none" stroke="#e3f3ff" stroke-width="1.2" d="M6 9h1m9 0h1"/>'],
  [/llavero|funda|mousepad|promo/,
   '<path fill="#f2cf74" stroke="#8a6a1c" stroke-width="1.1" d="M9 4h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"/><path fill="none" stroke="#8a6a1c" stroke-width="1.2" d="M11 6h2"/><circle cx="12" cy="18" r="1.3" fill="#fff6d8"/>']
];
function dibujoArt(a){
  const n = ART_SIN_ACENTO(((a&&a.cat)||"") + " " + ((a&&a.nombre)||""));
  for(let i=0;i<ART_DIBUJOS.length;i++){ if(ART_DIBUJOS[i][0].test(n)) return ART_DIBUJOS[i][1]; }
  /* Lo que no se parece a nada: una caja. Mejor una caja honesta que una
     playera que no es. */
  return '<path fill="#83d9cb" stroke="#347c73" stroke-width="1.1" d="M5 7.5 12 4l7 3.5v9L12 20l-7-3.5z"/>' +
         '<path fill="none" stroke="#347c73" stroke-width="1.1" d="m5.5 8 6.5 3.5L18.5 8M12 11.5V20"/>' +
         '<path fill="none" stroke="#d8fff4" stroke-width="1.1" d="m8 6 4 2 4-2"/>';
}
function miniArt(a, clase){
  const f = fotoDe(a);
  if(f) return '<img class="'+(clase||"artMini")+'" src="'+esc(f)+'" alt="'+esc(a.nombre||"")+'" loading="lazy">';
  return '<span class="'+(clase||"artMini")+' artDibujo" aria-hidden="true">' +
    '<svg viewBox="0 0 24 24">'+dibujoArt(a)+'</svg></span>';
}""",
    "los dibujos de artículo")

uno(
""".gotaIns{display:inline-block""",
""".artDibujo{display:grid;place-items:center;background:var(--surface-2);
  box-shadow:inset 0 0 0 1px var(--line-soft)}
.artDibujo svg{width:66%;height:66%;max-width:64px;max-height:64px;
  stroke-linecap:round;stroke-linejoin:round}
.azIt .artDibujo{width:100%;height:62px;border-radius:9px}
.gotaIns{display:inline-block""",
    "los estilos del dibujo")

# ======================================= 3. la luz que sigue al cursor
uno(
"""/* ---- detalles de diseño ---- */""",
"""/* ---- la luz que sigue al cursor ---- */
/* Es de ChatGPT y está bien pensada: en vez de un brillo fijo, el botón se
   ilumina justo donde está el puntero. Aquí usa el acento del taller en vez
   de un verde escrito a mano, para que valga en los dos modos. */
.lucecita{position:relative;isolation:isolate;overflow:hidden}
.lucecita>.luz{position:absolute;z-index:-1;inset:-1px;display:block;
  border-radius:inherit;pointer-events:none;opacity:0;transform:scale(.96);
  background:radial-gradient(170px circle at var(--luz-x,50%) var(--luz-y,50%),
    color-mix(in srgb, var(--accent) 34%, transparent) 0%,
    color-mix(in srgb, var(--accent) 16%, transparent) 42%, transparent 78%);
  transition:opacity .2s, transform .38s cubic-bezier(.2,.8,.25,1)}
.lucecita:hover>.luz,.lucecita:focus-visible>.luz{opacity:1;transform:scale(1.08)}
.lucecita>:not(.luz){position:relative;z-index:1}
@media (prefers-reduced-motion: reduce){ .lucecita>.luz{transition:none!important} }

/* ---- detalles de diseño ---- */""",
    "los estilos de la luz del cursor")

uno(
"""/* ============ LOS AZULEJOS DEL COTIZADOR ============""",
"""/* ============ LA LUZ QUE SIGUE AL CURSOR ============
   Tomada del archivo de ChatGPT. Se cuelga UNA vez del documento y vale
   para los botones que nazcan después, que en este programa son casi
   todos. En pantalla táctil no hace nada: ahí no hay puntero que seguir. */
function prendeLuz(b){
  if(!b.querySelector(":scope > .luz")){
    const l = document.createElement("span");
    l.className = "luz"; l.setAttribute("aria-hidden", "true");
    b.prepend(l);
  }
  b.classList.add("lucecita");
}
function sigueElCursor(e){
  if(e.pointerType === "touch") return;
  const b = e.target && e.target.closest(
    "button.btn, .lzApp, .azIt, .cpAz, .arrOpc, .tbAcceso, .temaCard");
  if(!b || b.disabled) return;
  const r = b.getBoundingClientRect();
  prendeLuz(b);
  b.style.setProperty("--luz-x", (e.clientX - r.left) + "px");
  b.style.setProperty("--luz-y", (e.clientY - r.top) + "px");
}
document.addEventListener("pointerover", sigueElCursor);
document.addEventListener("pointermove", sigueElCursor);
document.addEventListener("focusin", e=>{
  const b = e.target && e.target.closest(
    "button.btn, .lzApp, .azIt, .cpAz, .arrOpc, .tbAcceso, .temaCard");
  if(b && !b.disabled) prendeLuz(b);
});

/* ============ LOS AZULEJOS DEL COTIZADOR ============""",
    "la luz del cursor")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
