# -*- coding: utf-8 -*-
"""Cotizar por pasos: un interruptor en Ajustes, la pantalla de siempre debajo.

   No es un cotizador nuevo. Son LOS MISMOS campos de siempre, con los pasos
   que ya traian numero, nada mas que de uno en uno y sin poder saltarse lo
   que falta. Apagando el interruptor todo vuelve a quedar como hoy, porque
   nunca se movio nada de su lugar."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


# ------------------------------------------------------------------ estilos
uno(
""".cpGanar .f{display:block;margin-bottom:8px}""",
"""/* ---- cotizar por pasos ---- */
body.cotGuiado [data-paso].guiaFuturo{display:none}
body.cotGuiado [data-paso].guiaHecho>header{opacity:.78}
body.cotGuiado [data-paso]{scroll-margin-top:90px}
.guiaTira{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 14px;
  padding:11px 14px;border:1.5px solid var(--line);border-radius:14px;background:var(--surface-2)}
.guiaTira .guiaP{display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--ink-3);
  background:none;border:0;font:inherit;padding:3px 4px;border-radius:8px;cursor:default}
.guiaTira .guiaP.hecho{cursor:pointer;color:var(--ink-2)}
.guiaTira .guiaP.hecho:hover{color:var(--accent)}
.guiaTira .guiaP i{width:20px;height:20px;border-radius:50%;display:grid;place-items:center;
  font-style:normal;font-size:11px;font-weight:700;background:var(--surface);
  border:1.5px solid var(--line);color:var(--ink-3)}
.guiaTira .guiaP.activo{color:var(--ink);font-weight:600}
.guiaTira .guiaP.activo i{background:var(--accent);border-color:var(--accent);color:#fff}
.guiaTira .guiaP.hecho i{background:var(--good);border-color:var(--good);color:#fff}
.guiaTira .guiaSep{color:var(--ink-3);opacity:.5}
.guiaPie{display:flex;align-items:center;gap:10px;flex-wrap:wrap;
  border-top:1px solid var(--line);margin:4px 16px 0;padding:14px 0 16px}
.guiaPie .guiaFalta{color:var(--warn);font-size:12.5px;margin-right:auto}
.guiaPie .guiaOk{color:var(--ink-3);font-size:12.5px;margin-right:auto}
@media(max-width:560px){
  .guiaTira{gap:5px;padding:9px 10px}
  .guiaTira .guiaP span{display:none}
  .guiaTira .guiaP.activo span{display:inline}
}
.cpGanar .f{display:block;margin-bottom:8px}""",
    "los estilos de cotizar por pasos")

# ------------------------------------------------------------------- ajustes
uno(
"""  <div class="card secOculta" data-set="tema">""",
"""  <div class="card secOculta" data-set="cotizar">
    <header><h2>Cómo se cotiza</h2><span class="hint">la pantalla de cotizar, a tu modo</span></header>
    <div class="body">
      <p class="note" style="margin:0 0 14px">La pantalla de cotizar es la misma en los dos modos: los mismos campos, el mismo armado, los mismos botones. Lo único que cambia es si te los enseña <b>todos juntos</b> o <b>de uno en uno</b>.</p>
      <label class="sw"><input type="checkbox" id="p_guiado"> <b>Cotizar por pasos</b></label>
      <p class="note" style="margin:12px 0 0">Con esto prendido, la cotización va de un paso al siguiente y no deja seguir hasta que llenes lo que falta. Cada paso que terminas se cierra solo y deja su resumen a la vista. Sirve para quien apenas entra al programa, o para el vendedor nuevo. Si ya te sabes la pantalla de memoria, déjalo apagado: así ves todo de un golpe, como hasta hoy.</p>
    </div>
  </div>

  <div class="card secOculta" data-set="tema">""",
    "la tarjeta de Ajustes con el interruptor")

uno(
"""  {id:"tema", nombre:"Apariencia", sub:"tema claro u oscuro", color:"#14B8A6",""",
"""  {id:"cotizar", nombre:"Cómo se cotiza", sub:"todo junto o paso a paso", color:"#D6127F",
   icono:'<path d="M4 6h16M4 12h10M4 18h6"/><circle cx="19" cy="15" r="3"/>',
   card:'[data-set="cotizar"]'},
  {id:"tema", nombre:"Apariencia", sub:"tema claro u oscuro", color:"#14B8A6",""",
    "el azulejo de cómo se cotiza")

# ----------------------------------------------------------------- el motor
MOTOR = r"""
/* ==================== COTIZAR POR PASOS ====================
   Los mismos campos de siempre, de uno en uno. El interruptor vive en
   Ajustes y se guarda con los demás parámetros, así que vale para toda la
   cuenta: si el dueño lo prende, el vendedor nuevo lo encuentra prendido. */
const GUIA_ORDEN = ["cliente","articulo","apps","tallas","extras","prod"];
const GUIA_NOMBRE = {cliente:"Cliente", articulo:"Artículo", apps:"Decorado",
                     tallas:"Tallas", extras:"Extras", prod:"Entrega"};
let GUIA = {actual:"cliente"};
const guiado = () => !!P.guiado;

/* Las tallas sólo salen cuando el artículo las usa: preguntarle las tallas
   a una taza es hacerle perder el tiempo a quien cotiza. */
function guiaPasos(){
  return GUIA_ORDEN.filter(k=>{
    if(k !== "tallas") return true;
    try{ return esTextil(cot); }catch(e){ return true; }
  });
}
function guiaFalta(k){
  const q = Math.max(0, usaTallas(cot) ? sumaTallas(cot) : Math.round(num(cot.cantidad,0)));
  if(k === "cliente")  return (cot.cliente||"").trim() ? "" : "Escribe para quién es la cotización";
  if(k === "articulo"){
    if(!(cot.articuloId || (cot.desc||"").trim())) return "Escoge el artículo o escribe qué se va a hacer";
    return q > 0 ? "" : "¿Cuántas piezas son?";
  }
  if(k === "tallas") return q > 0 ? "" : "Captura al menos un renglón de tallas";
  return "";
}
function guiaTira(){
  const ps = guiaPasos(), i = ps.indexOf(GUIA.actual);
  return '<div class="guiaTira" id="guiaTira">' + ps.map((k,n)=>{
    const est = k === GUIA.actual ? "activo" : (n < i ? "hecho" : "");
    return (n ? '<span class="guiaSep" aria-hidden="true">›</span>' : '') +
      '<button type="button" class="guiaP '+est+'" data-guiair="'+k+'"'+
      (est==="hecho" ? '' : ' disabled')+'>'+
      '<i>'+(est==="hecho" ? "✓" : (n+1))+'</i><span>'+GUIA_NOMBRE[k]+'</span></button>';
  }).join("") + '</div>';
}
function guiaPinta(){
  const sec = document.getElementById("tab-cot"); if(!sec) return;
  const col = sec.querySelector(".cols > div"); if(!col) return;
  document.body.classList.toggle("cotGuiado", guiado());
  let tira = document.getElementById("guiaTira");
  if(!guiado()){
    if(tira) tira.remove();
    sec.querySelectorAll("[data-paso]").forEach(c=>{
      c.classList.remove("guiaFuturo","guiaHecho");
      const pie = c.querySelector(".guiaPie"); if(pie) pie.remove();
    });
    if(typeof arrancaPasos === "function") arrancaPasos();
    return;
  }
  const ps = guiaPasos();
  if(ps.indexOf(GUIA.actual) < 0) GUIA.actual = ps[0];
  const i = ps.indexOf(GUIA.actual);
  /* La tira se vuelve a escribir entera: son seis botones, no cuesta nada,
     y así nunca se queda una palomita donde ya no va. */
  if(!tira) col.insertAdjacentHTML("afterbegin", guiaTira());
  else      tira.outerHTML = guiaTira();

  sec.querySelectorAll("[data-paso]").forEach(c=>{
    const k = c.dataset.paso, n = ps.indexOf(k);
    const pie = c.querySelector(".guiaPie"); if(pie) pie.remove();
    c.classList.remove("guiaFuturo","guiaHecho");
    if(n < 0 || n > i){ c.classList.add("guiaFuturo"); return; }
    if(n < i){ c.classList.add("guiaHecho","cerrado"); return; }
    c.classList.remove("cerrado");
    const falta = guiaFalta(k);
    const ultimo = i === ps.length - 1;
    c.insertAdjacentHTML("beforeend",
      '<div class="guiaPie">' +
        (falta ? '<span class="guiaFalta">'+esc(falta)+'</span>'
               : '<span class="guiaOk">'+(ultimo ? "Ya está: abajo tienes el total y los botones."
                                                 : "Listo. Puedes seguir.")+'</span>') +
        (i > 0 ? '<button class="btn ghost" data-guiair="'+ps[i-1]+'">Atrás</button>' : '') +
        (ultimo ? '' :
          '<button class="btn primary" data-guiasig="'+ps[i+1]+'"'+(falta?" disabled":"")+'>Continuar</button>') +
      '</div>');
  });
  if(typeof resumenPasos === "function") resumenPasos();
}
/* Mientras se escribe, el aviso y el botón de Continuar se refrescan sin
   volver a dibujar el paso: si lo redibujara, se perdería el cursor. */
function guiaRevisa(){
  if(!guiado()) return;
  const sec = document.getElementById("tab-cot"); if(!sec) return;
  const c = sec.querySelector('[data-paso="'+GUIA.actual+'"]'); if(!c) return;
  const ps = guiaPasos();
  /* El artículo decide si hay paso de tallas; si cambió, la tira cambia. */
  const tira = document.getElementById("guiaTira");
  if(tira && tira.querySelectorAll("[data-guiair]").length !== ps.length){ guiaPinta(); return; }
  const falta = guiaFalta(GUIA.actual);
  const ultimo = ps.indexOf(GUIA.actual) === ps.length - 1;
  const av = c.querySelector(".guiaFalta, .guiaOk");
  if(av){
    av.className = falta ? "guiaFalta" : "guiaOk";
    av.textContent = falta || (ultimo ? "Ya está: abajo tienes el total y los botones." : "Listo. Puedes seguir.");
  }
  const btn = c.querySelector("[data-guiasig]");
  if(btn) btn.disabled = !!falta;
}
function guiaVaA(k){
  GUIA.actual = k;
  guiaPinta();
  const c = document.querySelector('[data-paso="'+k+'"]');
  if(c) c.scrollIntoView({behavior:"smooth", block:"start"});
}
document.addEventListener("click", e=>{
  const sig = e.target.closest("[data-guiasig]");
  if(sig && !sig.disabled){ guiaVaA(sig.dataset.guiasig); return; }
  const ir = e.target.closest("[data-guiair]");
  if(ir && !ir.disabled){ guiaVaA(ir.dataset.guiair); return; }
  /* En modo guiado, abrir un paso ya hecho es volver a él. */
  if(guiado()){
    const h = e.target.closest("[data-paso] > header");
    if(h && !e.target.closest("button:not(.chev)") && !e.target.closest("input,select")){
      const c = h.parentElement;
      if(c.classList.contains("guiaHecho")) guiaVaA(c.dataset.paso);
    }
  }
});
document.addEventListener("input",  e=>{ if(e.target.closest("#tab-cot")) guiaRevisa(); });
document.addEventListener("change", e=>{ if(e.target.closest("#tab-cot")) guiaRevisa(); });
"""

uno(
"""function pon(clave, txt){ const e = document.querySelector('[data-res="'+clave+'"]'); if(e) e.textContent = txt; }""",
MOTOR + """
function pon(clave, txt){ const e = document.querySelector('[data-res="'+clave+'"]'); if(e) e.textContent = txt; }""",
    "el motor de cotizar por pasos")

# --------------------------------------------------- el parametro arranca off
uno(
"""function defaultParams(){ return {plazoCobro:15,""",
"""function defaultParams(){ return {guiado:false,plazoCobro:15,""",
    "el interruptor nace apagado")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
