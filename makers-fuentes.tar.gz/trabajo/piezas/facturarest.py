# -*- coding: utf-8 -*-
"""Facturacion dentro del restaurante, la misma del cotizador.

   «Todos los sistemas POS deben llevar lo mismo». En un restaurante la
   factura no nace con la venta: el cliente paga, se va, y regresa —o manda
   a alguien— con el ticket en la mano. Por eso aqui no se pregunta al
   cobrar: se factura DESPUES, buscando el folio del ticket.

   Lo que se guarda es lo mismo que en el cotizador: los datos del emisor en
   Ajustes y los del receptor pegados al ticket, con su estado (pendiente o
   ya timbrada). El paquete impreso trae emisor, receptor, desglose de IVA y
   el concepto; es lo que el contador necesita para timbrar."""

HTML_SET = """  <div class="card secOculta" data-set="fiscal">
    <header><h2>Facturación</h2><span class="hint">con qué datos emites tus facturas</span></header>
    <div class="body">
      <p class="note" style="margin:0 0 14px">Esto es lo <b>tuyo</b>: lo que va arriba de cada factura.
        Los datos del cliente se piden al facturar cada ticket, en <b>Ventas</b>.</p>
      <div class="grid g2">
        <div><label class="f" for="fx_razon">Razón social</label>
          <input id="fx_razon" placeholder="Como está en tu constancia del SAT"></div>
        <div><label class="f" for="fx_rfc">RFC</label>
          <input id="fx_rfc" placeholder="XAXX010101000" style="text-transform:uppercase" maxlength="13"></div>
      </div>
      <div class="grid g2" style="margin-top:10px">
        <div><label class="f" for="fx_regimen">Régimen fiscal</label><select id="fx_regimen"></select></div>
        <div><label class="f" for="fx_cp">Código postal fiscal</label>
          <input id="fx_cp" inputmode="numeric" maxlength="5" placeholder="58000"></div>
      </div>
      <p class="note" style="margin-top:10px">El código postal fiscal es el <b>lugar de expedición</b>.
        Si no coincide con tu constancia, el SAT rechaza el timbrado.</p>
      <div class="note" style="margin-top:14px;border-left-color:var(--warn)">
        <b>Tus sellos del SAT no se guardan aquí, y es a propósito.</b> Tu archivo .cer, tu .key y la
        contraseña de tu llave son tu firma: quien los tiene puede facturar a tu nombre. Se suben
        directo con el PAC, que es quien está autorizado por el SAT para guardarlos y timbrar.
        Este programa nunca los ve ni los pide.
      </div>
      <div class="grid g3" style="margin-top:14px">
        <div><label class="f" for="fx_pac">Tu PAC</label><select id="fx_pac">
          <option value="">— Todavía no elijo —</option>
          <option value="facturama">Facturama</option>
          <option value="facturapi">Facturapi</option>
          <option value="sw">SW sapien (Smarter Web)</option>
          <option value="finkok">Finkok</option>
          <option value="prodigia">Prodigia</option>
          <option value="otro">Otro</option>
        </select></div>
        <div><label class="f" for="fx_serie">Serie</label><input id="fx_serie" maxlength="8" placeholder="A"></div>
        <div><label class="f" for="fx_folio">Siguiente folio</label>
          <input id="fx_folio" type="number" min="1" step="1"></div>
      </div>
      <label class="sw" style="margin-top:14px"><input type="checkbox" id="fx_sellos">
        Ya di de alta mis sellos con mi PAC</label>
      <p class="note" id="fxNota" style="margin-top:12px"></p>
    </div>
  </div>
"""

HTML_VEN = """  <div class="card secOculta" data-ven="factura">
    <header><h2>Facturas</h2><span class="hint" id="facHint"></span></header>
    <div class="body">
      <p class="note" style="margin:0 0 14px">El cliente regresa con su ticket y te pide factura.
        Busca su <b>folio</b>, captura su RFC y queda guardada pegada a esa venta. Mientras no la
        timbres se queda en <b>pendiente</b>, para que al cierre del mes sepas cuáles faltan.</p>
      <div class="fila" style="margin-bottom:12px">
        <input id="facBusca" placeholder="Buscar folio, mesa o RFC" style="max-width:300px">
        <button class="btn sm" data-facfiltro="pend" id="facFPend">Por timbrar</button>
        <button class="btn sm" data-facfiltro="hechas">Timbradas</button>
        <button class="btn sm" data-facfiltro="todas">Todas las ventas</button>
      </div>
      <div class="tbl-wrap"><table id="t_facturas"></table></div>
    </div>
  </div>
"""

HTML_MODAL = """<div class="modal" id="modalFacRest" hidden>
  <div class="card" style="width:min(560px,100%)">
    <header><h2>Facturar un ticket</h2>
      <button class="btn sm" id="fr_cancel" style="margin-left:auto">Cerrar</button></header>
    <div class="body">
      <p class="note" id="fr_resumen" style="margin:0 0 14px"></p>
      <div class="grid g2">
        <div><label class="f" for="fr_rfc">RFC del cliente</label>
          <input id="fr_rfc" style="text-transform:uppercase" maxlength="13" placeholder="XAXX010101000"></div>
        <div><label class="f" for="fr_cp">Código postal</label>
          <input id="fr_cp" inputmode="numeric" maxlength="5"></div>
      </div>
      <div style="margin-top:10px"><label class="f" for="fr_razon">Razón social</label>
        <input id="fr_razon" placeholder="Como viene en su constancia"></div>
      <div class="grid g2" style="margin-top:10px">
        <div><label class="f" for="fr_regimen">Régimen fiscal</label><select id="fr_regimen"></select></div>
        <div><label class="f" for="fr_uso">Uso del CFDI</label><select id="fr_uso"></select></div>
      </div>
      <div class="grid g3" style="margin-top:10px">
        <div><label class="f" for="fr_forma">Forma de pago</label><select id="fr_forma"></select></div>
        <div><label class="f" for="fr_metodo">Método</label><select id="fr_metodo">
          <option value="PUE">PUE — una exhibición</option>
          <option value="PPD">PPD — en parcialidades</option></select></div>
        <div><label class="f" for="fr_fecha">Fecha</label><input id="fr_fecha" type="date"></div>
      </div>
      <div style="margin-top:10px"><label class="f" for="fr_uuid">Folio fiscal (UUID), si ya la timbraste</label>
        <input id="fr_uuid" placeholder="Déjalo vacío si todavía no la timbras"></div>
      <div class="fila" style="margin-top:18px">
        <button class="btn primary" id="fr_ok">Guardar y ver los datos</button>
        <button class="btn" id="fr_quita" hidden>Quitar la factura</button>
      </div>
    </div>
  </div>
</div>
"""

JS = r"""
/* ============ FACTURACIÓN ============ */
/* Los catálogos del SAT son los mismos del cotizador: si cambian, cambian
   en los dos. No se abrevian —un régimen de menos es una factura que el
   PAC rechaza. */
const REGIMENES = [["601","General de Ley Personas Morales"],["603","Personas Morales con Fines no Lucrativos"],
 ["605","Sueldos y Salarios"],["606","Arrendamiento"],["607","Enajenación o Adquisición de Bienes"],
 ["608","Demás ingresos"],["610","Residentes en el Extranjero"],["611","Dividendos"],
 ["612","Personas Físicas con Actividades Empresariales y Profesionales"],["614","Ingresos por Intereses"],
 ["616","Sin obligaciones fiscales"],["620","Sociedades Cooperativas de Producción"],["621","Incorporación Fiscal"],
 ["622","Actividades Agrícolas, Ganaderas, Silvícolas y Pesqueras"],["623","Opcional para Grupos de Sociedades"],
 ["624","Coordinados"],["625","Plataformas Tecnológicas"],["626","Régimen Simplificado de Confianza"]];
const USOS_CFDI = [["G01","Adquisición de mercancías"],["G02","Devoluciones y descuentos"],["G03","Gastos en general"],
 ["D01","Honorarios médicos"],["I02","Mobiliario y equipo de oficina"],
 ["P01","Por definir"],["S01","Sin efectos fiscales"],["CP01","Pagos"]];
/* En un restaurante lo que hay son estas cuatro. «app» es depósito: el
   dinero llega de la plataforma, no de la mano del comensal. */
const FORMAS_SAT = [["01","Efectivo"],["03","Transferencia electrónica"],["04","Tarjeta de crédito"],
                    ["28","Tarjeta de débito"],["99","Por definir"]];
const FORMA_DE_PAGO = {efectivo:"01", tarjeta:"04", transferencia:"03", app:"03"};
function opcSAT(pares, sel){
  return pares.map(p=>'<option value="'+esc(p[0])+'"'+(p[0]===sel?" selected":"")+'>'+
    esc(p[0])+" — "+esc(p[1])+'</option>').join("");
}
/* Devuelve SIEMPRE el mismo objeto. Antes armaba uno nuevo con
   Object.assign y se lo colgaba a P.fiscal: quien ya tenia la referencia
   anterior le escribia a un huerfano, y por eso el folio de la factura
   nunca avanzaba. */
function fiscalRest(){
  const d = {razon:"", rfc:"", regimen:"612", cpFiscal:"",
             pac:"", serie:"A", folioFactura:1, sellosAlta:false};
  if(!P.fiscal || typeof P.fiscal !== "object") P.fiscal = {};
  Object.keys(d).forEach(k=>{ if(P.fiscal[k] === undefined) P.fiscal[k] = d[k]; });
  return P.fiscal;
}
function faltaParaFacturarRest(){
  const E = fiscalRest(), f = [];
  if(!String(E.razon||"").trim()) f.push("la razón social");
  if(String(E.rfc||"").trim().length < 12) f.push("el RFC");
  if(String(E.cpFiscal||"").trim().length !== 5) f.push("el código postal fiscal");
  return f;
}
function folioFacturaRest(){
  const E = fiscalRest(), n = num(E.folioFactura, 0);
  if(!n) return E.serie || "";
  return (E.serie||"") + "-" + String(n).padStart(digitosFolio(), "0");
}
function pintaNotaFiscal(){
  const n = $("#fxNota"); if(!n) return;
  const falta = faltaParaFacturarRest(), E = fiscalRest();
  if(falta.length){
    n.innerHTML = "Te falta capturar <b>" +
      esc(falta.join(", ").replace(/, ([^,]*)$/, " y $1")) + "</b>. Sin eso el SAT no timbra.";
    n.style.borderLeftColor = "var(--mal)";
    return;
  }
  n.style.borderLeftColor = "";
  n.innerHTML = "Tu próxima factura saldría como <b>" + esc(folioFacturaRest()) + "</b>" +
    (E.sellosAlta ? "." : ", pero todavía no marcas que diste de alta tus sellos con tu PAC.");
}
function renderSetFiscal(){
  const E = fiscalRest();
  $("#fx_regimen").innerHTML = opcSAT(REGIMENES, E.regimen || "612");
  $("#fx_razon").value = E.razon || "";
  $("#fx_rfc").value   = E.rfc || "";
  $("#fx_cp").value    = E.cpFiscal || "";
  $("#fx_pac").value   = E.pac || "";
  $("#fx_serie").value = E.serie || "A";
  $("#fx_folio").value = num(E.folioFactura, 1);
  $("#fx_sellos").checked = !!E.sellosAlta;
  pintaNotaFiscal();
}
$("#tab-set").addEventListener("input", e=>{
  const t = e.target, E = fiscalRest();
  if(t.id === "fx_razon"){ E.razon = t.value; pintaNotaFiscal(); persist(); return; }
  if(t.id === "fx_rfc"){ E.rfc = String(t.value||"").toUpperCase().trim(); t.value = E.rfc;
                         pintaNotaFiscal(); persist(); return; }
  if(t.id === "fx_cp"){ E.cpFiscal = String(t.value||"").replace(/[^0-9]/g,"").slice(0,5);
                        t.value = E.cpFiscal; pintaNotaFiscal(); persist(); return; }
  if(t.id === "fx_serie"){ E.serie = t.value; pintaNotaFiscal(); persist(); return; }
  if(t.id === "fx_folio"){ E.folioFactura = Math.max(1, num(t.value,1)); pintaNotaFiscal(); persist(); return; }
});
$("#tab-set").addEventListener("change", e=>{
  const t = e.target, E = fiscalRest();
  if(t.id === "fx_regimen"){ E.regimen = t.value; persist(); return; }
  if(t.id === "fx_pac"){ E.pac = t.value; pintaNotaFiscal(); persist(); return; }
  if(t.id === "fx_sellos"){ E.sellosAlta = t.checked; pintaNotaFiscal(); persist(); return; }
});

/* ---------- la lista de Ventas ---------- */
let facFiltro = "pend", facFolio = null;
const facturaDeTicket = c => (c && c.factura && c.factura.requiere) ? c.factura : null;
const vendidas = () => cerradasTodas().filter(c=>!c.cancelada);
const facturadas  = () => vendidas().filter(c=>{
  const f = facturaDeTicket(c); return f && f.estado === "facturada";
});
const porFacturar = () => vendidas().filter(c=>{
  const f = facturaDeTicket(c); return f && f.estado !== "facturada";
});
function facLista(){
  const q = ($("#facBusca") ? ($("#facBusca").value||"") : "").toLowerCase().trim();
  let base = facFiltro === "pend"   ? porFacturar()
           : facFiltro === "hechas" ? facturadas()
           :                          vendidas();
  if(q) base = base.filter(c=>{
    const f = c.factura || {};
    return ((c.folio||"") + " " + (c.mesaNombre||"") + " " + (f.rfc||"") + " " + (f.razon||""))
      .toLowerCase().indexOf(q) >= 0;
  });
  return base.slice().sort((a,b)=> String(b.fecha+b.cierra).localeCompare(String(a.fecha+a.cierra)));
}
function renderFacturas(){
  const t = $("#t_facturas"); if(!t) return;
  $$("[data-facfiltro]").forEach(b=> b.classList.toggle("primary", b.dataset.facfiltro === facFiltro));
  const pend = porFacturar().length, hechas = facturadas().length;
  const h = $("#facHint");
  if(h) h.textContent = pend ? pend + " por timbrar · " + hechas + " timbrada(s)"
                             : (hechas ? hechas + " timbrada(s)" : "todavía ninguna");
  const lista = facLista();
  t.innerHTML = '<thead><tr><th>Folio</th><th>Fecha</th><th>Mesa</th><th>RFC</th><th>Razón social</th>' +
    '<th class="der">Total</th><th>Estado</th><th style="width:170px"></th></tr></thead><tbody>' +
    (lista.length ? lista.slice(0,200).map(c=>{
      const f = c.factura || {};
      const pill = !f.requiere ? '<span class="pill">sin factura</span>'
        : f.estado === "facturada" ? '<span class="pill good">timbrada</span>'
        : '<span class="pill tarde">pendiente</span>';
      return '<tr><td class="mono">'+esc(c.folio)+'</td><td class="mono">'+esc(c.fecha)+'</td>' +
        '<td>'+esc(c.mesaNombre||"")+'</td><td class="mono">'+esc(f.rfc||"—")+'</td>' +
        '<td>'+esc(f.razon||"—")+'</td><td class="der mono">'+mx(c.total)+'</td>' +
        '<td>'+pill+'</td>' +
        '<td><button class="btn sm" data-facticket="'+esc(c.folio)+'">' +
          (f.requiere ? "Editar" : "Facturar") + '</button>' +
          (f.requiere ? ' <button class="btn sm ghost" data-facver="'+esc(c.folio)+'">Ver datos</button>' : '') +
        '</td></tr>';
    }).join("") : '<tr><td colspan="8"><div class="empty">' +
      (facFiltro === "pend" ? "No hay facturas por timbrar." : "Nada con ese filtro.") +
      '</div></td></tr>') + '</tbody>';
}
function ticketDeFolio(folio){ return vendidas().find(c=>c.folio === folio) || null; }

function abreFacturaRest(folio){
  const c = ticketDeFolio(folio);
  if(!c){ toast("No encuentro ese ticket"); return; }
  facFolio = folio;
  const f = c.factura || {};
  const pagoTipo = ((c.pagos||[])[0]||{}).tipo || "efectivo";
  $("#fr_resumen").innerHTML = '<b>'+esc(c.folio)+'</b> · '+esc(c.mesaNombre||"")+' · '+esc(c.fecha)+
    '<br>'+ (c.lineas||[]).length +' platillo(s) · Total <b>'+mx(c.total)+'</b>' +
    (num(c.propina) ? '<br><span style="color:var(--ink-3)">La propina de '+mx(c.propina)+
      ' no se factura: es del mesero, no del negocio.</span>' : '');
  $("#fr_regimen").innerHTML = opcSAT(REGIMENES, f.regimen || "612");
  $("#fr_uso").innerHTML     = opcSAT(USOS_CFDI, f.uso || "G03");
  $("#fr_forma").innerHTML   = opcSAT(FORMAS_SAT, f.formaSAT || FORMA_DE_PAGO[pagoTipo] || "99");
  $("#fr_rfc").value   = f.rfc || "";
  $("#fr_razon").value = f.razon || "";
  $("#fr_cp").value    = f.cp || "";
  $("#fr_metodo").value = f.metodoPago || "PUE";
  $("#fr_fecha").value  = f.fecha || c.fecha || hoyISO();
  $("#fr_uuid").value   = f.folioFiscal || "";
  $("#fr_quita").hidden = !f.requiere;
  $("#modalFacRest").hidden = false;
}
$("#fr_cancel").addEventListener("click", ()=>{ $("#modalFacRest").hidden = true; facFolio = null; });
$("#fr_quita").addEventListener("click", ()=>{
  const c = ticketDeFolio(facFolio); if(!c) return;
  delete c.factura; persist();
  $("#modalFacRest").hidden = true; facFolio = null;
  renderFacturas(); pintaLanzadorSec("ventas");
  toast("Factura quitada del ticket");
});
$("#fr_ok").addEventListener("click", ()=>{
  const c = ticketDeFolio(facFolio); if(!c) return;
  const rfc = ($("#fr_rfc").value||"").toUpperCase().trim();
  if(rfc.length < 12){ toast("Escribe un RFC válido"); return; }
  const uuid = ($("#fr_uuid").value||"").trim();
  const antes = c.factura || {};
  c.factura = {
    requiere:true, estado: uuid ? "facturada" : "pendiente",
    rfc, razon:($("#fr_razon").value||"").trim(), cp:($("#fr_cp").value||"").trim(),
    regimen:$("#fr_regimen").value, uso:$("#fr_uso").value,
    formaSAT:$("#fr_forma").value, metodoPago:$("#fr_metodo").value,
    folioFiscal:uuid, fecha:$("#fr_fecha").value || c.fecha,
    serie: antes.serie || "", quien: usuarioActual().nombre || ""
  };
  /* El folio se consume cuando SE TIMBRA, no cuando se captura: una factura
     pendiente todavia no gasta ninguno. Y un folio consumido no se devuelve
     aunque despues se desmarque — asi funcionan los folios del SAT. */
  if(uuid && !c.factura.serie){
    const E = fiscalRest();
    c.factura.serie = folioFacturaRest();
    E.folioFactura = num(E.folioFactura, 1) + 1;
    pintaNotaFiscal();
  }
  persist();
  $("#modalFacRest").hidden = true;
  renderFacturas(); pintaLanzadorSec("ventas");
  toast(uuid ? "Factura marcada como timbrada · "+c.folio : "Factura pendiente registrada · "+c.folio);
  imprimeDatosFactura(c);
  facFolio = null;
});
/* La hoja que se le manda al contador. Trae emisor Y receptor: con el
   receptor solo, el contador sabe a quien facturar pero no de parte de
   quien, y eso se acaba escribiendo a mano cada vez. */
function imprimeDatosFactura(c){
  const f = c.factura || {}, E = fiscalRest();
  const reg  = (REGIMENES.find(r=>r[0]===f.regimen)||["",""])[1];
  const regE = (REGIMENES.find(r=>r[0]===E.regimen)||["",""])[1];
  const uso  = (USOS_CFDI.find(u=>u[0]===f.uso)||["",""])[1];
  const forma= (FORMAS_SAT.find(x=>x[0]===f.formaSAT)||["",""])[1];
  /* Lo facturable es el consumo CON cargo por servicio y SIN propina. */
  const base = num(c.total) - num(c.propina);
  const sub  = P.ticket.mostrarIva !== false && num(P.iva) ? base/(1+num(P.iva)/100) : base;
  const iva  = base - sub;
  const falta = faltaParaFacturarRest();
  const datos = [
    ["Emisor", E.razon || (P.negocio||{}).nombre], ["RFC del emisor", E.rfc],
    ["Régimen del emisor", E.regimen ? E.regimen+" — "+regE : ""],
    ["Lugar de expedición (CP)", E.cpFiscal],
    ["Serie y folio", f.serie || "(se asigna al timbrarla; la siguiente sería " + folioFacturaRest() + ")"],
    ["Folio del ticket", c.folio], ["Fecha", f.fecha || c.fecha],
    ["Receptor", f.razon], ["RFC", f.rfc], ["Código postal", f.cp],
    ["Régimen fiscal", f.regimen+" — "+reg], ["Uso del CFDI", f.uso+" — "+uso],
    ["Forma de pago (SAT)", f.formaSAT+" — "+forma],
    ["Método de pago", f.metodoPago+(f.metodoPago==="PUE"?" — Pago en una exhibición":" — Pago en parcialidades")],
    ["Concepto", "Consumo de alimentos y bebidas"],
    ["Clave SAT sugerida", "90101500 — Servicio de restaurante"],
    ["Subtotal", mx(sub)], ["IVA "+num(P.iva)+"%", mx(iva)], ["Total a facturar", mx(base)]
  ];
  if(num(c.propina)) datos.push(["Propina (NO se factura)", mx(c.propina)]);
  if(f.folioFiscal)  datos.push(["Folio fiscal (UUID)", f.folioFiscal]);
  imprimeCarta("Datos para facturar · " + c.folio,
    '<h1>Datos para facturar</h1>' +
    '<p class="sub">' + esc((P.negocio||{}).nombre||"") + ' · ticket ' + esc(c.folio) + '</p>' +
    (falta.length
      ? '<p style="color:#B01660;font-weight:600">Te falta capturar ' +
        esc(falta.join(", ").replace(/, ([^,]*)$/, " y $1")) +
        ' en Ajustes → Facturación. El SAT lo va a pedir.</p>' : '') +
    '<table class="datos"><tbody>' + datos.map(d=>
      '<tr><th style="width:38%">'+esc(d[0])+'</th><td>'+esc(d[1]||"—")+'</td></tr>').join("") +
    '</tbody></table>' +
    '<p class="pie">Copia estos datos en tu sistema de facturación o mándaselos a tu contador.</p>');
}
document.addEventListener("click", e=>{
  const b = e.target.closest("[data-facticket]");
  if(b){ abreFacturaRest(b.dataset.facticket); return; }
  const v = e.target.closest("[data-facver]");
  if(v){ const c = ticketDeFolio(v.dataset.facver); if(c) imprimeDatosFactura(c); return; }
  const fl = e.target.closest("[data-facfiltro]");
  if(fl){ facFiltro = fl.dataset.facfiltro; renderFacturas(); return; }
});
const fb = $("#facBusca"); if(fb) fb.addEventListener("input", renderFacturas);
"""
