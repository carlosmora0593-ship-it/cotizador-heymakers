# -*- coding: utf-8 -*-
"""Que los botones de suscripcion del Lab LLEGUEN a la base.

   El bug: «Reactivar» movia el objeto de la pantalla y despues llamaba a
   guarda("cuentas", c), que por diseno solo guarda tus NOTAS — los numeros
   de la suscripcion no se editan por ahi. Resultado: la ficha del Lab se
   veia reactivada y el taller seguia viendo «tu prueba termino».

   La puerta buena ya existia desde la migracion 08: la funcion
   staff_cambia_plan, que valida que seas del equipo y deja todo escrito en
   lab_bitacora. Nadie la llamaba nunca. Esto la llama."""
import io

RUTA = "lab.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


# ------------------------------------- 1. el boton que faltaba para el plan
uno(
"""      '<div class="fila">' +
        '<button class="btn sm" data-acc="mas7">+7 días</button>' +
        '<button class="btn sm" data-acc="mas15">+15 días</button>' +""",
"""      '<div class="fila">' +
        '<button class="btn sm p" data-acc="guardaplan">Guardar plan y periodo</button>' +
        '<button class="btn sm" data-acc="mas7">+7 días</button>' +
        '<button class="btn sm" data-acc="mas15">+15 días</button>' +""",
    "el botón de guardar el plan")

# ------------------------------------------ 2. el camino viejo, reemplazado
uno(
"""  if (acc === "mas7" || acc === "mas15") {
    const n = acc === "mas7" ? 7 : 15;
    c.vence = iso(masDias(dObj(c.vence < iso(HOY) ? iso(HOY) : c.vence), n));
    if (c.estado === "vencida") c.estado = "prueba";
    anota(c, "Se le dieron " + dias(n) + " más. Ahora vence el " + fFecha(c.vence) + ".");
    aviso("Vence el " + fFecha(c.vence));
  } else if (acc === "pausa") { c.estado = "pausada"; anota(c, "Cuenta pausada. Los datos se conservan.");
  } else if (acc === "reactiva") {
    c.estado = "activa"; c.baja = null; c.vence = iso(masDias(HOY, 30));
    anota(c, "Cuenta reactivada. Siguiente cobro el " + fFecha(c.vence) + ".");
  } else if (acc === "cobra") {
    c.estado = "activa"; c.vence = iso(masDias(HOY, c.periodo === "anual" ? 365 : 30));
    anota(c, "Pasó de prueba a " + planDe(c).nombre + " " + c.periodo + ".");
    aviso("Bien: " + c.taller + " ya está pagando");
  } else if (acc === "baja") {
    if (!confirm("¿Dar de baja a " + c.taller + "? Deja de cobrarse, pero sus datos se conservan.")) return;
    c.estado = "baja"; c.baja = iso(HOY); anota(c, "Se dio de baja la cuenta.");
  } else if (acc === "nota") {""",
"""  /* Todo lo que toca la suscripción va por la base, no por la pantalla.
     Antes esto cambiaba el objeto de aquí y lo mandaba a guarda(), que
     sólo escribe tus notas: la ficha se veía reactivada y el taller
     seguía con el letrero de prueba terminada. */
  if (acc === "mas7" || acc === "mas15" || acc === "pausa" || acc === "reactiva" ||
      acc === "cobra" || acc === "baja" || acc === "guardaplan") {
    await mueveSuscripcion(c, acc);
    return;
  }
  if (acc === "nota") {""",
    "los botones de suscripción ya no fingen")

# ----------------------------------------------- 3. el que de verdad manda
uno(
"""  await guarda("cuentas", c);
  abreFicha(c.id);
}

/* ================= pintar ================= */""",
"""  await guarda("cuentas", c);
  abreFicha(c.id);
}

/* La única puerta que la base acepta para mover una suscripción.
   staff_cambia_plan vive en la migración 08: comprueba que seas del
   equipo y deja escrito en lab_bitacora quién cambió qué y cuándo. */
async function mueveSuscripcion(c, acc) {
  const planFicha = ($("#fPlan") && $("#fPlan").value) || c.planReal || c.plan;
  const periodo   = ($("#fPeriodo") && $("#fPeriodo").value) || c.periodo || "mensual";
  const nombreDe  = p => (PLANES[p] || { nombre: p }).nombre;
  const campos    = { p_cuenta: c.id };
  let texto = "";

  if (acc === "mas7" || acc === "mas15") {
    const n = acc === "mas7" ? 7 : 15;
    /* Si ya venció, los días se cuentan desde hoy: regalarle siete días
       a una fecha de la semana pasada no le sirve a nadie. */
    const desde = (c.vence && c.vence >= iso(HOY)) ? c.vence : iso(HOY);
    campos.p_vence  = iso(masDias(dObj(desde), n));
    campos.p_estado = "activa";
    /* Alargar la fecha de una cuenta sin plan no la deja trabajar: el
       cotizador pide las dos cosas. */
    if ((c.planReal || c.plan) === "ninguno") {
      if (planFicha === "ninguno") { aviso("Esta cuenta no tiene plan. Escoge uno arriba antes de darle días."); return; }
      campos.p_plan = planFicha;
    }
    texto = "Se le dieron " + dias(n) + " más. Ahora vence el " + fFecha(campos.p_vence) + ".";
  } else if (acc === "pausa") {
    campos.p_estado = "vencida";
    texto = "Cuenta pausada. Los datos se conservan.";
  } else if (acc === "reactiva") {
    const p = (planFicha && planFicha !== "ninguno") ? planFicha
            : ((c.planReal && c.planReal !== "ninguno") ? c.planReal : "");
    if (!p) { aviso("Esta cuenta no tiene plan. Escoge uno arriba antes de reactivarla."); return; }
    campos.p_plan   = p;
    campos.p_estado = "activa";
    campos.p_vence  = iso(masDias(HOY, 30));
    texto = "Cuenta reactivada en plan " + nombreDe(p) + ". Siguiente cobro el " + fFecha(campos.p_vence) + ".";
  } else if (acc === "cobra") {
    if (planFicha === "ninguno" || planFicha === "prueba") { aviso("Escoge el plan que va a pagar antes de marcarla como pagada."); return; }
    campos.p_plan      = planFicha;
    campos.p_estado    = "activa";
    campos.p_ciclo     = periodo;
    campos.p_es_prueba = false;
    campos.p_vence     = iso(masDias(HOY, periodo === "anual" ? 365 : 30));
    texto = "Pasó de prueba a " + nombreDe(planFicha) + " " + periodo + ".";
  } else if (acc === "baja") {
    if (!confirm("¿Dar de baja a " + c.taller + "? Deja de cobrarse, pero sus datos se conservan.")) return;
    campos.p_estado = "cancelada";
    texto = "Se dio de baja la cuenta.";
  } else if (acc === "guardaplan") {
    campos.p_plan  = planFicha;
    campos.p_ciclo = periodo;
    if (planFicha !== "prueba") campos.p_es_prueba = false;
    texto = "Plan cambiado a " + nombreDe(planFicha) + " " + periodo + ".";
  }
  campos.p_motivo = texto;

  if (!window.SB) { aviso("Sin conexión con la base: el cambio no se mandó."); return; }
  let r;
  try { r = await SB.rpc("staff_cambia_plan", campos); }
  catch (e) { aviso("No se pudo cambiar el plan: " + ((e && e.message) || e)); return; }

  if (r && r.error) {
    const m = String(r.error.message || "");
    /* El error de "no existe la función" es cierto y perfectamente inútil:
       lo que hay que hacer es correr la migración. */
    aviso(/staff_cambia_plan|schema cache|does not exist/i.test(m)
      ? "Falta correr CORRER-8-lab-manda.sql en Supabase. Sin eso, los botones de plan no llegan a la base."
      : "No se pudo cambiar el plan: " + m);
    console.error("staff_cambia_plan", r.error);
    return;
  }
  if (r && r.data && r.data.ok === false) { aviso(r.data.motivo || "La base no aceptó el cambio."); return; }

  anota(c, texto);
  await guarda("cuentas", c);     // la nota, que sí es tuya
  await recarga("cuentas");       // los números, que son de la base
  abreFicha(c.id);
  aviso(texto + " Ya le llegó al taller.");
}

/* ================= pintar ================= */""",
    "la función que llama a staff_cambia_plan")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
