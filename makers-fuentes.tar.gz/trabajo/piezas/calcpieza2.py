# -*- coding: utf-8 -*-
"""El motor de la calculadora por pasos."""
import io
RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []
def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1: raise SystemExit("ANCLA '%s': %d coincidencias" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1); hechos.append(etiqueta)

MOTOR = r"""
/* ==================== LA CALCULADORA POR PASOS ====================
   Una pieza, de principio a fin, sin poder saltarse un paso. Lo que cuesta
   sale del MISMO calc() que usa el cotizador: se arma una cotización de una
   sola pieza, se corre el motor de siempre y se devuelve el global a su
   lugar. Así nunca hay dos verdades sobre el mismo precio. */

const CP_DEF = {paso:1, via:"articulo", articuloId:"", servicioId:"", tecnicaId:"",
                medida:"fijo", tamanoId:"", ancho:25, alto:20,
                puntadas:8000, tintas:2, minMaquina:0, maquinaId:"",
                minutos:0, extras:{}, precio:null, precioTocado:false,
                desglose:false, busca:""};
let CP = Object.assign({}, CP_DEF, {extras:{}});

const cpArt  = () => (cat.articulos||[]).find(a=>a.id===CP.articuloId) || null;
const cpSvc  = () => (cat.servicios||[]).find(x=>x.id===CP.servicioId) || null;
const cpTec  = () => (cat.tecnicas||[]).find(t=>t.id===CP.tecnicaId) || null;
const cpTam  = () => (cat.tamanos||[]).find(t=>t.id===CP.tamanoId) || null;
const cpPasos = () => [1,2,3,4,5,6];
function cpAncho(){ const t = cpTam(); return CP.medida==="fijo" && t ? num(t.ancho) : num(CP.ancho); }
function cpAlto(){  const t = cpTam(); return CP.medida==="fijo" && t ? num(t.alto)  : num(CP.alto); }

/* Lo que falta para poder avanzar. Devuelve el texto del aviso o "". */
function cpFalta(n){
  if(n===1) return CP.via==="servicio" ? "" : (cpArt() ? "" : "Escoge el artículo que vas a costear");
  if(n===2) return CP.via==="servicio"
    ? (cpSvc() ? "" : "Escoge el material o servicio")
    : (cpTec() ? "" : "Escoge con qué se decora");
  if(n===3){
    const t = cpTec();
    if(CP.via!=="servicio" && t && t.modo==="tintas")   return num(CP.tintas)>0 ? "" : "¿Cuántas tintas lleva?";
    if(CP.via!=="servicio" && t && t.modo==="puntadas") return num(CP.puntadas)>0 ? "" : "¿Cuántas puntadas lleva?";
    if(CP.medida==="fijo") return cpTam() ? "" : "Escoge el tamaño";
    return (num(CP.ancho)>0 && num(CP.alto)>0) ? "" : "Pon el ancho y el alto";
  }
  if(n===5) return num(CP.minutos)>0 ? "" : "¿Cuántos minutos te lleva hacer una?";
  return "";
}
const cpListo = n => !cpFalta(n);

/* ---------- la cotización de una sola pieza ---------- */
function cpCotTemp(){
  const a = cpArt(), t = cpTec();
  const c = {folio:"CALC", fecha:hoyISO(), cliente:"", contacto:"", clienteId:"", ref:"",
             articuloId: CP.via==="servicio" ? "" : (a ? a.id : ""),
             costoArt: (CP.via==="servicio" || !a) ? 0 : num(a.costo),
             precioArt:(CP.via==="servicio" || !a) ? 0 : num(a.precio),
             desc:"", cantidad:1, cantManual:true, modo: CP.via==="servicio" ? "servicio" : "articulo",
             armado:[], descOn:false, descTipo:"pct", descVal:0, descNota:"",
             apps:[], extras:(cat.extras||[]).map(e=>({id:e.id, on:!!CP.extras[e.id]})),
             tallas:[], notas:"", entrega:"", resp:"", checklist:{},
             estado:"borrador", op:null, items:null, iAct:0};
  if(CP.via==="servicio"){
    const sv = cpSvc();
    if(sv) c.armado = [{id:"cparm", servicioId:sv.id, appId:"", giro:"auto", cobraMerma:true,
                        nota:"", principal:true, auto:false,
                        piezas:[{id:"cppz", ancho:cpAncho(), alto:cpAlto(), cant:1,
                                 appId:"", etiqueta:""}]}];
  } else if(t){
    c.apps = [{id:"cpapp", ubic:"Aplicación", tecnicaId:t.id,
               tamanoId: CP.medida==="fijo" ? CP.tamanoId : "",
               ancho:cpAncho(), alto:cpAlto(),
               tintas:Math.max(1,num(CP.tintas,1)), puntadas:num(CP.puntadas),
               minutos:num(CP.minMaquina), minutosSetup:0, art:null}];
  }
  return c;
}
/* El motor de siempre, con el global prestado un instante. */
function cpCostea(){
  const guardado = cot;
  let r = null;
  try{
    cot = cpCotTemp();
    if(CP.via !== "servicio" && typeof autoArmado === "function") autoArmado();
    r = calc();
    r.cot = cot;
  }catch(e){ r = null; }
  finally{ cot = guardado; }
  return r;
}

/* ---------- lo que el cotizador NO cobra pero sí se gasta ---------- */
function cpFijos(){
  const c = normalizaCalc();
  const mes = num(c.gfMes), pzas = num(c.gfPiezas);
  return (c.gfOn && mes>0 && pzas>0) ? mes/pzas : 0;
}
function cpTiempo(){
  const c = normalizaCalc();
  const hora = num(c.moHora);
  return hora>0 ? num(CP.minutos)*hora/60 : 0;
}
function cpLuz(){
  const m = maqDe(CP.maquinaId);
  if(!m) return 0;
  const min = num(CP.minMaquina) > 0 ? num(CP.minMaquina) : num(CP.minutos);
  return min * costoMinutoMaq(m);
}
/* Todo junto: lo que el cotizador ya cuenta más el tiempo, la luz y la
   parte de la renta que le toca a esta pieza. */
function cpTotales(){
  const r = cpCostea();
  const base = r ? num(r.costoTotal) : 0;
  const tiempo = cpTiempo(), luz = cpLuz(), fijos = cpFijos();
  const costo = base + tiempo + luz + fijos;
  const sugerido = r ? num(r.total) : 0;
  const precio = (CP.precioTocado && CP.precio !== null) ? num(CP.precio) : sugerido;
  return {r, base, tiempo, luz, fijos, costo, sugerido, precio,
          utilidad: precio - costo,
          margen: precio>0 ? (precio-costo)/precio*100 : 0};
}

/* ---------- lo que sale del almacén por una pieza ---------- */
function cpConsumo(){
  const T = cpTotales();
  if(!T.r || !T.r.cot) return [];
  try{ return consumoDe(T.r.cot, Object.assign({}, T.r, {qty:1, partes:null})); }
  catch(e){ return []; }
}

/* ---------- pintar ---------- */
function cpIco(d){
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+d+'</svg>';
}
function cpAzulejo(attr, id, color, dentro, elegido){
  return '<button type="button" class="cpAz" '+attr+'="'+esc(id)+'" style="--cpc:'+esc(color)+'" '+
    'aria-pressed="'+(elegido?"true":"false")+'">'+dentro+'</button>';
}
function cpChip(txt, fuerte){ return '<span class="cpChip'+(fuerte?" fuerte":"")+'">'+esc(txt)+'</span>'; }

const CP_VIAS = [
  {id:"articulo", nombre:"Un artículo de mi catálogo", sub:"playera, taza, termo, gorra", color:"#D6127F",
   icono:'<path d="M6 4h12l3 5-4 2v9H7v-9L3 9Z"/>'},
  {id:"servicio", nombre:"Sólo un servicio por medida", sub:"metros de rollo, lona, vinil", color:"#0680AB",
   icono:'<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 6v12M18 6v12"/>'}
];

function cpCuerpo1(){
  let h = '<div class="cpRej">' + CP_VIAS.map(v=>
    cpAzulejo("data-cpvia", v.id, v.color,
      '<span class="cpIco">'+cpIco(v.icono)+'</span><b>'+esc(v.nombre)+'</b><small>'+esc(v.sub)+'</small>',
      CP.via===v.id)).join("") + '</div>';
  if(CP.via !== "articulo") return h;
  const q = (CP.busca||"").trim().toLowerCase();
  const ls = (cat.articulos||[]).filter(a=> !q ||
    ((a.nombre||"")+" "+(a.cat||"")).toLowerCase().indexOf(q) >= 0);
  h += '<div class="cpBusca" style="margin-top:14px">' +
       '<input id="cpBusca" placeholder="Buscar artículo" value="'+esc(CP.busca||"")+'">' +
       '<span class="hint">'+ls.length+' de '+(cat.articulos||[]).length+'</span></div>';
  h += ls.length
    ? '<div class="cpRej">' + ls.map(a=> cpAzulejo("data-cpart", a.id, "#D6127F",
        miniArt(a) + '<b>'+esc(a.nombre)+'</b><small>'+esc(a.cat||"Sin familia")+' · cuesta '+mx(a.costo)+'</small>',
        CP.articuloId===a.id)).join("") + '</div>'
    : '<p class="cpNota">Ningún artículo con ese nombre. Los artículos se capturan en Catálogo.</p>';
  return h;
}
function cpCuerpo2(){
  if(CP.via === "servicio"){
    const ls = cat.servicios || [];
    if(!ls.length) return '<p class="cpNota">No tienes materiales por medida capturados. Van en Catálogo · Materiales y servicios.</p>';
    return '<div class="cpRej">' + ls.map(x=> cpAzulejo("data-cpsvc", x.id, "#0680AB",
      '<span class="cpIco">'+cpIco('<rect x="2" y="7" width="20" height="10" rx="1.5"/><path d="M6 7v10"/>')+'</span>'+
      '<b>'+esc(x.nombre)+'</b><small>'+num(x.ancho)+' cm de ancho · '+mx(x.costo)+' el '+
      (x.unidad==="m2"?"m²":"metro")+'</small>',
      CP.servicioId===x.id)).join("") + '</div>';
  }
  const ls = cat.tecnicas || [];
  if(!ls.length) return '<p class="cpNota">No tienes técnicas capturadas. El asistente de arranque te las carga en un minuto.</p>';
  const COL = {area:"#0680AB", tintas:"#8B5CF6", puntadas:"#D2541F", tiempo:"#14B8A6"};
  const QUE = {area:"se cobra por centímetro cuadrado", tintas:"se cobra por tinta",
               puntadas:"se cobra por puntada", tiempo:"se cobra por minuto de máquina"};
  return '<div class="cpRej">' + ls.map(t=> cpAzulejo("data-cptec", t.id, COL[t.modo]||"#0680AB",
    '<span class="cpIco">'+cpIco('<circle cx="12" cy="12" r="8"/><path d="M12 8v8M8 12h8"/>')+'</span>'+
    '<b>'+esc(t.nombre)+'</b><small>'+(QUE[t.modo]||"")+'</small>',
    CP.tecnicaId===t.id)).join("") + '</div>' +
    '<p class="cpNota">Sólo salen las técnicas que tú tienes configuradas. Si falta alguna, se agrega en Catálogo.</p>';
}
function cpCuerpo3(){
  const t = cpTec();
  let h = "";
  if(CP.via !== "servicio" && t && t.modo === "puntadas"){
    h += '<div class="cpCampos"><label class="cpCampo"><span>Puntadas del diseño</span>'+
      '<input type="number" min="100" step="500" data-cpf="puntadas" value="'+num(CP.puntadas)+'"></label></div>';
  }
  if(CP.via !== "servicio" && t && t.modo === "tintas"){
    h += '<div class="cpCampos"><label class="cpCampo"><span>Tintas del diseño</span>'+
      '<input type="number" min="1" max="12" step="1" data-cpf="tintas" value="'+num(CP.tintas,1)+'"></label></div>';
  }
  if(CP.via !== "servicio" && t && t.modo === "tiempo"){
    h += '<div class="cpCampos"><label class="cpCampo"><span>Minutos de máquina</span>'+
      '<input type="number" min="0" step="0.5" data-cpf="minMaquina" value="'+num(CP.minMaquina)+'"></label></div>';
  }
  h += '<div class="seg" style="margin:'+(h?"14px":"0")+' 0 12px">'+
    '<button type="button" data-cpmed="fijo" aria-pressed="'+(CP.medida==="fijo")+'">Un tamaño de los míos</button>'+
    '<button type="button" data-cpmed="libre" aria-pressed="'+(CP.medida==="libre")+'">A la medida</button></div>';
  if(CP.medida === "fijo"){
    const ls = cat.tamanos || [];
    h += ls.length
      ? '<div class="cpRej">' + ls.map(x=> cpAzulejo("data-cptam", x.id, "#14B8A6",
          '<b>'+esc(x.nombre)+'</b><small>'+num(x.ancho)+' × '+num(x.alto)+' cm</small>',
          CP.tamanoId===x.id)).join("") + '</div>'
      : '<p class="cpNota">No tienes tamaños capturados. Van en Catálogo · Tamaños de impresión.</p>';
  } else {
    h += '<div class="cpCampos">'+
      '<label class="cpCampo"><span>Ancho (cm)</span><input type="number" min="0.5" step="0.5" data-cpf="ancho" value="'+num(CP.ancho)+'"></label>'+
      '<label class="cpCampo"><span>Alto (cm)</span><input type="number" min="0.5" step="0.5" data-cpf="alto" value="'+num(CP.alto)+'"></label>'+
      '</div>';
  }
  const a = cpAncho(), al = cpAlto();
  if(a>0 && al>0) h += '<p class="cpNota">Son <b>'+red3(a*al/10000)+' m²</b> de impresión por pieza.</p>';
  return h;
}
function cpCuerpo4(){
  const lista = cpConsumo();
  let h = lista.length
    ? '<table class="cpTabla"><thead><tr><th>Lo que sale del almacén</th>'+
      '<th class="n">Por pieza</th><th class="n">Hay</th></tr></thead><tbody>'+
      lista.map(x=>{
        const falta = num(x.insumo.existencia) < num(x.cant);
        return '<tr><td>'+esc(x.insumo.nombre)+'</td>'+
          '<td class="n">'+cantIns(x.cant)+' '+abrevIns(x.insumo.unidad)+'</td>'+
          '<td class="n"'+(falta?' style="color:var(--warn)"':'')+'>'+
            cantIns(x.insumo.existencia)+'</td></tr>';
      }).join("")+'</tbody></table>'+
      '<p class="cpNota">Esto es lo que <b>se descuenta solo</b> de tu inventario cuando confirmas un pedido. '+
      'No se suma al costo de aquí abajo: ya viene adentro de lo que cobra la técnica por centímetro cuadrado. '+
      'Si los dos números no se parecen, el que está mal es el de la técnica.</p>'
    : '<p class="cpNota">Esta combinación todavía no tiene consumibles amarrados, así que el almacén no se va a mover '+
      'cuando confirmes un pedido. Los amarres van en Catálogo · Consumibles.</p>';
  const porPieza = (cat.extras||[]).filter(x=>x.tipo==="pieza");
  if(porPieza.length){
    h += '<div style="margin-top:14px"><div class="cpTit" style="font-size:13.5px">Extras que van en cada pieza</div>'+
      '<div class="cpRej">' + porPieza.map(x=> cpAzulejo("data-cpext", x.id, "#B26A00",
        '<b>'+esc(x.nombre)+'</b><small>'+mx(x.monto)+' la pieza</small>', !!CP.extras[x.id])).join("") + '</div></div>';
  }
  return h;
}
function cpCuerpo5(){
  const c = normalizaCalc();
  const ms = maquinas();
  let h = '<div class="cpCampos">'+
    '<label class="cpCampo"><span>Minutos que te lleva hacer una</span>'+
      '<input type="number" min="0" step="0.5" data-cpf="minutos" value="'+num(CP.minutos)+'"></label>'+
    '<label class="cpCampo"><span>Cuánto vale tu hora</span>'+
      '<input type="number" min="0" step="10" data-cc="moHora" value="'+num(c.moHora)+'"></label>'+
    (ms.length
      ? '<label class="cpCampo"><span>Máquina que se usa</span><select data-cpf="maquinaId">'+
        '<option value="">Ninguna / a mano</option>'+
        ms.map(m=>'<option value="'+esc(m.id)+'"'+(CP.maquinaId===m.id?" selected":"")+'>'+esc(m.nombre)+'</option>').join("")+
        '</select></label>'
      : '')+
    '</div>';
  h += '<label class="sw" style="margin:14px 0 10px"><input type="checkbox" data-cc="gfOn"'+(c.gfOn?" checked":"")+'> '+
    'Repartir la renta, la luz y lo demás entre las piezas que hago al mes</label>';
  if(c.gfOn){
    h += '<div class="cpCampos">'+
      '<label class="cpCampo"><span>Gastos fijos al mes</span>'+
        '<input type="number" min="0" step="100" data-cc="gfMes" value="'+num(c.gfMes)+'"></label>'+
      '<label class="cpCampo"><span>Piezas que haces al mes</span>'+
        '<input type="number" min="0" step="10" data-cc="gfPiezas" value="'+num(c.gfPiezas)+'"></label>'+
      '</div>';
  }
  const m = maqDe(CP.maquinaId);
  if(m){
    const d = desgloseMaq(m);
    h += '<p class="cpNota">El minuto de <b>'+esc(m.nombre)+'</b> cuesta <b>'+mx(d.minuto)+'</b>: '+
      mx(d.luz)+' de luz, '+mx(d.consumibles)+' de consumibles, '+mx(d.mantenimiento)+' de mantenimiento y '+
      mx(d.depreciacion)+' de lo que vale la máquina, todo por hora.</p>';
  }
  h += '<p class="cpNota">Tu tiempo cuenta aunque no te lo pagues: el día que contrates a alguien para hacer esto, '+
    'ese costo aparece igual. Y la renta se paga haya o no trabajo.</p>';
  return h;
}
function cpCuerpo6(){
  const T = cpTotales();
  return '<div class="cpCampos">'+
    '<label class="cpCampo"><span>Lo que te cuesta</span>'+
      '<input type="text" value="'+mx(T.costo)+'" readonly></label>'+
    '<label class="cpCampo"><span>Lo que cobra hoy tu cotizador</span>'+
      '<input type="text" value="'+mx(T.sugerido)+'" readonly></label>'+
    '</div>'+
    '<p class="cpNota">Tu utilidad está configurada en Ajustes: '+
    (P.modo==="margen" ? "margen " : "markup ")+num(P.margen)+'%. Si quieres otro precio para esta pieza, '+
    'escríbelo abajo y te digo cuánto te queda.</p>';
}
const CP_TITULOS = [
  ["¿Qué vas a costear?", "un artículo terminado o nada más el servicio"],
  ["¿Cómo se decora?", "sólo salen las técnicas que tú configuraste"],
  ["¿De qué tamaño?", "uno de tus tamaños o a la medida"],
  ["¿Qué se gasta?", "lo que se descuenta del almacén y los extras"],
  ["Tu tiempo y la luz", "lo que se paga aunque nadie lo cobre"],
  ["¿Cuánto quieres ganar?", "el precio sale de tu utilidad y lo puedes mover"]
];
function cpChipsDe(n){
  const a = cpArt(), sv = cpSvc(), t = cpTec();
  if(n===1) return CP.via==="servicio" ? cpChip("Servicio por medida", true)
    : (a ? cpChip(a.nombre, true) + cpChip(mx(a.costo)+" de costo") : "");
  if(n===2) return CP.via==="servicio" ? (sv ? cpChip(sv.nombre, true) : "")
    : (t ? cpChip(t.nombre, true) : "");
  if(n===3){
    if(CP.via!=="servicio" && t && t.modo==="puntadas") return cpChip(num(CP.puntadas).toLocaleString("es-MX")+" puntadas", true);
    if(CP.via!=="servicio" && t && t.modo==="tintas")   return cpChip(num(CP.tintas,1)+" tinta(s)", true);
    const tm = cpTam();
    return CP.medida==="fijo" && tm ? cpChip(tm.nombre, true) + cpChip(num(tm.ancho)+"×"+num(tm.alto)+" cm")
                                    : cpChip(num(CP.ancho)+"×"+num(CP.alto)+" cm", true);
  }
  if(n===4){
    const l = cpConsumo().length;
    const e = Object.keys(CP.extras).filter(k=>CP.extras[k]).length;
    return (l ? cpChip(l+" consumible(s)", true) : cpChip("sin consumibles")) +
           (e ? cpChip(e+" extra(s)") : "");
  }
  if(n===5) return cpChip(num(CP.minutos)+" min", true) +
    (cpFijos()>0 ? cpChip(mx(cpFijos())+" de fijos") : "");
  return "";
}
function cpPinta(){
  const w = $("#cpPasos"); if(!w) return;
  const pasos = cpPasos();
  w.innerHTML = pasos.map(n=>{
    const i = pasos.indexOf(n), act = pasos.indexOf(CP.paso);
    const estado = n === CP.paso ? "activo" : (i < act ? "hecho" : "");
    const cuerpo = n === CP.paso
      ? '<div class="cpCuerpo">' +
        [cpCuerpo1, cpCuerpo2, cpCuerpo3, cpCuerpo4, cpCuerpo5, cpCuerpo6][n-1]() +
        '<div class="cpPie">' +
          (cpFalta(n) ? '<span class="cpAviso">'+esc(cpFalta(n))+'</span>'
                      : '<span class="cpOk">Listo. Puedes seguir.</span>') +
          (n > 1 ? '<button class="btn ghost" data-cpir="'+pasos[i-1]+'">Atrás</button>' : '') +
          (n < pasos[pasos.length-1]
            ? '<button class="btn primary" data-cpsig="'+pasos[i+1]+'"'+(cpFalta(n)?" disabled":"")+'>Continuar</button>'
            : '') +
        '</div></div>'
      : "";
    return '<div class="cpPaso '+estado+'">'+
      '<'+(estado==="hecho"?'button type="button" data-cpir="'+n+'"':'div')+' class="cpCab">'+
        '<span class="cpNum">'+(estado==="hecho"?"✓":n)+'</span>'+
        '<span class="cpTit">'+CP_TITULOS[n-1][0]+'<small>'+CP_TITULOS[n-1][1]+'</small></span>'+
        '<span class="cpChips">'+(estado==="activo"?"":cpChipsDe(n))+'</span>'+
      '</'+(estado==="hecho"?'button':'div')+'>'+ cuerpo + '</div>';
  }).join("");
  cpResultado();
}

function cpResultado(){
  const w = $("#cpResultado"); if(!w) return;
  const listos = cpPasos().every(n=>cpListo(n));
  if(!listos || CP.paso < 6){ w.innerHTML = ""; return; }
  const T = cpTotales();
  if(!T.r){ w.innerHTML = '<p class="cpNota">No pude calcular esta combinación. Revisa la medida y el material.</p>'; return; }
  const r = T.r;
  const material = num(r.costoArt) + num(r.armadoCosto);
  const trabajo  = num(r.costoApps) + num(r.setupCosto) + T.tiempo;
  const merma    = Math.max(0, num(r.costoDirecto) - (num(r.costoArt) + num(r.costoApps)));
  const fijos    = T.fijos + T.luz;
  const total    = Math.max(0.0001, material + trabajo + merma + fijos);
  const pct = v => (v/total*100).toFixed(1) + "%";
  const COLS = ["#0680AB", "#D2541F", "#B26A00", "#8B5CF6"];
  const perdida = T.utilidad < 0;

  w.innerHTML = '<div class="cpRes">'+
    '<div class="cpResTop">'+
      '<div class="cpBig"><span>Te cuesta hacer una</span><b>'+mx(T.costo)+'</b>'+
        '<i>material, trabajo, merma y lo fijo</i></div>'+
      '<div class="cpBig alt"><span>Deberías cobrar</span><b>'+mx(T.precio)+'</b>'+
        '<i>'+(CP.precioTocado ? "tu precio" : "con tu utilidad de Ajustes")+'</i></div>'+
    '</div>'+

    '<div class="cpBarra">'+
      '<i style="background:'+COLS[0]+';width:'+pct(material)+'"></i>'+
      '<i style="background:'+COLS[1]+';width:'+pct(trabajo)+'"></i>'+
      '<i style="background:'+COLS[2]+';width:'+pct(merma)+'"></i>'+
      '<i style="background:'+COLS[3]+';width:'+pct(fijos)+'"></i>'+
    '</div>'+
    '<div class="cpLeyenda">'+
      '<span><u style="background:'+COLS[0]+'"></u>Material '+mx(material)+'</span>'+
      '<span><u style="background:'+COLS[1]+'"></u>Tiempo y trabajo '+mx(trabajo)+'</span>'+
      '<span><u style="background:'+COLS[2]+'"></u>Merma '+mx(merma)+'</span>'+
      '<span><u style="background:'+COLS[3]+'"></u>Fijos y luz '+mx(fijos)+'</span>'+
    '</div>'+

    '<div class="cpPrecio">'+
      '<label class="cpCampo"><span>Tu precio por pieza</span>'+
        '<input type="number" min="0" step="1" id="cpPrecio" value="'+(Math.round(num(T.precio)*100)/100)+'"></label>'+
      '<div style="flex:1 1 240px">'+
        '<p class="cpNota" style="margin:0">'+
          (perdida
            ? '<b style="color:var(--warn)">Con ese precio pierdes '+mx(-T.utilidad)+' por pieza.</b>'
            : 'Te quedan <b>'+mx(T.utilidad)+'</b> por pieza · <b>'+T.margen.toFixed(0)+'%</b> de margen')+
        '</p>'+
        (CP.precioTocado ? '<button class="btn sm ghost" id="cpVuelve" style="margin-top:8px">Volver al precio de mi utilidad</button>' : '')+
      '</div>'+
    '</div>'+
    (cpArt() && CP.via!=="servicio"
      ? '<div class="cpPie"><button class="btn" id="cpGuardaPrecio">Guardar este precio en «'+esc(cpArt().nombre)+'»</button>'+
        '<span class="hint">Cambia el precio público del artículo para que el cotizador llegue a este total.</span></div>'
      : '')+

    '<div class="cpDesp"'+(CP.desglose?" open":"")+'>'+
      '<button type="button" id="cpVerDesglose">'+
        cpIco('<path d="M9 6l6 6-6 6"/>')+'<b>De dónde sale el costo</b>'+
        '<span class="hint">'+mx(T.costo)+'</span></button>'+
      (CP.desglose ? '<div class="cpDespCuerpo">'+cpTablaDesglose(T)+'</div>' : '')+
    '</div>'+

    '<p class="cpNota">Este número es de <b>una pieza suelta</b>. En un pedido de verdad el material se acomoda '+
    'en el rollo entre todas las piezas y sale más barato: eso lo calcula el armado del cotizador, no esta pantalla.</p>'+
  '</div>';
}
function cpTablaDesglose(T){
  const r = T.r;
  const fila = (que, cuanto, nota) =>
    '<tr><td>'+que+(nota?' <i>'+nota+'</i>':'')+'</td><td class="n">'+mx(cuanto)+'</td></tr>';
  let h = '<table class="cpTabla"><thead><tr><th>De qué</th><th class="n">Por pieza</th></tr></thead><tbody>';
  if(num(r.costoArt) > 0) h += fila("El artículo", r.costoArt, "lo que te cuesta comprarlo");
  if(num(r.armadoCosto) > 0) h += fila("El material impreso", r.armadoCosto, "con su merma de acomodo");
  (r.detalle||[]).forEach(d=> h += fila(d.tecnica, d.costo, d.base));
  if(num(r.setupCosto) > 0) h += fila("Preparación", r.setupCosto, "pantallas, ponchado, arranque");
  const merma = Math.max(0, num(r.costoDirecto) - (num(r.costoArt) + num(r.costoApps)));
  if(merma > 0) h += fila("Merma", merma, num(P.merma)+"% de lo que se echa a perder");
  if(T.tiempo > 0) h += fila("Tu tiempo", T.tiempo, num(CP.minutos)+" min");
  if(T.luz > 0) h += fila("La máquina", T.luz, "luz, mantenimiento y desgaste");
  if(T.fijos > 0) h += fila("Gastos fijos", T.fijos, "la parte que le toca a esta pieza");
  h += '</tbody><tfoot><tr><td><b>Todo junto</b></td><td class="n"><b>'+mx(T.costo)+'</b></td></tr>'+
       '<tr><td>Lo que cobra hoy tu cotizador</td><td class="n">'+mx(T.sugerido)+'</td></tr></tfoot></table>';
  return h;
}

/* ---------- los clics ---------- */
document.addEventListener("click", e=>{
  const via = e.target.closest("[data-cpvia]");
  if(via){ CP.via = via.dataset.cpvia; CP.precioTocado = false; cpPinta(); return; }
  const art = e.target.closest("[data-cpart]");
  if(art){ CP.articuloId = art.dataset.cpart; CP.precioTocado = false; cpPinta(); return; }
  const sv = e.target.closest("[data-cpsvc]");
  if(sv){ CP.servicioId = sv.dataset.cpsvc; CP.precioTocado = false; cpPinta(); return; }
  const tc = e.target.closest("[data-cptec]");
  if(tc){ CP.tecnicaId = tc.dataset.cptec; CP.precioTocado = false; cpPinta(); return; }
  const md = e.target.closest("[data-cpmed]");
  if(md){ CP.medida = md.dataset.cpmed; cpPinta(); return; }
  const tm = e.target.closest("[data-cptam]");
  if(tm){ CP.tamanoId = tm.dataset.cptam; CP.precioTocado = false; cpPinta(); return; }
  const ex = e.target.closest("[data-cpext]");
  if(ex){ CP.extras[ex.dataset.cpext] = !CP.extras[ex.dataset.cpext]; CP.precioTocado = false; cpPinta(); return; }
  const sig = e.target.closest("[data-cpsig]");
  if(sig){ CP.paso = num(sig.dataset.cpsig); cpPinta(); return; }
  const ir = e.target.closest("[data-cpir]");
  if(ir){ CP.paso = num(ir.dataset.cpir); cpPinta(); return; }
  if(e.target.closest("#cpVerDesglose")){ CP.desglose = !CP.desglose; cpResultado(); return; }
  if(e.target.closest("#cpVuelve")){ CP.precioTocado = false; CP.precio = null; cpResultado(); return; }
  if(e.target.closest("#cpReinicia")){
    CP = Object.assign({}, CP_DEF, {extras:{}});
    cpPinta(); toast("Listo, de cero"); return;
  }
  if(e.target.closest("#cpGuardaPrecio")){
    const a = cpArt(); if(!a) return;
    const T = cpTotales();
    /* Lo que ya cobra la decoración y el material no se toca: al artículo le
       toca la diferencia. Si da negativo, el precio que pusiste no alcanza ni
       para lo que ya cobra la impresión, y eso hay que decirlo, no esconderlo. */
    const sinArt = num(T.sugerido) - (num(a.precio) || 0);
    const nuevo = num(T.precio) - sinArt;
    if(!(nuevo > 0)){
      alert("Con ese precio el artículo saldría en cero o en negativo: la decoración y el material por sí solos " +
            "ya cobran " + mx(sinArt) + ". Sube el precio o baja lo que cobras por la impresión.");
      return;
    }
    if(!confirm("¿Dejar «" + a.nombre + "» en " + mx(nuevo) + " de precio público?\n\n" +
                "Hoy está en " + mx(a.precio) + ". Así el cotizador llega a " + mx(T.precio) + " por pieza.")) return;
    a.precio = Math.round(nuevo*100)/100;
    persist();
    if(typeof renderCatalogo === "function") renderCatalogo();
    CP.precioTocado = false; CP.precio = null;
    cpPinta();
    toast("Precio guardado en el catálogo");
    return;
  }
});
document.addEventListener("input", e=>{
  if(e.target.id === "cpBusca"){ CP.busca = e.target.value; cpPinta();
    const b = $("#cpBusca"); if(b){ b.focus(); b.setSelectionRange(b.value.length, b.value.length); } return; }
  if(e.target.id === "cpPrecio"){ CP.precio = num(e.target.value); CP.precioTocado = true;
    /* El resultado se repinta solo; el campo del precio no, para no quitarle
       el cursor a quien lo está escribiendo. */
    const T = cpTotales();
    const n = e.target.closest(".cpPrecio").querySelector(".cpNota");
    if(n) n.innerHTML = T.utilidad < 0
      ? '<b style="color:var(--warn)">Con ese precio pierdes '+mx(-T.utilidad)+' por pieza.</b>'
      : 'Te quedan <b>'+mx(T.utilidad)+'</b> por pieza · <b>'+T.margen.toFixed(0)+'%</b> de margen';
    return;
  }
  const f = e.target.dataset && e.target.dataset.cpf;
  if(f && e.target.closest("#cpPasos")){
    CP[f] = f === "maquinaId" ? e.target.value : num(e.target.value);
    CP.precioTocado = false;
    const aviso = e.target.closest(".cpCuerpo");
    if(aviso){
      const falta = cpFalta(CP.paso);
      const av = aviso.querySelector(".cpAviso, .cpOk");
      if(av){ av.className = falta ? "cpAviso" : "cpOk";
              av.textContent = falta || "Listo. Puedes seguir."; }
      const btn = aviso.querySelector("[data-cpsig]");
      if(btn) btn.disabled = !!falta;
    }
    cpResultado();
    return;
  }
});
document.addEventListener("change", e=>{
  const f = e.target.dataset && e.target.dataset.cpf;
  if(f === "maquinaId" && e.target.closest("#cpPasos")){ CP.maquinaId = e.target.value; cpPinta(); return; }
});
"""

# el motor va justo antes de renderCalc, que ya existe
uno(
"""function renderCalc(){ renderMaquinas(); renderPasos(); renderResultado(); }""",
MOTOR + """
function renderCalc(){ renderMaquinas(); renderPasos(); renderResultado(); cpPinta(); }""",
    "el motor de la calculadora por pasos")

# ------------------------------------------------------------ el lanzador
uno(
"""registraLanzador("inv", [""",
"""registraLanzador("calc", [
  {id:"pieza", nombre:"¿Qué cuesta hacer una?", sub:"una pieza, paso a paso", color:"#D6127F",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.5 9.6a2.5 2.5 0 0 1 5 0c0 2.4-5 1.9-5 4.8a2.5 2.5 0 0 0 5 0"/>',
   card:'#cardCalcPieza',
   alAbrir:()=>{ if(typeof cpPinta === "function") cpPinta(); }},
  {id:"materiales", nombre:"Calibrar mis materiales", sub:"film, tinta y polvo por m²", color:"#0680AB",
   icono:'<path d="M12 3s6 6.4 6 10a6 6 0 0 1-12 0c0-3.6 6-10 6-10Z"/>',
   card:'#cardCalc',
   alAbrir:()=>{ if(typeof renderPasos === "function"){ renderPasos(); renderResultado(); } }},
  {id:"maquinas", nombre:"Máquinas y su hora", sub:"luz, desgaste y mantenimiento", color:"#14B8A6",
   icono:'<rect x="3" y="8" width="18" height="10" rx="2"/><path d="M7 8V5h10v3M7 18v2M17 18v2"/>',
   card:'#cardMaq',
   cuenta:()=>{ try{ return maquinas().length; }catch(e){ return 0; } },
   alAbrir:()=>{ if(typeof renderMaquinas === "function") renderMaquinas(); }}
], "Calculadora");

registraLanzador("inv", [""",
    "el lanzador de la calculadora")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  · " + h)
