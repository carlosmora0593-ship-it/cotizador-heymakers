# -*- coding: utf-8 -*-
"""La calculadora por pasos: que cuesta UNA pieza.

   No es un cotizador. No pregunta cuantas piezas lleva el pedido: contesta
   que te cuesta hacer una taza magica sublimada, y que deberias cobrar por
   ella. Los precios salen del mismo motor que ya usa el cotizador, para que
   lo que diga aqui y lo que diga una cotizacion sean el mismo numero."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []

def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)

# ================================================================= 1. estilos
uno(
""".armSepOri{align-items:end;gap:10px}""",
"""/* ---- la calculadora por pasos ---- */
.cpPaso{border:1.5px solid var(--line);border-radius:16px;background:var(--surface);
  margin-bottom:12px;overflow:hidden;transition:border-color .15s}
.cpPaso.activo{border-color:var(--accent)}
.cpPaso.hecho{background:var(--surface-2)}
.cpCab{display:flex;align-items:center;gap:12px;padding:14px 16px;width:100%;
  background:none;border:0;font:inherit;color:var(--ink);text-align:left;cursor:default}
.cpPaso.hecho .cpCab{cursor:pointer}
.cpNum{flex:none;width:27px;height:27px;border-radius:50%;display:grid;place-items:center;
  background:var(--surface-2);color:var(--ink-3);font-weight:700;font-size:13px;
  border:1.5px solid var(--line)}
.cpPaso.activo .cpNum{background:var(--accent);color:#fff;border-color:var(--accent)}
.cpPaso.hecho .cpNum{background:var(--good);color:#fff;border-color:var(--good)}
.cpTit{flex:1;min-width:0;font-weight:600;font-size:15px}
.cpTit small{display:block;font-weight:400;font-size:12px;color:var(--ink-3);margin-top:1px}
.cpChips{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;max-width:52%}
.cpChip{font-size:11.5px;padding:3px 9px;border-radius:999px;background:var(--surface-2);
  border:1px solid var(--line);color:var(--ink-2);white-space:nowrap}
.cpChip.fuerte{background:var(--accent-soft);border-color:transparent;color:var(--accent);font-weight:600}
.cpCuerpo{padding:0 16px 16px}
.cpRej{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:10px}
.cpAz{position:relative;display:flex;flex-direction:column;align-items:flex-start;gap:6px;
  text-align:left;border:1.5px solid var(--line);background:var(--surface-2);border-radius:14px;
  padding:12px;cursor:pointer;font:inherit;color:var(--ink);
  transition:border-color .15s,background .15s,transform .1s}
.cpAz:hover{border-color:var(--cpc,var(--accent));transform:translateY(-1px)}
.cpAz[aria-pressed="true"]{border-color:var(--cpc,var(--accent));
  background:color-mix(in srgb, var(--cpc,var(--accent)) 11%, var(--surface-2))}
.cpAz .cpIco{width:32px;height:32px;border-radius:10px;display:grid;place-items:center;
  background:color-mix(in srgb, var(--cpc,var(--accent)) 20%, transparent);color:var(--cpc,var(--accent))}
.cpAz .cpIco svg{width:18px;height:18px}
.cpAz b{font-family:"Fredoka",system-ui,sans-serif;font-weight:500;font-size:13.5px;line-height:1.2}
.cpAz small{color:var(--ink-3);font-size:11.5px;line-height:1.35}
.cpAz img.artMini,.cpAz .artMini{width:100%;height:68px;object-fit:cover;border-radius:10px}
.cpBusca{display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
.cpBusca input{flex:1 1 180px;min-width:150px}
.cpCampos{display:flex;flex-wrap:wrap;gap:10px;margin-top:12px}
.cpCampo{display:flex;flex-direction:column;flex:1 1 170px;min-width:140px}
.cpCampo span{font-size:11px;font-weight:600;letter-spacing:.03em;text-transform:uppercase;
  color:var(--ink-3);margin-bottom:4px}
.cpCampo input,.cpCampo select{min-height:44px;margin-top:auto}
.cpCampo input[type=number]{text-align:right}
.cpPie{display:flex;align-items:center;gap:10px;margin-top:14px;flex-wrap:wrap}
.cpPie .cpAviso{color:var(--warn);font-size:12.5px;margin-right:auto}
.cpPie .cpOk{color:var(--ink-3);font-size:12.5px;margin-right:auto}
.cpNota{font-size:12.5px;line-height:1.55;color:var(--ink-3);margin:10px 0 0}
.cpTabla{width:100%;border-collapse:collapse;font-size:13px}
.cpTabla th{font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
  color:var(--ink-3);text-align:left;padding:6px 8px;border-bottom:1px solid var(--line)}
.cpTabla td{padding:7px 8px;border-bottom:1px solid var(--line)}
.cpTabla td.n{text-align:right;font-variant-numeric:tabular-nums}
.cpTabla tr:last-child td{border-bottom:0}
.cpTabla i{font-style:normal;color:var(--ink-3);font-size:11.5px}
.cpRes{margin-top:18px}
.cpResTop{display:flex;gap:12px;flex-wrap:wrap}
.cpBig{flex:1 1 230px;background:var(--accent-soft);border-radius:14px;padding:14px 16px}
.cpBig.alt{background:var(--good-soft)}
.cpBig span{display:block;font-size:11px;font-weight:700;letter-spacing:.05em;
  text-transform:uppercase;color:var(--ink-3)}
.cpBig b{display:block;font-family:"IBM Plex Mono",monospace;font-size:28px;font-weight:700;
  color:var(--accent);margin:3px 0 1px}
.cpBig.alt b{color:var(--good)}
.cpBig i{font-style:normal;font-size:11.5px;color:var(--ink-3)}
.cpBarra{display:flex;height:12px;border-radius:999px;overflow:hidden;margin:14px 0 8px;
  background:var(--surface-2)}
.cpBarra i{display:block;height:100%}
.cpLeyenda{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:var(--ink-2)}
.cpLeyenda span{display:flex;align-items:center;gap:6px}
.cpLeyenda u{width:10px;height:10px;border-radius:3px;text-decoration:none;display:inline-block}
.cpPrecio{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin-top:16px}
.cpPrecio .cpCampo{flex:0 0 190px}
.cpPrecio input{font-family:"IBM Plex Mono",monospace;font-size:19px;font-weight:700;min-height:48px}
.cpDesp{margin-top:16px;border:1px solid var(--line);border-radius:14px;overflow:hidden}
.cpDesp>button{width:100%;display:flex;align-items:center;gap:10px;padding:12px 14px;
  background:var(--surface-2);border:0;font:inherit;color:var(--ink);cursor:pointer;text-align:left}
.cpDesp>button b{flex:1;font-weight:600;font-size:13.5px}
.cpDesp>button svg{width:16px;height:16px;transition:transform .15s}
.cpDesp[open]>button svg{transform:rotate(90deg)}
.cpDespCuerpo{padding:12px 14px}
@media(max-width:560px){
  .cpChips{max-width:100%;justify-content:flex-start}
  .cpCab{flex-wrap:wrap}
}
.armSepOri{align-items:end;gap:10px}""",
    "los estilos de la calculadora por pasos")

# =============================================================== 2. el markup
uno(
"""<section id="tab-calc" hidden>
  <div class="card" id="cardMaq">""",
"""<section id="tab-calc" hidden>
  <div class="secBarra" id="bar_calc" hidden><button class="secVolver" data-secvolver="calc"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>Volver</button><span class="secMigas">Calculadora</span></div>
  <div class="lanzador secLz" id="lz_calc"></div>
  <div class="card secOculta" id="cardCalcPieza" style="margin-top:20px">
    <header><h2>¿Qué cuesta hacer una?</h2>
      <span class="hint" style="margin-left:auto">una pieza, no un pedido</span>
      <button class="btn sm ghost" id="cpReinicia">Empezar de nuevo</button>
    </header>
    <div class="body">
      <p class="note" style="margin:0 0 16px">Esto <b>no es un cotizador</b>: no pregunta cuántas piezas lleva el pedido.
        Contesta qué te cuesta hacer <b>una</b> y qué deberías cobrar por ella. Los precios son los mismos que ya tienes
        capturados, así que lo que salga aquí y lo que salga en una cotización son el mismo número.</p>
      <div id="cpPasos"></div>
      <div id="cpResultado"></div>
    </div>
  </div>
  <div class="card secOculta" id="cardMaq">""",
    "la tarjeta nueva y el lanzador de la calculadora")

uno(
"""  <div class="card" id="cardCalc">
    <header><h2>Calculadora de costo de producción</h2>""",
"""  <div class="card secOculta" id="cardCalc">
    <header><h2>Calculadora de costo de producción</h2>""",
    "la calculadora de materiales entra al lanzador")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
