# -*- coding: utf-8 -*-
"""El aviso de que existe el cotizador por pasos.

   El interruptor nace apagado, que esta bien: a quien ya se sabe la
   pantalla no se le cambia debajo de los pies. Pero apagado y escondido
   en Ajustes es lo mismo que no existir — Carlos mismo no lo encontro.

   Esto lo ofrece UNA vez, en la pantalla donde importa, y se quita para
   siempre con cualquiera de los dos botones."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []


def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)


# ------------------------------------------------------------------ estilos
uno(
"""/* ---- los azulejos del cotizador ---- */""",
"""/* ---- el aviso del cotizador por pasos ---- */
.invPasos{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin:0 0 14px;
  padding:14px 16px;border:1.5px solid color-mix(in srgb,var(--accent) 35%,var(--line));
  border-radius:16px;background:var(--accent-soft);animation:mvEntra .4s both}
.invPasos .invIco{flex:none;width:36px;height:36px;border-radius:11px;display:grid;place-items:center;
  background:var(--accent);color:#fff}
.invPasos .invIco svg{width:19px;height:19px}
.invPasos .invTxt{flex:1;min-width:190px;font-size:13px;line-height:1.5;color:var(--ink-2)}
.invPasos .invTxt b{color:var(--ink-1)}
.invPasos .invBtns{display:flex;gap:8px;flex-wrap:wrap}
@media(max-width:560px){ .invPasos{gap:10px} .invPasos .invBtns{width:100%} }
/* ---- los azulejos del cotizador ---- */""",
    "los estilos del aviso")

# -------------------------------------------------------------------- motor
MOTOR = r"""
/* ============ OFRECER EL COTIZADOR POR PASOS ============
   Una sola vez, donde se usa, y con las dos salidas a la vista. Lo que se
   guarda es que YA SE PREGUNTÓ, aparte del interruptor: así «ahora no» es
   una respuesta y no una pregunta que vuelve mañana. */
function invPinta(){
  const sec = document.getElementById("tab-cot"); if(!sec) return;
  const col = sec.querySelector(".cols > div"); if(!col) return;
  const vieja = document.getElementById("invPasos");
  /* Ya contestó, o ya lo trae prendido: no hay nada que ofrecer. */
  if(P.guiadoVisto || guiado()){ if(vieja) vieja.remove(); return; }
  if(vieja) return;
  col.insertAdjacentHTML("afterbegin",
    '<div class="invPasos" id="invPasos">' +
      '<span class="invIco"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
        'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
        '<path d="M4 6h16M4 12h10M4 18h6"/><circle cx="19" cy="15" r="3"/></svg></span>' +
      '<span class="invTxt"><b>Nuevo: cotizar por pasos.</b> La misma pantalla y los mismos ' +
        'botones, nada más que de uno en uno, con azulejos para escoger el cliente, el artículo ' +
        'y la técnica. Se prende y se apaga cuando quieras, en Ajustes.</span>' +
      '<span class="invBtns">' +
        '<button class="btn primary" id="invSi">Probarlo</button>' +
        '<button class="btn ghost" id="invNo">Ahora no</button>' +
      '</span>' +
    '</div>');
}
document.addEventListener("click", e=>{
  if(e.target.closest("#invSi")){
    P.guiado = true; P.guiadoVisto = true; persist();
    const c = $("#p_guiado"); if(c) c.checked = true;
    if(typeof guiaPinta === "function"){ GUIA.actual = guiaPasos()[0]; guiaPinta(); }
    invPinta();
    toast("Cotizar por pasos: prendido. Se apaga en Ajustes · Cómo se cotiza.");
    return;
  }
  if(e.target.closest("#invNo")){
    P.guiadoVisto = true; persist(); invPinta();
    toast("Queda como está. Lo encuentras en Ajustes · Cómo se cotiza.");
    return;
  }
});
"""

uno(
"""/* ==================== COTIZAR POR PASOS ====================""",
MOTOR + """
/* ==================== COTIZAR POR PASOS ====================""",
    "el motor del aviso")

# ------------------------------------------- que se pinte al entrar a Cotizar
uno(
"""  if(b.dataset.tab==="cot" && typeof guiaPinta === "function") guiaPinta();""",
"""  if(b.dataset.tab==="cot" && typeof guiaPinta === "function"){ guiaPinta(); invPinta(); }""",
    "al entrar a Cotizar se ofrece")

uno(
"""  renderCot(); renderSet(); arrancaPasos();
  if(typeof guiaPinta === "function") guiaPinta();""",
"""  renderCot(); renderSet(); arrancaPasos();
  if(typeof guiaPinta === "function") guiaPinta();
  if(typeof invPinta === "function") invPinta();""",
    "al arrancar también")

# --------------------------- el interruptor de Ajustes tambien cuenta como visto
uno(
"""  if(t.id==="p_guiado"){
    P.guiado = t.checked;""",
"""  if(t.id==="p_guiado"){
    P.guiado = t.checked;
    P.guiadoVisto = true;
    if(typeof invPinta === "function") invPinta();""",
    "tocar el interruptor contesta el aviso")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
