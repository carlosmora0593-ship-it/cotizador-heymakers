# -*- coding: utf-8 -*-
"""Retardos y faltas, medidos contra el horario de cada quien, y ligados a
   la nomina.

   El reloj checador ya sabia a que hora entro cada persona. Lo que no sabia
   es a que hora DEBIA entrar: no habia horario capturado, asi que nadie
   llegaba tarde nunca. Y eso no es que todos lleguen a tiempo, es que no
   hay con que compararlo.

   Tres piezas:
     - un horario semanal por persona, en su expediente
     - la tolerancia, que la pone el patron
     - el conteo del periodo: retardos, faltas y los minutos que se deben

   La nomina los ensena y ofrece descontarlos. OFRECE, no descuenta solo:
   un descuento que aparece sin que nadie lo decida es como se pierden los
   juicios laborales. El renglon se agrega con un boton y se puede quitar."""

CSS = """
/* ---- horario y retardos ---- */
.horSem{display:grid;gap:8px;margin-top:4px}
.horDia{display:grid;grid-template-columns:104px 1fr 1fr auto;gap:10px;align-items:center}
.horDia .nom{font-size:13px;font-weight:600}
.horDia input[type="time"]{width:100%}
.horDia.libre input{opacity:.4;pointer-events:none}
.horCopia{margin-top:10px}
.retTiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:0 0 14px}
.retTile{border:1px solid var(--line);border-radius:var(--radio-sm,12px);background:var(--surface-2);
  padding:13px 15px}
.retTile b{display:block;font-family:"IBM Plex Mono",monospace;font-size:21px;font-weight:600;line-height:1.1}
.retTile small{display:block;font-size:10.5px;text-transform:uppercase;letter-spacing:.06em;
  color:var(--ink-3);margin-top:5px}
.retTile.mal b{color:var(--guinda-2,var(--accent))}
.retTile.aviso b{color:var(--warn)}
.nmRet{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:10px;
  padding:11px 13px;border:1px solid var(--line);border-radius:12px;background:var(--surface-2)}
.nmRet .txt{flex:1;min-width:180px;font-size:12.5px;color:var(--ink-2)}
.nmRet .txt b{color:var(--ink)}
"""

JS = r"""
/* ============ HORARIO, RETARDOS Y FALTAS ============ */
const DIAS_SEM = [["lun","Lunes"],["mar","Martes"],["mie","Miércoles"],["jue","Jueves"],
                  ["vie","Viernes"],["sab","Sábado"],["dom","Domingo"]];
/* getDay(): 0 es domingo. Se recorre para que la semana empiece en lunes. */
function llaveDia(fecha){ return DIAS_SEM[(dmy(fecha).getDay()+6)%7][0]; }

function horarioDe(id){
  const e = expDe(id);
  if(!e.horario){
    e.horario = {};
    DIAS_SEM.forEach(([k])=>{ e.horario[k] = {libre: k==="dom", entra:"", sale:""}; });
  }
  return e.horario;
}
function toleranciaMin(){ return num(P.tolerancia, 10); }

/* Un día con horario puesto y sin checada es FALTA. Un día sin horario no
   es falta: es un día del que no sabemos nada, y decir lo contrario es
   inventarle un descuento a alguien. */
function diaDe(id, fecha){
  const h = horarioDe(id)[llaveDia(fecha)] || {};
  const ts = turnosDe(id, fecha);
  const min = minutosDia(id, fecha);
  if(h.libre || !h.entra) return {tipo: ts.length ? "trabajo" : "libre", min, tarde:0};
  if(!ts.length) return {tipo:"falta", min:0, tarde:0};
  const debia = minutosDe(h.entra);
  const llego = minutosDe(ts[0].entrada.hora);
  const tarde = Math.max(0, llego - debia - toleranciaMin());
  return {tipo: tarde > 0 ? "retardo" : "trabajo", min, tarde, debia:h.entra,
          llego: ts[0].entrada.hora};
}

function retardosDe(id, R){
  const dias = diasDelRango(R);
  const retardos = [], faltas = [];
  let minTarde = 0;
  dias.forEach(d=>{
    if(d > hoyISO()) return;            /* el futuro no falta */
    const x = diaDe(id, d);
    if(x.tipo === "retardo"){ retardos.push({fecha:d, min:x.tarde, debia:x.debia, llego:x.llego});
                              minTarde += x.tarde; }
    else if(x.tipo === "falta") faltas.push({fecha:d});
  });
  const j = justificadasDe(id);
  return {retardos, faltas, minTarde,
          retardosSin: retardos.filter(r=>!j[r.fecha]),
          faltasSin:   faltas.filter(f=>!j[f.fecha]),
          justificadas: j};
}
/* Justificar no borra: el retardo se queda con sus minutos y se le agrega
   el motivo y quién lo justificó. Un retardo borrado no sirve el día que
   se discute; uno justificado sí. */
function justificadasDe(id){
  const e = expDe(id);
  e.justificadas = e.justificadas || {};
  return e.justificadas;
}
function justifica(id, fecha, motivo){
  const j = justificadasDe(id);
  j[fecha] = {motivo, quien: usuarioActual().nombre || "", cuando: hoyISO()+" "+horaAhora()};
  persist();
}
function quitaJustificacion(id, fecha){
  const j = justificadasDe(id); delete j[fecha]; persist();
}

/* Lo que se descontaría. Son dos cosas distintas y se calculan distinto:
   una falta cuesta el día; los retardos cuestan los minutos. */
function descuentoDe(id, R){
  const e = expDe(id);
  const r = retardosDe(id, R);
  const diario = salarioDiario(e), porHora = salarioHora(e);
  const porFaltas   = r.faltasSin.length * diario;
  const porRetardos = (r.minTarde / 60) * porHora;
  return {faltas: r.faltasSin.length, retardos: r.retardosSin.length,
          minutos: r.minTarde,
          montoFaltas: Math.round(porFaltas*100)/100,
          montoRetardos: Math.round(porRetardos*100)/100,
          total: Math.round((porFaltas + porRetardos)*100)/100, detalle: r};
}
function minutosTxt(m){
  m = Math.round(num(m));
  if(m < 60) return m + " min";
  const h = Math.floor(m/60), r = m%60;
  return h + " h" + (r ? " " + r + " min" : "");
}
"""
