# -*- coding: utf-8 -*-
"""Lanzador de tarjetas dentro de una seccion.

   El Catalogo eran nueve tarjetas apiladas, una debajo de otra, y la
   primera —Articulos— traia una tabla de nueve columnas. Abrirlo era caer
   en un muro: para llegar a «Escalas de volumen» habia que pasar de largo
   por todo lo demas.

   La idea que Carlos pidio es la del tablero: entrar y ver AZULEJOS, no
   contenido. Se toca uno y se abre lo suyo, solo. Es el mismo componente
   del lanzador de aplicaciones (.lanzador / .lzApp / .lzIco), para que no
   haya dos juegos de azulejos que se desfasen.

   Lo generico vive aqui: una seccion declara sus tarjetas y este codigo se
   encarga del resto. Asi se repite en Cotizaciones y en Archivo sin volver
   a escribirlo."""

CSS = """
/* ---- lanzador dentro de una sección ---- */
.secLz{margin-top:20px}
.secBarra{display:flex;align-items:center;gap:12px;margin:0 0 16px;flex-wrap:wrap}
.secBarra h2{font-family:"Fredoka",system-ui,sans-serif;font-weight:500;font-size:20px;margin:0}
.secBarra .sub{font-size:12.5px;color:var(--ink-3)}
.secVolver{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);
  background:var(--surface);color:var(--ink-2);border-radius:999px;padding:7px 14px;
  cursor:pointer;font:inherit;font-size:13px;transition:border-color .16s,color .16s}
.secVolver:hover{border-color:var(--accent);color:var(--accent)}
.secVolver svg{width:15px;height:15px}
.secMigas{display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--ink-3)}
.secMigas b{color:var(--ink);font-weight:600}
.secOculta{display:none!important}
"""

JS = r"""
/* ============ LANZADOR DE SECCIONES ============ */
/* Una sección declara sus tarjetas; esto hace el resto. */
const SEC_LZ = {};

/* cada tarjeta: {id, nombre, sub, color, icono, cuenta:fn, card:selector} */
function registraLanzador(tab, tarjetas, titulo, sub){
  SEC_LZ[tab] = {tarjetas, titulo, sub, abierta:null};
}
function lzIconoSvg(d){
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>';
}
function pintaLanzadorSec(tab){
  const cfg = SEC_LZ[tab]; if(!cfg) return;
  const w = document.getElementById("lz_" + tab); if(!w) return;
  w.innerHTML = cfg.tarjetas.filter(t=>{
    if(t.visible){ try{ return !!t.visible(); }catch(e){ return true; } }
    if(!t.soloAdmin) return true;
    return typeof rolActual !== "function" || rolActual() === "admin";
  }).map(t=>{
    let n = "";
    try{ n = t.cuenta ? String(t.cuenta()) : ""; }catch(e){ n = ""; }
    return '<button class="lzApp" data-seclz="'+esc(tab)+'|'+esc(t.id)+'" style="--lzc:'+esc(t.color)+'">' +
      '<span class="lzIco">' + lzIconoSvg(t.icono) +
        (n !== "" ? '<i class="lzN">'+esc(n)+'</i>' : '') + '</span>' +
      '<span class="lzEt">'+esc(t.nombre)+'</span>' +
      '<span class="lzSub">'+esc(t.sub||"")+'</span></button>';
  }).join("");
}
/* Abrir una tarjeta: se esconden las demás y aparece la barra de volver.
   No se borra nada del DOM — se esconde — porque los render de siempre
   siguen escribiendo en esas tablas aunque no se vean. */
function abreTarjetaSec(tab, id){
  const cfg = SEC_LZ[tab]; if(!cfg) return;
  const t = cfg.tarjetas.find(x=>x.id === id); if(!t) return;
  cfg.abierta = id;
  const sec = document.getElementById("tab-" + tab); if(!sec) return;
  /* Primero se tapa todo y luego se destapa la elegida. Con toggle en un
     solo paso, varias tarjetas que comparten contenedor —como las de
     Cotizaciones, que abren la misma lista filtrada— se tapaban entre
     ellas segun el orden del arreglo. */
  cfg.tarjetas.forEach(x=> sec.querySelectorAll(x.card).forEach(el=> el.classList.add("secOculta")));
  sec.querySelectorAll(t.card).forEach(el=>{
    el.classList.remove("secOculta");
    /* Algunas tarjetas usan hidden para el rol. Si el azulejo se pinto es
       porque al rol SI le toca, asi que al abrirla se destapa tambien. */
    if(t.destapa) el.hidden = false;
  });
  const lz = document.getElementById("lz_" + tab); if(lz) lz.hidden = true;
  const barra = document.getElementById("bar_" + tab);
  if(barra){
    barra.hidden = false;
    barra.querySelector(".secMigas").innerHTML =
      esc(cfg.titulo) + ' <span aria-hidden="true">›</span> <b>' + esc(t.nombre) + '</b>';
  }
  if(t.alAbrir) try{ t.alAbrir(); }catch(e){}
  window.scrollTo({top:0, behavior:"smooth"});
}
function cierraTarjetaSec(tab){
  const cfg = SEC_LZ[tab]; if(!cfg) return;
  cfg.abierta = null;
  const sec = document.getElementById("tab-" + tab); if(!sec) return;
  cfg.tarjetas.forEach(x=> sec.querySelectorAll(x.card).forEach(el=> el.classList.add("secOculta")));
  const lz = document.getElementById("lz_" + tab); if(lz) lz.hidden = false;
  const barra = document.getElementById("bar_" + tab); if(barra) barra.hidden = true;
  pintaLanzadorSec(tab);
  window.scrollTo({top:0, behavior:"smooth"});
}
/* El tablero y el menú de la cuenta mandan a una tarjeta por su ancla
   («#equipoCaja», «#cardExp»). Con azulejos esa tarjeta nace tapada, así
   que antes de bajar a ella hay que abrir el azulejo que la contiene. */
function abrePorAncla(sel){
  let el = null;
  try{ el = document.querySelector(sel); }catch(e){ return false; }
  if(!el) return false;
  const sec = el.closest("section[id^='tab-']"); if(!sec) return false;
  const tab = sec.id.replace(/^tab-/, "");
  const cfg = SEC_LZ[tab]; if(!cfg) return false;
  const t = cfg.tarjetas.find(x=>{
    try{
      return Array.from(sec.querySelectorAll(x.card))
        .some(c=> c === el || c.contains(el));
    }catch(e){ return false; }
  });
  if(!t || t.accion) return false;
  abreTarjetaSec(tab, t.id);
  return true;
}
window.abrePorAncla = abrePorAncla;
/* Al entrar a la sección siempre se ve el lanzador, no lo último que se
   abrió: entrar al Catálogo y caer en «Escalas de volumen» desorienta. */
function reiniciaSec(tab){
  if(SEC_LZ[tab]) cierraTarjetaSec(tab);
}
document.addEventListener("click", e=>{
  const b = e.target.closest("[data-seclz]");
  if(b){
    const [tab, id] = b.dataset.seclz.split("|");
    /* Un azulejo puede ser una ACCION en vez de una puerta: «+ Nueva
       requisicion» no abre nada, crea algo. Se ve igual que los demas
       porque para quien lo usa es lo mismo: lo que quiere hacer. */
    const cfg = SEC_LZ[tab];
    const t = cfg && cfg.tarjetas.find(x=>x.id === id);
    if(t && t.accion){ try{ t.accion(); }catch(err){} return; }
    abreTarjetaSec(tab, id); return;
  }
  const v = e.target.closest("[data-secvolver]");
  if(v){ cierraTarjetaSec(v.dataset.secvolver); return; }
});
"""

def barra(tab, titulo):
    return ('<div class="secBarra" id="bar_%s" hidden>'
            '<button class="secVolver" data-secvolver="%s">'
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" '
            'stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>'
            'Volver</button>'
            '<span class="secMigas">%s</span></div>' % (tab, tab, titulo))

def lanzador(tab):
    return '<div class="lanzador secLz" id="lz_%s"></div>' % tab
