# -*- coding: utf-8 -*-
import io
RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []
def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1: raise SystemExit("ANCLA '%s': %d coincidencias" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno(
"""  gfOn:true, gfMes:0, gfM2:0,
  ancho:25, alto:20
};""",
"""  gfOn:true, gfMes:0, gfM2:0, gfPiezas:0,
  ancho:25, alto:20
};""",
    "las piezas al mes entran al costeo guardado")

uno(
"""document.addEventListener("change", e=>{
  const f = e.target.dataset && e.target.dataset.cpf;
  if(f === "maquinaId" && e.target.closest("#cpPasos")){ CP.maquinaId = e.target.value; cpPinta(); return; }
});""",
"""document.addEventListener("change", e=>{
  const f = e.target.dataset && e.target.dataset.cpf;
  if(f === "maquinaId" && e.target.closest("#cpPasos")){ CP.maquinaId = e.target.value; cpPinta(); return; }
  /* Los campos de tu hora y de los gastos fijos son LOS MISMOS de la otra
     calculadora: si los cambias aquí, allá quedan cambiados. Un taller tiene
     una sola renta. */
  const k = e.target.dataset && e.target.dataset.cc;
  if(k && e.target.closest("#cpPasos") && e.target.type === "checkbox"){
    normalizaCalc()[k] = e.target.checked; persist(); cpPinta(); return;
  }
});
document.addEventListener("input", e=>{
  const k = e.target.dataset && e.target.dataset.cc;
  if(k && e.target.closest("#cpPasos") && e.target.type !== "checkbox"){
    normalizaCalc()[k] = num(e.target.value); persist();
    /* Igual que en la otra: se repintan los números, nunca los campos. */
    cpResultado();
    const chips = $("#cpPasos");
    return;
  }
});""",
    "los campos compartidos con la otra calculadora")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  · " + h)
