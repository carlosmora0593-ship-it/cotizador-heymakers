# -*- coding: utf-8 -*-
"""Mete el asistente de arranque y le quita a la app los supuestos que
   tenia sobre la semilla (que siempre habria una tecnica, que servicios
   vacio era un error que habia que rellenar)."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import arranque

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("/* ---- lanzador dentro de una sección ---- */",
    arranque.CSS.strip() + "\n/* ---- lanzador dentro de una sección ---- */",
    "estilos del asistente")

uno('<div class="modal" id="modalPlanes" hidden>',
    arranque.HTML + '<div class="modal" id="modalPlanes" hidden>',
    "la ventana del asistente")

uno('registraLanzador("cat", [\n  {id:"articulos", nombre:"Artículos", sub:"lo que vendes", color:"#06B6D4",',
    arranque.JS.rstrip() + """

registraLanzador("cat", [
  {id:"traer", nombre:"Traer ejemplos", sub:"técnicas y artículos que no cargaste", color:"#D2541F",
   icono:'<path d="M12 3v12"/><path d="M8 11l4 4 4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>',
   card:'[data-cat="articulos"]',
   accion:()=> abreArranque("agregar")},
  {id:"articulos", nombre:"Artículos", sub:"lo que vendes", color:"#06B6D4",""",
    "el asistente y el azulejo de traer ejemplos")

# ---- lo que suponia que la semilla siempre estaba completa ----
uno("""  if(!Array.isArray(cat.servicios) || !cat.servicios.length){ cat.servicios = d.servicios; _catSembrado = true; }""",
    """  /* Un taller que sólo borda se queda sin materiales por medida, y eso
     está bien: si ya pasó por el asistente, vacío es una respuesta, no un
     catálogo a medio sembrar. */
  const yaEligio = !!(cat.arranque && cat.arranque.hecho);
  if(!Array.isArray(cat.servicios) || (!cat.servicios.length && !yaEligio)){
    cat.servicios = d.servicios; _catSembrado = true;
  }""",
    "no resembrar los materiales")

uno("""  cot.apps.push({id:uid(),ubic:cot.apps.length?"Espalda":"Frente",tecnicaId:cat.tecnicas[0].id,tamanoId:s.id,ancho:s.ancho,alto:s.alto,tintas:1,puntadas:8000});""",
    """  if(!(cat.tecnicas||[]).length){ toast("Primero da de alta una técnica en Catálogo"); return; }
  cot.apps.push({id:uid(),ubic:cot.apps.length?"Espalda":"Frente",tecnicaId:cat.tecnicas[0].id,tamanoId:s.id,ancho:s.ancho,alto:s.alto,tintas:1,puntadas:8000});""",
    "agregar aplicación sin técnicas")

uno("""  if(cot.apps.length && !cat.tecnicas.find(t=>t.id===cot.apps[0].tecnicaId)) cot.apps[0].tecnicaId = cat.tecnicas[0].id;""",
    """  if(cot.apps.length && (cat.tecnicas||[]).length && !cat.tecnicas.find(t=>t.id===cot.apps[0].tecnicaId))
    cot.apps[0].tecnicaId = cat.tecnicas[0].id;""",
    "arranque sin técnicas")

uno("""    const t = cat.tecnicas.find(t=>t.id===a.tecnicaId) || cat.tecnicas[0];""",
    """    const t = cat.tecnicas.find(t=>t.id===a.tecnicaId) || (cat.tecnicas||[])[0];""",
    "técnica del armado sin técnicas")

# ---- el orden al entrar: primero el asistente, luego el tutorial ----
uno("""  arrancaAyuda();
  tourSiEsNuevo();""",
    """  arrancaAyuda();
  arranqueSiEsNuevo();
  tourSiEsNuevo();""",
    "el asistente al arrancar")

uno("""  const puerta = $("#acceso");
  if(puerta && !puerta.hidden){ setTimeout(tourSiEsNuevo, 1500); return; }
  const nuevo = typeof esPrimeraVez === "function" ? esPrimeraVez() : !(guardadas||[]).length;""",
    """  const puerta = $("#acceso");
  if(puerta && !puerta.hidden){ setTimeout(tourSiEsNuevo, 1500); return; }
  /* El asistente de arranque va primero: enseñar el tutorial encima de él
     serían dos ventanas peleándose por la misma pantalla. */
  const asis = $("#arranque");
  if(asis && !asis.hidden){ setTimeout(tourSiEsNuevo, 2000); return; }
  const nuevo = typeof esPrimeraVez === "function" ? esPrimeraVez() : !(guardadas||[]).length;""",
    "el tutorial espera al asistente")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
