# -*- coding: utf-8 -*-
"""Una falta no se cobra dos veces.

   Salio probando el restaurante: a Luis, con sueldo semanal de $2,100 y
   dos faltas, el recibo le pagaba 3 dias ($900, ya SIN los dos que falto)
   y ademas le proponia descontarle $600 por esas mismas dos faltas. Le
   habriamos cobrado la falta dos veces.

   Depende de COMO se le paga:
   · por hora          -> ni faltas ni retardos: lo que no trabajo nunca se le pago.
   · por dias checados -> la falta ya se cobro sola; el retardo no, porque
                          un dia que entro tarde se paga completo.
   · por periodo fijo  -> se cobra la semana entera pase lo que pase, asi
                          que ahi si entran las dos cosas."""
import pathlib
hechos = []

# ---------------- cotizador ----------------
RC = pathlib.Path('/home/claude/trabajo/cotizador.html')
c = RC.read_text(encoding='utf-8')
def unoC(viejo, nuevo, etiqueta):
    global c
    n = c.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    c = c.replace(viejo, nuevo, 1); hechos.append("cotizador: " + etiqueta)

unoC("""function descuentoDe(id, R){
  const e = expDe(id);
  const r = retardosDe(id, R);
  const diario = salarioDiario(e), porHora = salarioHora(e);
  const porFaltas   = r.faltasSin.length * diario;
  const porRetardos = (r.minTarde / 60) * porHora;
  return {faltas: r.faltasSin.length, retardos: r.retardosSin.length,
          minutos: r.minTarde,
          montoFaltas: Math.round(porFaltas*100)/100,
          montoRetardos: Math.round(porRetardos*100)/100,
          total: Math.round((porFaltas + porRetardos)*100)/100, detalle: r};
}""",
"""function descuentoDe(id, R){
  const e = expDe(id);
  const r = retardosDe(id, R);
  const modo = (e.sueldo && e.sueldo.modo) || "fijo";
  const diario = salarioDiario(e), porHora = salarioHora(e);
  /* Lo que la base YA descontó sola no se vuelve a descontar. Por horas la
     base paga horas checadas: ni la falta ni el retardo llegaron a pagarse.
     Por días checados la falta ya se cobró sola, pero el retardo no —ese
     día se pagó completo. Sólo el sueldo fijo paga el periodo entero. */
  const cobraFaltas   = (modo === "fijo");
  const cobraRetardos = (modo !== "horas");
  const porFaltas   = cobraFaltas   ? r.faltasSin.length * diario : 0;
  const porRetardos = cobraRetardos ? (r.minTarde / 60) * porHora : 0;
  return {faltas: r.faltasSin.length, retardos: r.retardosSin.length,
          minutos: r.minTarde, modo, cobraFaltas, cobraRetardos,
          montoFaltas: Math.round(porFaltas*100)/100,
          montoRetardos: Math.round(porRetardos*100)/100,
          total: Math.round((porFaltas + porRetardos)*100)/100, detalle: r};
}""",
"el descuento respeta cómo se paga")

unoC("""  const ya = (r.deduc||[]).some(d=>d.porRetardos);
  return '<div class="nmRet"><span class="txt">' +
    (f.faltas ? '<b>'+f.faltas+' falta(s)</b> sin justificar — '+mx(f.montoFaltas) : '') +
    (f.faltas && f.retardos ? ' · ' : '') +
    (f.retardos ? '<b>'+f.retardos+' retardo(s)</b>, '+minutosTxt(f.minutos)+' — '+mx(f.montoRetardos) : '') +
    '</span>' +
    (ya ? '<span class="pill good">Ya descontado</span>'
        : '<button class="btn sm" data-nmret="'+esc(r.id)+'">Descontar '+mx(f.total)+'</button>') +
    '<button class="btn sm ghost" data-nmretver="'+esc(r.id)+'">Ver los días</button></div>';""",
"""  const ya = (r.deduc||[]).some(d=>d.porRetardos);
  const nota = !f.cobraFaltas && f.faltas
    ? (f.modo === "horas"
        ? ' <small style="color:var(--ink-3)">— no se descuentan: se le paga por horas checadas</small>'
        : ' <small style="color:var(--ink-3)">— no se descuentan: la base ya paga sólo los días que vino</small>')
    : '';
  return '<div class="nmRet"><span class="txt">' +
    (f.faltas ? '<b>'+f.faltas+' falta(s)</b> sin justificar' +
       (f.cobraFaltas ? ' — '+mx(f.montoFaltas) : nota) : '') +
    (f.faltas && f.retardos ? ' · ' : '') +
    (f.retardos ? '<b>'+f.retardos+' retardo(s)</b>, '+minutosTxt(f.minutos) +
       (f.cobraRetardos ? ' — '+mx(f.montoRetardos)
                        : ' <small style="color:var(--ink-3)">— ya van fuera: se le paga por hora</small>') : '') +
    '</span>' +
    (!f.total ? '<span class="pill">sólo para que lo veas</span>'
      : ya ? '<span class="pill good">Ya descontado</span>'
        : '<button class="btn sm" data-nmret="'+esc(r.id)+'">Descontar '+mx(f.total)+'</button>') +
    '<button class="btn sm ghost" data-nmretver="'+esc(r.id)+'">Ver los días</button></div>';""",
"el renglón dice por qué no descuenta")

RC.write_text(c, encoding='utf-8')

# ---------------- restaurante ----------------
RR = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
s = RR.read_text(encoding='utf-8')
def unoR(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1); hechos.append("restaurante: " + etiqueta)

unoR("""function descuentoDe(u, r){
  const dia = valorDia(u);
  if(!dia) return {aplica:false, faltas:r.faltas.length, minTarde:r.tardeSinJust,
                   porFaltas:0, porRetardos:0, total:0};
  const hora = dia / jornadaHoras(u);
  const porFaltas   = r.faltas.length * dia;
  const porRetardos = (r.tardeSinJust / 60) * hora;
  return {aplica:true, faltas:r.faltas.length, minTarde:r.tardeSinJust,
          porFaltas, porRetardos, total: porFaltas + porRetardos};
}""",
"""/* El recibo paga SOLO los días que checó, así que la falta ya se cobró
   sola: descontarla otra vez sería cobrársela dos veces. Lo que el recibo
   no descuenta es el retardo —un día que entró tarde se paga completo— y
   eso sí va aquí. Por hora no se descuenta nada. */
function descuentoDe(u, r){
  const dia = valorDia(u);
  const base = {aplica:false, porHora:!dia, faltas:r.faltas.length,
                minTarde:r.tardeSinJust, porFaltas:0, porRetardos:0, total:0};
  if(!dia) return base;
  const hora = dia / jornadaHoras(u);
  base.aplica = true;
  base.porRetardos = (r.tardeSinJust / 60) * hora;
  base.total = base.porRetardos;
  return base;
}""",
"el descuento no cobra la falta dos veces")

unoR("""    (r.faltas.length ? '<p class="note" style="margin-top:12px;border-left-color:var(--mal)">' +
      'Faltó <b>' + r.faltas.length + ' día(s)</b> que tenía programados: ' +
      esc(r.faltas.join(", ")) + '.</p>' : "") +""",
"""    (r.faltas.length ? '<p class="note" style="margin-top:12px;border-left-color:var(--mal)">' +
      'Faltó <b>' + r.faltas.length + ' día(s)</b> que tenía programados: ' +
      esc(r.faltas.join(", ")) + '. Esos días ya no se le están pagando — el recibo cuenta ' +
      'los días que checó — así que no hay nada más que descontarle por ellos.</p>' : "") +""",
"la falta se explica en pantalla")

unoR("""      '<b>Descuento por retardos y faltas: ' + mx(r.desc.total) + '</b><br>' +
      (r.desc.porFaltas ? r.desc.faltas + ' falta(s) × ' + mx(valorDia(u)) + ' el día = ' +
        mx(r.desc.porFaltas) + '<br>' : '') +
      (r.desc.porRetardos ? horasTxt(r.desc.minTarde) + ' de retardo × ' +
        mx(valorDia(u)/jornadaHoras(u)) + ' la hora = ' + mx(r.desc.porRetardos) + '<br>' : '') +""",
"""      '<b>Descuento por retardos: ' + mx(r.desc.total) + '</b><br>' +
      horasTxt(r.desc.minTarde) + ' de retardo × ' +
        mx(valorDia(u)/jornadaHoras(u)) + ' la hora = ' + mx(r.desc.porRetardos) + '<br>' +""",
"el aviso habla sólo de retardos")

unoR("""     : (!r.desc.aplica && (r.faltas.length || r.sinJust)
        ? '<p class="note" style="margin-top:12px">A ' + esc(u.nombre||"") + ' se le paga por hora, ' +
          'así que no hay nada que descontar: las horas que no trabajó nunca se le contaron.</p>'
        : "")) +""",
"""     : (r.desc.porHora && (r.faltas.length || r.sinJust)
        ? '<p class="note" style="margin-top:12px">A ' + esc(u.nombre||"") + ' se le paga por hora, ' +
          'así que no hay nada que descontar: las horas que no trabajó nunca se le contaron.</p>'
        : "")) +""",
"el aviso de pago por hora")

unoR("""      ? '<p class="pie" style="margin-top:8px">Se descontaron ' +
        (r.desc.porFaltas ? r.desc.faltas + ' falta(s) por ' + mx(r.desc.porFaltas) : '') +
        (r.desc.porFaltas && r.desc.porRetardos ? ' y ' : '') +
        (r.desc.porRetardos ? horasTxt(r.desc.minTarde) + ' de retardo por ' + mx(r.desc.porRetardos) : '') +
        '.</p>'""",
"""      ? '<p class="pie" style="margin-top:8px">Se descontaron ' + horasTxt(r.desc.minTarde) +
        ' de retardo por ' + mx(r.desc.porRetardos) +
        (r.faltas.length ? '. Los ' + r.faltas.length + ' día(s) que faltó no se cobran aparte: ' +
          'el recibo paga únicamente los días que checó' : '') + '.</p>'"""
,
"el recibo impreso lo explica")

unoR("""        ? '<tr><td><b>Subtotal</b></td><td>'+mx(r.bruto)+'</td>' +
          '<td><b>Descuento</b></td><td>−'+mx(r.desc.total)+'</td></tr>'""",
"""        ? '<tr><td><b>Subtotal</b></td><td>'+mx(r.bruto)+'</td>' +
          '<td><b>Descuento por retardos</b></td><td>−'+mx(r.desc.total)+'</td></tr>'""",
"la etiqueta del recibo impreso")

unoR("""      <label class="sw" style="margin-top:14px"><input type="checkbox" id="recDescuenta">
        Descontar los retardos y las faltas de lo que le toca</label>""",
"""      <label class="sw" style="margin-top:14px"><input type="checkbox" id="recDescuenta">
        Descontar los retardos de lo que le toca</label>""",
"la casilla habla sólo de retardos")

RR.write_text(s, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
