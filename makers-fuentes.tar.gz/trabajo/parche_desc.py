# -*- coding: utf-8 -*-
"""La descripcion para el cliente sigue al articulo.

   `if(!cot.desc)` solo la ponia la PRIMERA vez. Al cambiar de articulo
   —de playera a camisa polo— la descripcion se quedaba diciendo
   «Playera cuello redondo algodon», y asi se iba la cotizacion al cliente.

   Ahora se actualiza mientras NADIE la haya escrito a mano. Se marca
   `descAuto`: si el usuario la edita, deja de seguir al articulo y se
   respeta lo que escribio, que es lo correcto —la escribio a proposito—."""
import pathlib
R = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = R.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    c = src.count(viejo)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, c))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""    case "c_desc": cot.desc=t.value; return;""",
    """    case "c_desc":
      cot.desc = t.value;
      /* La escribio una persona: de aqui en adelante manda ella. */
      cot.descAuto = false;
      return;""",
    "escribirla a mano la fija")

uno("""  if(a){ cot.costoArt = a.costo; cot.precioArt = num(a.precio); if(!cot.desc) cot.desc = a.nombre; }""",
    """  if(a){
    cot.costoArt = a.costo; cot.precioArt = num(a.precio);
    /* Sigue al articulo mientras nadie la haya escrito a mano. Tambien
       sigue cuando lo que dice es el nombre de OTRO articulo del catalogo:
       eso es que venia de automatico aunque no estuviera marcada, como
       pasa con las cotizaciones de antes de este cambio. */
    const puesta = (cot.desc||"").trim();
    const deOtro = puesta && (cat.articulos||[]).some(x=>x.nombre === puesta);
    if(!puesta || cot.descAuto !== false || deOtro){
      cot.desc = a.nombre;
      cot.descAuto = true;
    }
  }""",
    "la descripción sigue al artículo")

R.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
