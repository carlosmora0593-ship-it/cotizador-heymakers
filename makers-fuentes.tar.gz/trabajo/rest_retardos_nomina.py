# -*- coding: utf-8 -*-
"""Retardos y faltas anclados al recibo de pago del restaurante.

   El restaurante ya sabia contar retardos —tiene horario, tolerancia y su
   reporte— pero el recibo los imprimia y ahi se acababa: el descuento se
   sacaba a mano con calculadora, o no se sacaba.

   Faltaban ademas las FALTAS. El recibo solo miraba los dias que la
   persona checo; un dia programado al que no vino simplemente no existia,
   asi que cobraba la semana completa sin haberla trabajado.

   El descuento solo aplica a quien se le paga por periodo fijo. A quien se
   le paga POR HORA no se le descuenta nada: las horas que no trabajo nunca
   se le contaron."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""      <div id="recResumen" style="margin-top:16px"></div>""",
    """      <label class="sw" style="margin-top:14px"><input type="checkbox" id="recDescuenta">
        Descontar los retardos y las faltas de lo que le toca</label>
      <div id="recResumen" style="margin-top:16px"></div>""",
    "la casilla del descuento")

uno("""function cuentaPeriodo(u, desde, hasta){""",
    """/* Los dias del periodo, uno por uno. Hace falta recorrerlos TODOS —no
   solo los que checo— porque una falta es justamente un dia sin checada. */
function diasDelPeriodo(desde, hasta){
  const out = [];
  if(!desde || !hasta || desde > hasta) return out;
  const d = new Date(desde + "T12:00:00"), fin = new Date(hasta + "T12:00:00");
  let guarda = 0;
  while(d <= fin && guarda++ < 400){
    out.push(d.getFullYear()+"-"+dos(d.getMonth()+1)+"-"+dos(d.getDate()));
    d.setDate(d.getDate() + 1);
  }
  return out;
}
/* Un dia programado al que no vino. Hoy no cuenta: todavia puede llegar. */
function faltasDe(u, desde, hasta){
  const hoy = hoyISO();
  return diasDelPeriodo(desde, hasta).filter(f=>{
    if(f >= hoy) return false;
    if(!entradaEsperada(u, f)) return false;        // ese dia descansa
    return !primerEntrada(u.id, f);
  });
}
/* Cuanto vale un dia y una hora de esta persona. Por hora no aplica:
   lo que no trabajo no se le pago nunca. */
function valorDia(u){
  const p = pagoDe(u), fp = FORMAS_PAGO[p.forma] || FORMAS_PAGO.semana;
  if(p.forma === "hora" || !fp.dias) return 0;
  return num(p.monto) / fp.dias;
}
function jornadaHoras(u){
  const h = horarioDe(u);
  const dias = DIAS_SEM.map(d=>h[d.k]).filter(x=>x && !x.libre && x.e && x.s);
  if(!dias.length) return 8;
  const min = dias.reduce((s,x)=> s + Math.max(0, minutosDe(x.s) - minutosDe(x.e)), 0);
  return Math.max(1, (min / dias.length) / 60);
}
function descuentoDe(u, r){
  const dia = valorDia(u);
  if(!dia) return {aplica:false, faltas:r.faltas.length, minTarde:r.tardeSinJust,
                   porFaltas:0, porRetardos:0, total:0};
  const hora = dia / jornadaHoras(u);
  const porFaltas   = r.faltas.length * dia;
  const porRetardos = (r.tardeSinJust / 60) * hora;
  return {aplica:true, faltas:r.faltas.length, minTarde:r.tardeSinJust,
          porFaltas, porRetardos, total: porFaltas + porRetardos};
}
const descuentaOn = () => !!P.descuentaRetardos;

function cuentaPeriodo(u, desde, hasta){""",
    "faltas y valor del descuento")

uno("""  return {dias, min, horas, monto, forma: fp,
          tarde: dias.reduce((s,x)=>s+x.tarde,0),
          sinJust: dias.filter(x=>x.tarde && !x.just).length};
}""",
    """  const faltas = faltasDe(u, desde, hasta);
  const r = {dias, min, horas, monto, forma: fp, faltas,
             tarde: dias.reduce((s,x)=>s+x.tarde,0),
             tardeSinJust: dias.reduce((s,x)=> s + (x.just ? 0 : x.tarde), 0),
             sinJust: dias.filter(x=>x.tarde && !x.just).length};
  r.desc = descuentoDe(u, r);
  /* Lo que se paga ya con el descuento, si esta prendido. El bruto se
     guarda aparte para que el recibo pueda enseñar las dos cifras. */
  r.bruto = monto;
  r.monto = descuentaOn() && r.desc.aplica ? Math.max(0, monto - r.desc.total) : monto;
  return r;
}""",
    "el descuento dentro del periodo")

# ---- la pantalla ----
uno("""    (r.sinJust ? '<p class="note" style="margin-top:12px">Tiene <b>' + r.sinJust +
      ' retardo(s) sin justificar</b> en el periodo. El recibo los imprime: el descuento, si lo hay, lo decides tú.</p>' : "") +""",
    """    (r.faltas.length ? '<p class="note" style="margin-top:12px;border-left-color:var(--mal)">' +
      'Faltó <b>' + r.faltas.length + ' día(s)</b> que tenía programados: ' +
      esc(r.faltas.join(", ")) + '.</p>' : "") +
    (r.sinJust ? '<p class="note" style="margin-top:12px">Tiene <b>' + r.sinJust +
      ' retardo(s) sin justificar</b>, ' + horasTxt(r.tardeSinJust) + ' en total.</p>' : "") +
    (r.desc.total ? '<div class="note" style="margin-top:12px;border-left-color:' +
      (descuentaOn() ? 'var(--mal)' : 'var(--warn)') + '">' +
      '<b>Descuento por retardos y faltas: ' + mx(r.desc.total) + '</b><br>' +
      (r.desc.porFaltas ? r.desc.faltas + ' falta(s) × ' + mx(valorDia(u)) + ' el día = ' +
        mx(r.desc.porFaltas) + '<br>' : '') +
      (r.desc.porRetardos ? horasTxt(r.desc.minTarde) + ' de retardo × ' +
        mx(valorDia(u)/jornadaHoras(u)) + ' la hora = ' + mx(r.desc.porRetardos) + '<br>' : '') +
      (descuentaOn()
        ? 'Ya está restado: de ' + mx(r.bruto) + ' le quedan <b>' + mx(r.monto) + '</b>.'
        : 'No se está restando. Préndelo arriba si quieres descontarlo.') +
      '</div>'
     : (!r.desc.aplica && (r.faltas.length || r.sinJust)
        ? '<p class="note" style="margin-top:12px">A ' + esc(u.nombre||"") + ' se le paga por hora, ' +
          'así que no hay nada que descontar: las horas que no trabajó nunca se le contaron.</p>'
        : "")) +""",
    "el descuento en pantalla")

uno("""  if(e.target.id === "recQuien" || e.target.id === "recDesde" || e.target.id === "recHasta"){ pintaRecibo(); return; }""",
    """  if(e.target.id === "recQuien" || e.target.id === "recDesde" || e.target.id === "recHasta"){ pintaRecibo(); return; }
  if(e.target.id === "recDescuenta"){ P.descuentaRetardos = e.target.checked; persist(); pintaRecibo(); return; }""",
    "prender y apagar el descuento")

uno("""  if(!$("#recDesde").value) ponPeriodo("semana"); else pintaRecibo();""",
    """  const chk = $("#recDescuenta"); if(chk) chk.checked = descuentaOn();
  if(!$("#recDesde").value) ponPeriodo("semana"); else pintaRecibo();""",
    "la casilla recuerda su estado")

# ---- el papel ----
uno("""    '<table class="datos" style="margin-top:14px">' +
      '<tr><td><b>Días trabajados</b></td><td>'+r.dias.length+'</td>' +
      '<td><b>Horas checadas</b></td><td>'+horasTxt(r.min)+'</td></tr>' +
      '<tr><td><b>Retardos</b></td><td>'+(r.tarde?horasTxt(r.tarde):"ninguno")+
        (r.sinJust?' ('+r.sinJust+' sin justificar)':'')+'</td>' +
      '<td><b>Total a pagar</b></td><td class="tot">'+mx(r.monto)+'</td></tr></table>' +""",
    """    '<table class="datos" style="margin-top:14px">' +
      '<tr><td><b>Días trabajados</b></td><td>'+r.dias.length+'</td>' +
      '<td><b>Horas checadas</b></td><td>'+horasTxt(r.min)+'</td></tr>' +
      '<tr><td><b>Retardos</b></td><td>'+(r.tarde?horasTxt(r.tarde):"ninguno")+
        (r.sinJust?' ('+r.sinJust+' sin justificar)':'')+'</td>' +
      '<td><b>Faltas</b></td><td>'+(r.faltas.length ? r.faltas.length+" día(s)" : "ninguna")+'</td></tr>' +
      (descuentaOn() && r.desc.total
        ? '<tr><td><b>Subtotal</b></td><td>'+mx(r.bruto)+'</td>' +
          '<td><b>Descuento</b></td><td>−'+mx(r.desc.total)+'</td></tr>'
        : '') +
      '<tr><td><b>Total a pagar</b></td><td class="tot" colspan="3">'+mx(r.monto)+'</td></tr></table>' +
    (descuentaOn() && r.desc.total
      ? '<p class="pie" style="margin-top:8px">Se descontaron ' +
        (r.desc.porFaltas ? r.desc.faltas + ' falta(s) por ' + mx(r.desc.porFaltas) : '') +
        (r.desc.porFaltas && r.desc.porRetardos ? ' y ' : '') +
        (r.desc.porRetardos ? horasTxt(r.desc.minTarde) + ' de retardo por ' + mx(r.desc.porRetardos) : '') +
        '.</p>'
      : '') +""",
    "el descuento en el recibo impreso")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
