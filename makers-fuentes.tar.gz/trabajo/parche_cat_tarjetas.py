# -*- coding: utf-8 -*-
"""El Catalogo deja de ser un muro de tablas y se abre con azulejos."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# 1. estilos
uno("""/* ---- lanzador de aplicaciones ---- */""",
    secciones.CSS + """
/* ---- lanzador de aplicaciones ---- */""", "estilos del lanzador de sección")

# 2. el lanzador y la barra, arriba de la sección
uno("""<section id="tab-cat" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Artículos</h2>""",
    """<section id="tab-cat" hidden>
  """ + secciones.barra("cat", "Catálogo") + """
  """ + secciones.lanzador("cat") + """
  <div class="card secOculta" data-cat="articulos" style="margin-top:20px">
    <header><h2>Artículos</h2>""",
    "el lanzador del catálogo")

# 3. marcar cada tarjeta con su llave
marcas = [
 ("""  <div class="card">
    <header><h2>Técnicas de decorado</h2>""",
  """  <div class="card secOculta" data-cat="tecnicas">
    <header><h2>Técnicas de decorado</h2>""", "técnicas"),
 ("""  <div class="card">
    <header><h2>Servicios y material por medida</h2>""",
  """  <div class="card secOculta" data-cat="servicios">
    <header><h2>Servicios y material por medida</h2>""", "servicios"),
 ("""  <div class="card">
    <header><h2>Tamaños de impresión</h2>""",
  """  <div class="card secOculta" data-cat="tamanos">
    <header><h2>Tamaños de impresión</h2>""", "tamaños"),
 ("""  <div class="card">
    <header><h2>Escalas de volumen</h2>""",
  """  <div class="card secOculta" data-cat="escalas">
    <header><h2>Escalas de volumen</h2>""", "escalas"),
 ("""  <div class="card">
    <header><h2>Cargos extra predefinidos</h2>""",
  """  <div class="card secOculta" data-cat="extras">
    <header><h2>Cargos extra predefinidos</h2>""", "extras"),
 ("""  <div class="card">
    <header><h2>Inventario</h2>""",
  """  <div class="card secOculta" data-cat="inv">
    <header><h2>Inventario</h2>""", "inventario"),
 ("""  <div class="card" id="cardInsumos">""",
  """  <div class="card secOculta" data-cat="insumos" id="cardInsumos">""", "consumibles"),
 ("""  <div class="card" id="cardConsumos">""",
  """  <div class="card secOculta" data-cat="consumos" id="cardConsumos">""", "qué gasta cada cosa"),
 ("""  <div class="card">
    <header><h2>Historial de cambios de precio</h2>""",
  """  <div class="card secOculta" data-cat="hist">
    <header><h2>Historial de cambios de precio</h2>""", "historial"),
]
for v, n, et in marcas: uno(v, n, et)

# 4+5. el motor y las tarjetas del catalogo. El motor va ANTES del registro:
# registraLanzador() corre al cargar el archivo, y si la declaracion de
# SEC_LZ queda mas abajo revienta con «Cannot access before initialization».
uno("""function renderCatalogo(){""",
    secciones.JS + """
/* Los azulejos del Catálogo. El color es seña para encontrarlo sin leer,
   nunca un dato; cada uno lleva su nombre debajo. El número de la esquina es
   cuántos hay, que es lo que de verdad se quiere saber antes de entrar. */
registraLanzador("cat", [
  {id:"articulos", nombre:"Artículos", sub:"lo que vendes", color:"#06B6D4",
   icono:'<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0l-7.2-7.2a2 2 0 0 1-.6-1.4V4.4A1.4 1.4 0 0 1 4.4 3h7.6a2 2 0 0 1 1.4.6l7.2 7.2a2 2 0 0 1 0 2.6Z"/><circle cx="7.5" cy="7.5" r="1.3"/>',
   card:'[data-cat="articulos"]', cuenta:()=>(cat.articulos||[]).length},
  {id:"tecnicas", nombre:"Técnicas", sub:"cómo se decora", color:"#D6127F",
   icono:'<path d="M3 21h4l11-11a2.8 2.8 0 0 0-4-4L3 17Z"/><path d="M14.5 6.5 17.5 9.5"/>',
   card:'[data-cat="tecnicas"]', cuenta:()=>(cat.tecnicas||[]).length},
  {id:"servicios", nombre:"Materiales", sub:"rollos y por medida", color:"#A855F7",
   icono:'<rect x="3" y="7" width="18" height="10" rx="2"/><path d="M7 7V5M12 7V5M17 7V5M7 19v-2M12 19v-2M17 19v-2"/>',
   card:'[data-cat="servicios"]', cuenta:()=>(cat.servicios||[]).length},
  {id:"tamanos", nombre:"Tamaños", sub:"medidas de impresión", color:"#3B82F6",
   icono:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h5M3 15h5M9 3v5M15 3v5"/>',
   card:'[data-cat="tamanos"]', cuenta:()=>(cat.tamanos||[]).length},
  {id:"escalas", nombre:"Escalas", sub:"descuento por volumen", color:"#10B981",
   icono:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
   card:'[data-cat="escalas"]', cuenta:()=>(cat.escalas||[]).length},
  {id:"extras", nombre:"Cargos extra", sub:"urgencia, empaque", color:"#F59E0B",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
   card:'[data-cat="extras"]', cuenta:()=>(cat.extras||[]).length},
  {id:"insumos", nombre:"Consumibles", sub:"tinta, polvo, hilo", color:"#14B8A6",
   icono:'<path d="M12 3s6 6.4 6 10a6 6 0 0 1-12 0c0-3.6 6-10 6-10Z"/>',
   card:'[data-cat="insumos"]', cuenta:()=>(cat.insumos||[]).length},
  {id:"consumos", nombre:"Qué gasta cada cosa", sub:"los amarres", color:"#8B5CF6",
   icono:'<path d="M9.5 14.5 14.5 9.5"/><path d="M7.8 11.2 6 13a3.5 3.5 0 0 0 5 5l1.8-1.8"/><path d="M16.2 12.8 18 11a3.5 3.5 0 0 0-5-5l-1.8 1.8"/>',
   card:'[data-cat="consumos"]', cuenta:()=>(cat.consumos||[]).length},
  {id:"inv", nombre:"Existencias", sub:"mover inventario", color:"#22C55E",
   icono:'<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5Z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
   card:'[data-cat="inv"]', cuenta:()=>(cat.articulos||[]).filter(a=>num(a.existencia)!==0).length},
  {id:"hist", nombre:"Historial", sub:"cambios de precio", color:"#64748B",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
   card:'[data-cat="hist"]', cuenta:()=>(cat.hist||[]).length}
], "Catálogo");

function renderCatalogo(){""",
    "las tarjetas del catálogo")

# 6. pintar el lanzador al renderizar el catálogo
uno("""  catqPintaPie();
  renderInsumos(); renderConsumos();
  renderInventario();""",
    """  catqPintaPie();
  renderInsumos(); renderConsumos();
  pintaLanzadorSec("cat");
  renderInventario();""",
    "el lanzador se pinta con el catálogo")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
