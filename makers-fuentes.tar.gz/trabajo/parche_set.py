# -*- coding: utf-8 -*-
"""Ajustes con azulejos, y los enlaces profundos que los azulejos rompian.

   Ajustes eran diez tarjetas apiladas y la primera —Parametros de precio—
   es un muro de campos. Para llegar a «Facturacion electronica» habia que
   pasar de largo por utilidad, IVA, folios, claves, apariencia y equipo.

   Lo segundo que trae este parche es un arreglo que ya hacia falta desde
   el Catalogo: el tablero manda a tarjetas por su ancla («#equipoCaja»,
   «#cardExp», «#arcCompras»). Con azulejos esas tarjetas nacen tapadas, y
   el scrollIntoView bajaba a un elemento invisible: el usuario entraba a
   la seccion y se quedaba viendo los azulejos sin saber a cual iba. Ahora
   se busca cual azulejo contiene el ancla y se abre primero."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# ---------- 1. el lanzador al entrar a Ajustes ----------
uno("""<section id="tab-set" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Parámetros de precio</h2></header>""",
    """<section id="tab-set" hidden>
  """ + secciones.barra("set", "Ajustes") + """
  """ + secciones.lanzador("set") + """
  <div class="card secOculta" data-set="precio" style="margin-top:20px">
    <header><h2>Parámetros de precio</h2></header>""",
    "el lanzador de ajustes")

# ---------- 2. cada tarjeta con su llave ----------
marcas = [
 ('permisos', '  <div class="card" data-solo-admin>\n    <header><h2>Equipo y permisos</h2>',
             '  <div class="card secOculta" data-set="permisos" data-solo-admin>\n    <header><h2>Equipo y permisos</h2>'),
 ('folios',   '  <div class="card" data-solo-admin>\n    <header><h2>Folios</h2>',
             '  <div class="card secOculta" data-set="folios" data-solo-admin>\n    <header><h2>Folios</h2>'),
 ('claves',   '  <div class="card" data-solo-admin>\n    <header><h2>Claves y bloqueo</h2>',
             '  <div class="card secOculta" data-set="claves" data-solo-admin>\n    <header><h2>Claves y bloqueo</h2>'),
 ('cobro',    '  <div class="card">\n    <header><h2>Cómo se cobra la impresión</h2>',
             '  <div class="card secOculta" data-set="cobro">\n    <header><h2>Cómo se cobra la impresión</h2>'),
 ('tema',     '  <div class="card">\n    <header><h2>Apariencia</h2>',
             '  <div class="card secOculta" data-set="tema">\n    <header><h2>Apariencia</h2>'),
 ('altas',    '  <div class="card" data-solo-admin>\n    <header><h2>Equipo</h2>',
             '  <div class="card secOculta" data-set="altas" data-solo-admin>\n    <header><h2>Equipo</h2>'),
 ('empresa',  '  <div class="card">\n    <header><h2>Datos de tu empresa</h2>',
             '  <div class="card secOculta" data-set="empresa">\n    <header><h2>Datos de tu empresa</h2>'),
 ('fiscal',   '  <div class="card" id="cardFiscal">',
             '  <div class="card secOculta" data-set="fiscal" id="cardFiscal">'),
 ('timbrado', '  <div class="card" id="cardTimbrado">',
             '  <div class="card secOculta" data-set="timbrado" id="cardTimbrado">'),
]
for llave, viejo, nuevo in marcas:
    uno(viejo, nuevo, "tarjeta de ajustes: " + llave)

# ---------- 3. abrir por ancla (arregla tambien arc, com y ven) ----------
uno("""/* Al entrar a la sección siempre se ve el lanzador, no lo último que se
   abrió: entrar al Catálogo y caer en «Escalas de volumen» desorienta. */""",
    """/* El tablero y el menú de la cuenta mandan a una tarjeta por su ancla
   («#equipoCaja», «#cardExp»). Con azulejos esa tarjeta nace tapada, así
   que antes de bajar a ella hay que abrir el azulejo que la contiene. */
function abrePorAncla(sel){
  let el = null;
  try{ el = document.querySelector(sel); }catch(e){ return false; }
  if(!el) return false;
  const sec = el.closest("section[id^='tab-']"); if(!sec) return false;
  const tab = sec.id.replace(/^tab-/, "");
  const cfg = SEC_LZ[tab]; if(!cfg) return false;
  const t = cfg.tarjetas.find(x=>{
    try{
      return Array.from(sec.querySelectorAll(x.card))
        .some(c=> c === el || c.contains(el));
    }catch(e){ return false; }
  });
  if(!t || t.accion) return false;
  abreTarjetaSec(tab, t.id);
  return true;
}
window.abrePorAncla = abrePorAncla;
/* Al entrar a la sección siempre se ve el lanzador, no lo último que se
   abrió: entrar al Catálogo y caer en «Escalas de volumen» desorienta. */""",
    "abrir la tarjeta por su ancla")

# ---------- 4. los azulejos ----------
uno("""/* Los azulejos de Compras.""",
    """/* Los azulejos de Ajustes. Diez tarjetas que no se parecen en nada entre
   ellas: tres de dinero, tres de gente, dos de la empresa y dos del SAT.
   Puestas en fila no se distinguian; de azulejos, cada una se busca por lo
   que es. */
function sinClaveCuenta(){
  try{ return equipo.filter(u=>u.activo !== false && !String(u.pin||"").trim()).length; }
  catch(e){ return 0; }
}
registraLanzador("set", [
  {id:"precio", nombre:"Parámetros de precio", sub:"utilidad, IVA y redondeo", color:"#0680AB",
   icono:'<path d="M12 2v20"/><path d="M17 6.5c0-1.9-2.2-3-5-3s-5 1.1-5 3 2.2 2.8 5 3.3 5 1.4 5 3.4-2.2 3.3-5 3.3-5-1.4-5-3.3"/>',
   card:'[data-set="precio"]'},
  {id:"cobro", nombre:"Material y mano de obra", sub:"cómo se cobra la impresión", color:"#0E7C57",
   icono:'<rect x="3" y="7" width="18" height="12" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M3 13h18"/>',
   card:'[data-set="cobro"]'},
  {id:"folios", nombre:"Folios", sub:"las letras de tus documentos", color:"#B26A00", soloAdmin:true,
   icono:'<path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h4"/>',
   card:'[data-set="folios"]'},
  {id:"altas", nombre:"Quién entra a la cuenta", sub:"da de alta a tu gente", color:"#D2541F", soloAdmin:true,
   icono:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M16 11h6"/>',
   card:'[data-set="altas"]'},
  {id:"permisos", nombre:"Permisos y costos", sub:"qué ve cada rol", color:"#8B5CF6", soloAdmin:true,
   icono:'<path d="M12 3l7 3v6c0 4.2-2.8 7.6-7 9-4.2-1.4-7-4.8-7-9V6Z"/><path d="M9 12l2 2 4-4"/>',
   card:'[data-set="permisos"]'},
  {id:"claves", nombre:"Claves y bloqueo", sub:"el PIN para checar y entrar", color:"#D6127F", soloAdmin:true,
   icono:'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.5" r="1.3"/>',
   card:'[data-set="claves"]', cuenta:sinClaveCuenta},
  {id:"empresa", nombre:"Datos de tu empresa", sub:"lo que sale impreso", color:"#64748B",
   icono:'<path d="M3 21V7l9-4 9 4v14"/><path d="M9 21v-6h6v6"/><path d="M7 11h.01M17 11h.01"/>',
   card:'[data-set="empresa"]'},
  {id:"tema", nombre:"Apariencia", sub:"tema claro u oscuro", color:"#14B8A6",
   icono:'<circle cx="12" cy="12" r="4.2"/><path d="M12 2v2.4M12 19.6V22M2 12h2.4M19.6 12H22M5 5l1.7 1.7M17.3 17.3 19 19M19 5l-1.7 1.7M6.7 17.3 5 19"/>',
   card:'[data-set="tema"]'},
  {id:"fiscal", nombre:"Datos fiscales", sub:"RFC y domicilio del SAT", color:"#0680AB",
   icono:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h5"/>',
   card:'[data-set="fiscal"]'},
  {id:"timbrado", nombre:"Facturación electrónica", sub:"cómo se timbran tus facturas", color:"#8B5CF6",
   icono:'<path d="M4 4h16v13l-2.7-1.6L14.7 17 12 15.4 9.3 17 6.7 15.4 4 17Z"/><path d="M8 9h8M8 12h5"/>',
   card:'[data-set="timbrado"]'}
], "Ajustes");

/* Los azulejos de Compras.""",
    "los azulejos de ajustes")

uno("""  if(b.dataset.tab==="com") reiniciaSec("com");""",
    """  if(b.dataset.tab==="com") reiniciaSec("com");
  if(b.dataset.tab==="set") reiniciaSec("set");""",
    "al entrar a ajustes")

# ---------- 5. el tablero que manda a una tarjeta ----------
uno("""    if(x.foco){
      const el = document.querySelector(x.foco);
      if(!el){ return; }
      el.scrollIntoView({behavior:"smooth", block:"start"});""",
    """    if(x.foco){
      const el = document.querySelector(x.foco);
      if(!el){ return; }
      /* Si vive dentro de un azulejo, primero se abre: si no, se baja a
         una tarjeta tapada y no se ve nada. */
      try{ abrePorAncla(x.foco); }catch(e){}
      el.scrollIntoView({behavior:"smooth", block:"start"});""",
    "el tablero abre el azulejo del ancla")

uno("""      {t:"set",  ico:"gente",     d:"equipo",   et:"Equipo y permisos",      det:"Quién entra, qué ve, quién cotiza y quién comisiona"}""",
    """      {t:"set",  ico:"gente",     d:"equipo",   et:"Equipo y permisos",      det:"Quién entra, qué ve, quién cotiza y quién comisiona", foco:"#equipoCaja"}""",
    "el tablero apunta al equipo de la cuenta")

# el ancla que el tablero pedia para proveedores no existia
uno("""  <div class="card secOculta" data-com="prov">
    <header><h2>Proveedores</h2>""",
    """  <div class="card secOculta" data-com="prov" id="cardProv">
    <header><h2>Proveedores</h2>""",
    "el ancla de proveedores")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
