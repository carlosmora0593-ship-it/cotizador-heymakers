# -*- coding: utf-8 -*-
"""Las fotos del catalogo dejan de perderse al recargar.

   Las fotos viven en un bucket PRIVADO de Supabase —y tienen que seguir
   privadas: son los disenos de los clientes del taller, y los talleres
   compiten entre si—. Para verlas se usa una URL firmada, y lo que se
   guardaba en el catalogo era esa URL.

   El problema: una URL firmada caduca. Mientras no caduca todo se ve
   bien, y el dia que caduca la foto desaparece sin decir por que. Guardar
   una direccion que vence es guardar una bomba de tiempo.

   El arreglo: lo que se guarda es la RUTA del archivo (`fotoRef`), que no
   vence nunca, y la URL se vuelve a firmar cada vez que se abre la app.
   Lo mismo para el logo y para los documentos del expediente."""
import pathlib

# ---------- 1. cuenta.js: saber firmar de nuevo ----------
C = pathlib.Path('/home/claude/trabajo/cuenta.js')
js = C.read_text(encoding='utf-8')
v = """  async list(){ return {assets:[], usage:{}}; },"""
n = """  /* Vuelve a firmar una ruta que ya esta guardada. Una URL firmada vence;
     la ruta no. Por eso lo que se guarda es la ruta y la URL se pide otra
     vez cada que se abre la app. */
  async url(ref){
    if(!ref) return "";
    try{
      const {data} = await SB.storage.from("disenos").createSignedUrl(ref, 60*60*24*7);
      return (data && data.signedUrl) || "";
    }catch(e){ return ""; }
  },
  /* Varias de un golpe: una cuenta con cien articulos no puede hacer cien
     viajes al servidor uno por uno. */
  async urls(refs){
    const limpias = (refs||[]).filter(Boolean);
    if(!limpias.length) return {};
    try{
      const {data} = await SB.storage.from("disenos").createSignedUrls(limpias, 60*60*24*7);
      const m = {};
      (data||[]).forEach(x=>{ if(x && x.path && x.signedUrl) m[x.path] = x.signedUrl; });
      return m;
    }catch(e){ return {}; }
  },
  async list(){ return {assets:[], usage:{}}; },"""
assert js.count(v) == 1, js.count(v)
C.write_text(js.replace(v, n), encoding='utf-8')
print("ok cuenta.js · firmar de nuevo")

# ---------- 2. el cotizador refresca las URLs al abrir ----------
R = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = R.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    c = src.count(viejo)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, c))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""async function subeFotoArticulo(id, file){""",
    """/* ---------- refrescar las fotos ----------
   Lo que se guarda es la ruta; la URL se vuelve a firmar al abrir. Si el
   puente no sabe firmar —cuenta local, o una version vieja de cuenta.js—
   se queda con la URL que tenia y no se rompe nada. */
async function refrescaFotos(){
  if(!ASSETS || typeof ASSETS.urls !== "function") return;
  const arts = (cat.articulos||[]).filter(a=>a.fotoRef);
  const refs = arts.map(a=>a.fotoRef);
  if(P.empresa && P.empresa.logoRef) refs.push(P.empresa.logoRef);
  if(!refs.length) return;
  let m = {};
  try{ m = await ASSETS.urls(refs); }catch(e){ return; }
  let cambio = false;
  arts.forEach(a=>{ const u = m[a.fotoRef]; if(u && u !== a.foto){ a.foto = u; cambio = true; } });
  if(P.empresa && P.empresa.logoRef && m[P.empresa.logoRef]){
    P.empresa.logo = m[P.empresa.logoRef]; cambio = true;
  }
  if(cambio){
    /* No se llama persist(): la URL firmada es de usar y tirar, y escribirla
       de vuelta solo gastaria escrituras. Lo que importa ya esta guardado,
       que es la ruta. */
    renderTabla("articulos");
    if(typeof pintaSelectorArt === "function") pintaSelectorArt();
    if(typeof aplicaMarca === "function") aplicaMarca();
  }
}

async function subeFotoArticulo(id, file){""",
    "refrescaFotos")

# el logo también guarda su ruta
uno("""  try{ const res = await ASSETS.upload(f); P.empresa.logo = res.url; persist(); aplicaMarca(); toast("Logo actualizado"); }""",
    """  try{ const res = await ASSETS.upload(f); P.empresa.logo = res.url; P.empresa.logoRef = res.id || "";
       persist(); aplicaMarca(); toast("Logo actualizado"); }""",
    "el logo guarda su ruta")

R.write_text(src, encoding='utf-8')
print("Listo cotizador. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
