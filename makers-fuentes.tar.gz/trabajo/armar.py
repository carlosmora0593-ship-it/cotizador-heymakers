# -*- coding: utf-8 -*-
"""Arma los archivos publicables a partir de los fuentes de trabajo.

   Reemplaza a build_saas.py / build_restaurant.py, que se perdieron cuando
   el contenedor se reciclo. La cabecera y el pie del index salieron del
   index.html que ya estaba publicado en la computadora de Carlos, asi que
   el resultado es byte por byte el mismo envoltorio que ya funcionaba."""
import pathlib, json, datetime, re, sys

T = pathlib.Path('/home/claude/trabajo')
P = pathlib.Path('/home/claude/publicar')
P.mkdir(exist_ok=True)

sello = datetime.datetime.now().strftime("%Y%m%d-%H%M")

cab = (T/'envoltorio-cab.html').read_text(encoding='utf-8')
pie = (T/'envoltorio-pie.html').read_text(encoding='utf-8')
cot = (T/'cotizador.html').read_text(encoding='utf-8')

# las versiones de los scripts van con el sello, para que el navegador no
# sirva el cuenta.js viejo con el index nuevo
pie = re.sub(r'(cuenta\.js\?v=)[0-9\-]+', r'\g<1>'+sello, pie)
pie = re.sub(r'(diagnostico\.js\?v=)[0-9\-]+', r'\g<1>'+sello, pie)

(P/'index.html').write_text(cab + cot + pie, encoding='utf-8')
print("index.html      %d bytes" % (P/'index.html').stat().st_size)

rest = (T/'makersrestaurant.html').read_text(encoding='utf-8')
(P/'restaurant.html').write_text(rest, encoding='utf-8')
print("restaurant.html %d bytes" % (P/'restaurant.html').stat().st_size)

# lo que no se toca se copia tal cual del respaldo recuperado
R = pathlib.Path('/home/claude/rec/public')
for f in ['lab.html','cuenta.js','lab.js','diagnostico.js']:
    if (T/f).exists(): datos = (T/f).read_bytes()
    else:              datos = (R/f).read_bytes()
    (P/f).write_bytes(datos)
    print("%-15s %d bytes" % (f, len(datos)))

ver = json.loads((R/'version.json').read_text(encoding='utf-8'))
ver['build'] = sello
ver['cotizador'] = sello
ver['restaurant'] = sello
(P/'version.json').write_text(json.dumps(ver, indent=1, ensure_ascii=False) + "\n", encoding='utf-8')
print("version.json    build", sello)
