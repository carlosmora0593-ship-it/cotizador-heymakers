# -*- coding: utf-8 -*-
"""Los PIN dejan de ser campos de contrasena del navegador.

   Carlos reportaba que cada vez que hacia un cambio, Chrome le ofrecia
   «Update password?» con su correo y cuatro puntitos. Esos cuatro puntitos
   NO eran su contrasena: era el PIN de cuatro digitos del equipo.

   Chrome trata CUALQUIER <input type="password"> como una credencial del
   sitio. Los campos de PIN —la clave del gerente, la del cajero, la del
   checador— lo eran, asi que el navegador los emparejaba con el correo con
   el que entro y ofrecia guardar o ACTUALIZAR la contrasena del sitio con
   el PIN. Si alguna vez decia que si, el gestor de Google se quedaba con
   el PIN del taller en lugar de su contrasena de verdad.

   Arreglo: los PIN se escriben en un campo de texto normal, ocultos por
   CSS (-webkit-text-security). Se ven igual de puntitos, siguen siendo
   numericos, y el navegador deja de confundirlos con una credencial.

   La contrasena de ENTRAR si se queda como password: esa si es una
   credencial y ahi el gestor hace bien su trabajo."""
import pathlib
hechos = []

CSS_PIN = """
/* Un PIN no es la contraseña del sitio. Se oculta por CSS para que el
   navegador no lo trate como credencial ni ofrezca guardarlo. */
input.pinSecreto{-webkit-text-security:disc;text-security:disc;
  font-family:"IBM Plex Mono",ui-monospace,monospace;letter-spacing:.18em}
input.pinSecreto.verse{-webkit-text-security:none;text-security:none;letter-spacing:normal}
"""

def arregla(ruta, cambios, ancla_css):
    p = pathlib.Path(ruta)
    s = p.read_text(encoding='utf-8')
    n = s.count(ancla_css)
    if n != 1: raise SystemExit("ALTO: el ancla de estilos aparece %d veces en %s" % (n, ruta))
    s = s.replace(ancla_css, CSS_PIN + ancla_css, 1)
    hechos.append(ruta + " · estilos")
    for viejo, nuevo, et in cambios:
        c = s.count(viejo)
        if c != 1: raise SystemExit("ALTO en «%s» (%s): aparece %d veces." % (et, ruta, c))
        s = s.replace(viejo, nuevo, 1)
        hechos.append(ruta + " · " + et)
    p.write_text(s, encoding='utf-8')

# ---------------- cotizador ----------------
arregla('/home/claude/trabajo/cotizador.html', [
  ('<input id="pinCampo" type="password" inputmode="numeric" maxlength="6" placeholder="••••">',
   '<input id="pinCampo" class="pinSecreto" type="text" inputmode="numeric" maxlength="6" '
   'autocomplete="off" placeholder="••••">',
   "el PIN de la puerta"),
  ("""'<input data-clvpin type="password" inputmode="numeric" maxlength="24" '+""",
   """'<input data-clvpin class="pinSecreto" type="text" inputmode="numeric" maxlength="24" '+""",
   "las claves del equipo"),
], ".avisoStock{margin:0 16px 12px;")

# ---------------- restaurante ----------------
arregla('/home/claude/trabajo/makersrestaurant.html', [
  ('<input id="autoPin" type="password" inputmode="numeric" maxlength="12" autocomplete="off" placeholder="••••">',
   '<input id="autoPin" class="pinSecreto" type="text" inputmode="numeric" maxlength="12" '
   'autocomplete="off" placeholder="••••">',
   "el PIN de autorización"),
  ("""'<td><input data-uk="pin" type="password" inputmode="numeric" maxlength="12" value="'+esc(u.pin||"")+'" placeholder="sin clave"></td>' +""",
   """'<td><input data-uk="pin" class="pinSecreto" type="text" inputmode="numeric" maxlength="12" '+
        'autocomplete="off" value="'+esc(u.pin||"")+'" placeholder="sin clave"></td>' +""",
   "las claves del equipo"),
  ('<input id="accesoPass" type="password" inputmode="numeric" placeholder="Tu clave" autocomplete="current-password">',
   '<input id="accesoPass" class="pinSecreto" type="text" inputmode="numeric" placeholder="Tu clave" '
   'autocomplete="off">',
   "la clave de la puerta del POS"),
], "*{box-sizing:border-box}\nbody{margin:0;background:var(--bg);color:var(--ink);")

# el botón «Ver» del cotizador alterna la clase, ya no el type
p = pathlib.Path('/home/claude/trabajo/cotizador.html')
s = p.read_text(encoding='utf-8')
import re
m = re.search(r'data-clvver[^\n]*\n(?:[^\n]*\n){0,24}?[^\n]*type\s*=\s*["\']?(?:text|password)', s)
print("ojo: revisar el botón Ver manualmente" if not m else "")
pathlib.Path('/home/claude/trabajo/cotizador.html').write_text(s, encoding='utf-8')

print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
