# -*- coding: utf-8 -*-
"""Un azulejo para crear la requisicion.

   El boton «+ Requisicion» vivia en el encabezado de la tarjeta, o sea
   DENTRO de algo que hay que abrir primero. Lo que mas se hace en Compras
   es pedir material, y estaba a dos clics."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""registraLanzador("com", [
  {id:"todas", nombre:"Requisiciones", sub:"todas, como van", color:"#64748B",""",
    """registraLanzador("com", [
  {id:"nueva", nombre:"Nueva requisición", sub:"pedirle a un proveedor", color:"#D2541F",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
   card:'[data-com="req"]',
   accion:()=>{ const b = $("#compNueva"); if(b) b.click();
                else toast("No se encontró el botón de nueva requisición"); }},
  {id:"todas", nombre:"Requisiciones", sub:"todas, como van", color:"#64748B",""",
    "el azulejo de nueva requisición")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
