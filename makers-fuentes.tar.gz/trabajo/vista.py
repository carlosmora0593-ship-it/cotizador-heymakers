# -*- coding: utf-8 -*-
"""Vista previa suelta: el cotizador sin la capa de cuentas.

   La puerta la dibuja cuenta.js. En una prueba local no hay Supabase ni
   config.js, asi que la puerta se queda encima y no deja ver nada. Esta
   vista arma el mismo documento SIN cuenta.js: la app arranca sola, con su
   almacen en el navegador, igual que el PRUEBA-cotizador.html de siempre.

   No se publica nunca: es solo para mirar y para las pruebas."""
import pathlib, re
T = pathlib.Path('/home/claude/trabajo')
V = pathlib.Path('/home/claude/vista'); V.mkdir(exist_ok=True)

cab = (T/'envoltorio-cab.html').read_text(encoding='utf-8')
pie = (T/'envoltorio-pie.html').read_text(encoding='utf-8')
cot = (T/'cotizador.html').read_text(encoding='utf-8')

# fuera los scripts que necesitan red o llaves
for pat in [r'<script src="config\.js[^"]*"></script>\s*',
            r'<script src="https://cdn\.jsdelivr[^"]*"></script>\s*',
            r'<script src="cuenta\.js[^"]*"></script>\s*',
            r'<script src="diagnostico\.js[^"]*"></script>\s*']:
    cab = re.sub(pat, '', cab)
    pie = re.sub(pat, '', pie)

# body.sin-sesion esconde toda la app hasta que cuenta.js confirma la sesion.
# Sin cuenta.js esa clase nunca se quita, asi que aqui se quita a mano.
# Y el arranque lo dispara cuenta.js al confirmar la sesion; aqui se llama
# a mano para que la vista cargue datos igual que la app publicada.
suelta = """<script>
document.addEventListener("DOMContentLoaded", ()=>{ document.body.classList.remove("sin-sesion"); });
document.body && document.body.classList.remove("sin-sesion");
window.addEventListener("load", ()=>{
  if(typeof window.__arranca === "function") setTimeout(window.__arranca, 60);
});
</script>
"""
(V/'preview.html').write_text(cab + cot + suelta + pie, encoding='utf-8')
print("vista/preview.html %d bytes" % (V/'preview.html').stat().st_size)
