# -*- coding: utf-8 -*-
"""Horario, retardos y faltas, anclados a la nomina."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import retardos

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""/* ---- horario y retardos ---- */""", "", "sin ancla previa") if False else None

# 1. estilos
uno(""".avisoStock{margin:0 16px 12px;""", retardos.CSS + """
.avisoStock{margin:0 16px 12px;""", "estilos")

# 2. el motor, después de salarioHora para que exista cuando se use
uno("""function renglonNomina(id, R){""",
    retardos.JS + """
function renglonNomina(id, R){""",
    "el motor de retardos")

# 3. el horario en el expediente
uno("""        <div><label class="f" for="x_jornada">Horas por día</label><input id="x_jornada" type="number" min="0" max="24" step="0.5"></div>
      </div>""",
    """        <div><label class="f" for="x_jornada">Horas por día</label><input id="x_jornada" type="number" min="0" max="24" step="0.5"></div>
      </div>
      <details style="margin-top:14px"><summary style="cursor:pointer;font-size:13px;font-weight:600">Horario de la semana</summary>
        <p class="note" style="margin:10px 0">Con esto se miden los retardos y las faltas. <b>Sin horario no hay
          retardo</b>: un día del que no sabemos a qué hora entraba no se le puede descontar a nadie.</p>
        <div class="horSem" id="x_horario"></div>
        <button class="btn sm ghost horCopia" type="button" id="x_horCopia">Copiar el lunes a toda la semana</button>
      </details>""",
    "el horario en el expediente")

# 4. pintarlo y guardarlo
uno("""  pintaCarpetasExp();
  $("#modalExp").hidden = false;""",
    """  pintaHorario();
  pintaCarpetasExp();
  $("#modalExp").hidden = false;""",
    "pintar el horario al abrir")

uno("""function pintaCarpetasExp(){""",
    """function pintaHorario(){
  const w = $("#x_horario"); if(!w || !expAbierto) return;
  const h = horarioDe(expAbierto);
  w.innerHTML = DIAS_SEM.map(([k, nom])=>{
    const d = h[k] || {};
    return '<div class="horDia'+(d.libre?" libre":"")+'" data-hord="'+k+'">' +
      '<span class="nom">'+esc(nom)+'</span>' +
      '<input type="time" data-horf="entra" value="'+esc(d.entra||"")+'" aria-label="Entra '+esc(nom)+'">' +
      '<input type="time" data-horf="sale" value="'+esc(d.sale||"")+'" aria-label="Sale '+esc(nom)+'">' +
      '<label class="sw" style="white-space:nowrap;font-size:12px"><input type="checkbox" data-horf="libre"'+
        (d.libre?" checked":"")+'> Descanso</label></div>';
  }).join("");
}
document.addEventListener("input", e=>{
  const fila = e.target.closest("[data-hord]"); if(!fila || !expAbierto) return;
  const f = e.target.dataset.horf; if(!f || f === "libre") return;
  horarioDe(expAbierto)[fila.dataset.hord][f] = e.target.value;
  guardaExpediente(expAbierto);
});
document.addEventListener("change", e=>{
  const fila = e.target.closest("[data-hord]"); if(!fila || !expAbierto) return;
  if(e.target.dataset.horf !== "libre") return;
  horarioDe(expAbierto)[fila.dataset.hord].libre = e.target.checked;
  guardaExpediente(expAbierto); pintaHorario();
});
document.addEventListener("click", e=>{
  if(!e.target.closest("#x_horCopia") || !expAbierto) return;
  const h = horarioDe(expAbierto), lun = h.lun || {};
  DIAS_SEM.forEach(([k])=>{ if(k==="lun"||k==="dom") return;
    h[k] = {libre: !!lun.libre, entra: lun.entra||"", sale: lun.sale||""}; });
  guardaExpediente(expAbierto); pintaHorario();
  toast("Lunes copiado de martes a sábado · el domingo se quedó como estaba");
});

function pintaCarpetasExp(){""",
    "el editor de horario")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
