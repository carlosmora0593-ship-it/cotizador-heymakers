# -*- coding: utf-8 -*-
"""La tinta, por color.

   «Tinta DTF (blanco y color)» en un solo renglon esconde lo unico que
   importa: el blanco se lleva la mitad del consumo de un DTF y cuesta mas
   caro. En un renglon no se ve, y es justo el que se acaba primero.

   No hace falta cambiar el motor: ya sabe amarrar N consumibles a un
   material. Lo que faltaba era partir la tinta en sus canales, poder
   capturar el precio POR LITRO —que es como la venden— y ver cuantos
   metros cuadrados rinde cada bote.

   Las cuentas nuevas nacen con los cinco canales. Las que ya existen no se
   tocan solas: hay un boton que lo hace cuando el taller quiera, y deja la
   existencia de cada color en cero, porque repartir a ojo lo que habia en
   un renglon seria inventarle inventario a alguien."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# ---------- 1. la semilla, por canal ----------
uno(""" insumos:[
  {id:"i1",nombre:"Tinta DTF (blanco y color)",unidad:"ml",costo:0.9,existencia:0,minimo:0},
  {id:"i2",nombre:"Polvo termoadhesivo",unidad:"g",costo:0.28,existencia:0,minimo:0},
  {id:"i3",nombre:"Bolsa de celofán",unidad:"pza",costo:1.2,existencia:0,minimo:0},
  {id:"i4",nombre:"Hilo de bordado",unidad:"m",costo:0.05,existencia:0,minimo:0}
 ],""",
""" /* La tinta va por color. El blanco se lleva la mitad del consumo de un
    DTF y se compra más caro: en un solo renglón eso no se ve, y es el que
    se acaba primero. Los precios están por litro, que es como se vende, y
    aquí se guardan por mililitro. */
 insumos:[
  {id:"i1c",nombre:"Tinta DTF · Cian",unidad:"ml",costo:0.9,existencia:0,minimo:0,canal:"c"},
  {id:"i1m",nombre:"Tinta DTF · Magenta",unidad:"ml",costo:0.9,existencia:0,minimo:0,canal:"m"},
  {id:"i1y",nombre:"Tinta DTF · Amarillo",unidad:"ml",costo:0.9,existencia:0,minimo:0,canal:"y"},
  {id:"i1k",nombre:"Tinta DTF · Negro",unidad:"ml",costo:0.9,existencia:0,minimo:0,canal:"k"},
  {id:"i1w",nombre:"Tinta DTF · Blanco",unidad:"ml",costo:1.1,existencia:0,minimo:0,canal:"w"},
  {id:"i2",nombre:"Polvo termoadhesivo",unidad:"g",costo:0.28,existencia:0,minimo:0},
  {id:"i3",nombre:"Bolsa de celofán",unidad:"pza",costo:1.2,existencia:0,minimo:0},
  {id:"i4",nombre:"Hilo de bordado",unidad:"m",costo:0.05,existencia:0,minimo:0}
 ],""", "los cinco canales en la semilla")

uno(""" consumos:[
  {id:"c1",ancla:"servicio",anclaId:"sv1",insumoId:"i1",cant:50,por:"m2"},
  {id:"c2",ancla:"servicio",anclaId:"sv1",insumoId:"i2",cant:100,por:"m2"}
 ],""",
""" /* 50 ml de tinta por m² impreso, repartidos como los reparte un DTF:
    6 de cada color y 25 de blanco. Son promedios para arrancar; los tuyos
    salen del reporte de tinta del RIP o de pesar los botes. */
 consumos:[
  {id:"c1c",ancla:"servicio",anclaId:"sv1",insumoId:"i1c",cant:6,por:"m2"},
  {id:"c1m",ancla:"servicio",anclaId:"sv1",insumoId:"i1m",cant:6,por:"m2"},
  {id:"c1y",ancla:"servicio",anclaId:"sv1",insumoId:"i1y",cant:6,por:"m2"},
  {id:"c1k",ancla:"servicio",anclaId:"sv1",insumoId:"i1k",cant:7,por:"m2"},
  {id:"c1w",ancla:"servicio",anclaId:"sv1",insumoId:"i1w",cant:25,por:"m2"},
  {id:"c2",ancla:"servicio",anclaId:"sv1",insumoId:"i2",cant:100,por:"m2"}
 ],""", "el consumo repartido por canal")

uno("""   tecnicas:["t1"], servicios:["sv1","sv2"], insumos:["i1","i2"], familias:["Textil","Gorras"]},""",
    """   tecnicas:["t1"], servicios:["sv1","sv2"], insumos:["i1c","i1m","i1y","i1k","i1w","i2"], familias:["Textil","Gorras"]},""",
    "el asistente carga los canales")

# ---------- 2. precio por litro y rendimiento en la tabla ----------
uno("""  t.innerHTML = '<thead><tr><th>Consumible</th><th style="width:110px">Unidad</th>' +
    '<th style="width:120px" class="num">Costo por unidad</th>' +
    '<th style="width:110px" class="num">Existencia</th>' +
    '<th style="width:110px" class="num">Mínimo</th><th style="width:44px"></th></tr></thead><tbody>' +
    (ls.length ? ls.map(i=>
      '<tr data-ins="'+esc(i.id)+'">' +
      '<td><input value="'+esc(i.nombre||"")+'" data-insf="nombre" placeholder="Tinta, polvo, hilo, bolsa…"></td>' +
      '<td><select data-insf="unidad">' + UNIDADES_INS.map(u=>
          '<option value="'+u[0]+'"'+(i.unidad===u[0]?" selected":"")+'>'+abrevIns(u[0])+'</option>').join("") +
        '</select></td>' +
      '<td><input type="number" min="0" step="0.0001" value="'+num(i.costo)+'" data-insf="costo"></td>' +
      '<td><input type="number" step="0.01" value="'+num(i.existencia)+'" data-insf="existencia"></td>' +
      '<td><input type="number" min="0" step="0.01" value="'+num(i.minimo)+'" data-insf="minimo"></td>' +
      '<td><button class="quita" data-insdel="'+esc(i.id)+'" title="Quitar">&times;</button></td></tr>').join("")
    : '<tr><td colspan="6" style="color:var(--ink-3);padding:16px">Todavía no hay consumibles. ' +
      'Agrega la tinta, el polvo o las bolsas que de verdad gastas.</td></tr>') + '</tbody>';""",
"""  t.innerHTML = '<thead><tr><th>Consumible</th><th style="width:96px">Unidad</th>' +
    '<th style="width:118px" class="num">Costo por unidad</th>' +
    '<th style="width:118px" class="num">Por litro / kilo</th>' +
    '<th style="width:104px" class="num">Existencia</th>' +
    '<th style="width:96px" class="num">Mínimo</th>' +
    '<th style="width:120px">Rinde</th><th style="width:70px"></th></tr></thead><tbody>' +
    (ls.length ? ls.map(i=>
      '<tr data-ins="'+esc(i.id)+'">' +
      '<td>'+gotaIns(i)+'<input value="'+esc(i.nombre||"")+'" data-insf="nombre" placeholder="Tinta, polvo, hilo, bolsa…" style="width:calc(100% - 22px)"></td>' +
      '<td><select data-insf="unidad">' + UNIDADES_INS.map(u=>
          '<option value="'+u[0]+'"'+(i.unidad===u[0]?" selected":"")+'>'+abrevIns(u[0])+'</option>').join("") +
        '</select></td>' +
      '<td><input type="number" min="0" step="0.0001" value="'+num(i.costo)+'" data-insf="costo"></td>' +
      /* Los botes se compran por litro o por kilo, no por mililitro. Si se
         captura el precio del bote, el por-unidad sale solo y al revés. */
      '<td>'+(porMil(i)
        ? '<input type="number" min="0" step="1" value="'+(Math.round(num(i.costo)*1000*100)/100)+'" data-insf="costoMil" title="Lo que te cuesta el litro o el kilo">'
        : '<span class="hint" style="color:var(--ink-3)">—</span>')+'</td>' +
      '<td><input type="number" step="0.01" value="'+num(i.existencia)+'" data-insf="existencia"></td>' +
      '<td><input type="number" min="0" step="0.01" value="'+num(i.minimo)+'" data-insf="minimo"></td>' +
      '<td class="insRinde">'+rindeIns(i)+'</td>' +
      '<td style="white-space:nowrap">'+
        (esTinta(i) && !i.canal ? '<button class="btn icon sm" data-inspartir="'+esc(i.id)+'" title="Partirla en cian, magenta, amarillo, negro y blanco">⑁</button> ' : '')+
        '<button class="quita" data-insdel="'+esc(i.id)+'" title="Quitar">&times;</button></td></tr>').join("")
    : '<tr><td colspan="8" style="color:var(--ink-3);padding:16px">Todavía no hay consumibles. ' +
      'Agrega la tinta, el polvo o las bolsas que de verdad gastas.</td></tr>') + '</tbody>';""",
    "la tabla de consumibles por canal")

# ---------- 3. los ayudantes ----------
uno("""function renderInsumos(){""",
"""/* Un bote se vende por litro o por kilo; el consumo se mide en mililitros
   o en gramos. Las dos cifras son la misma, y cada quien tiene en la cabeza
   la suya. */
const porMil = i => i && (i.unidad === "ml" || i.unidad === "g");
const esTinta = i => /tinta/i.test((i && i.nombre) || "");
const COLOR_CANAL = {c:"#00A6E0", m:"#E6007E", y:"#FFD500", k:"#1C1619", w:"#FFFFFF", v:"#9AA7B4"};
function gotaIns(i){
  if(!i || !i.canal) return "";
  return '<span class="gotaIns" style="background:'+esc(COLOR_CANAL[i.canal] || "var(--ink-3)")+'" aria-hidden="true"></span>';
}
/* Cuántos metros cuadrados aguanta lo que hay. Es el número que contesta
   «¿me alcanza para el pedido?» sin sacar la calculadora, y el que enseña
   que el blanco se acaba tres veces antes que el negro. */
function rindeIns(i){
  if(!i) return "";
  const cs = (cat.consumos||[]).filter(c=>c.insumoId === i.id && c.por === "m2" && num(c.cant) > 0);
  if(!cs.length) return '<span class="hint" style="color:var(--ink-3)">sin amarre</span>';
  const porM2 = cs.reduce((s,c)=>s+num(c.cant), 0);
  const m2 = num(i.existencia) / porM2;
  return '<span class="insM2">'+ (Math.round(m2*10)/10).toLocaleString("es-MX") +' m²</span>' +
         '<small>'+ (Math.round(porM2*10)/10) +' '+ abrevIns(i.unidad) +' el m²</small>';
}
/* Partir la tinta en sus canales. El reparto es el de un DTF: seis de cada
   color y veinticinco de blanco por cada cincuenta. La EXISTENCIA se deja
   en cero a propósito: repartir a ojo lo que había en un renglón sería
   inventarle inventario al taller. */
const CANALES_TINTA = [["c","Cian",0.12],["m","Magenta",0.12],["y","Amarillo",0.12],
                       ["k","Negro",0.14],["w","Blanco",0.50]];
function parteTinta(id){
  const i = (cat.insumos||[]).find(x=>x.id === id); if(!i) return;
  const base = (i.nombre || "Tinta").replace(/\\s*\\((blanco y color|color y blanco)\\)\\s*/i, "").trim();
  const amarres = (cat.consumos||[]).filter(c=>c.insumoId === id);
  const nuevos = CANALES_TINTA.map(ch=>({
    id: uid(), nombre: base + " · " + ch[1], unidad: i.unidad || "ml",
    costo: num(i.costo), existencia: 0, minimo: 0, canal: ch[0]
  }));
  cat.insumos = (cat.insumos||[]).filter(x=>x.id !== id).concat(nuevos);
  /* Cada amarre que tenía la tinta se reparte entre los cinco canales. */
  const otros = (cat.consumos||[]).filter(c=>c.insumoId !== id);
  const partidos = [];
  amarres.forEach(c=> CANALES_TINTA.forEach((ch, n)=> partidos.push(
    Object.assign({}, c, {id: uid(), insumoId: nuevos[n].id,
                          cant: Math.round(num(c.cant) * ch[2] * 1000) / 1000}))));
  cat.consumos = otros.concat(partidos);
  persist();
  renderInsumos(); renderConsumos();
  if(typeof renderInvInsumos === "function") renderInvInsumos();
  toast("Tinta partida en cinco colores. Captura lo que tienes de cada uno: la existencia quedó en cero.");
}

function renderInsumos(){""", "los ayudantes de la tinta")

# ---------- 4. eventos ----------
uno("""      '<td><button class="quita" data-insdel="'+esc(i.id)+'" title="Quitar">&times;</button></td></tr>').join(""
    : '<tr><td colspan="6" style="color:var(--ink-3);padding:16px">Todavía no hay consumibles.""",
    "NO_DEBE_EXISTIR", "guardia") if False else None

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
