# -*- coding: utf-8 -*-
"""Los colores que estaban escritos a mano y no obedecian al tema.

   Una barra superior en rgba(14,18,38,.86) se ve bien en oscuro y se ve
   como un error en claro. Lo mismo con los objetos del croquis —cocina,
   barra, muros— que traian su color fijo. Se pasan a variables para que la
   paleta mande sobre todo, que es de lo que se trataba tener paleta."""
import pathlib
R = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
t = R.read_text(encoding='utf-8')
hechos = []
def uno(v, n, et):
    global t
    c = t.count(v)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (et, c))
    t = t.replace(v, n, 1); hechos.append(et)

uno("""header.top{position:sticky;top:0;z-index:40;background:rgba(14,18,38,.86);""",
    """header.top{position:sticky;top:0;z-index:40;background:var(--barra-fondo);""",
    "la barra superior obedece al tema")

uno("""  --barra:218px;
  color-scheme:dark;""",
    """  --barra:218px;
  --barra-fondo:rgba(14,18,38,.86);
  color-scheme:dark;""",
    "la variable de la barra")

uno(""""--sombra":"0 1px 2px rgba(0,0,0,.5), 0 14px 34px -18px rgba(0,0,0,.9)"}},""",
    """"--barra-fondo":"rgba(14,18,38,.86)",
    "--sombra":"0 1px 2px rgba(0,0,0,.5), 0 14px 34px -18px rgba(0,0,0,.9)"}},""",
    "la barra en Tecnología")

uno(""""--sombra":"0 1px 2px rgba(28,26,23,.06), 0 12px 28px -20px rgba(28,26,23,.30)"}}""",
    """"--barra-fondo":"rgba(255,255,255,.88)",
    "--sombra":"0 1px 2px rgba(28,26,23,.06), 0 12px 28px -20px rgba(28,26,23,.30)"}}""",
    "la barra en Papel")

R.write_text(t, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
