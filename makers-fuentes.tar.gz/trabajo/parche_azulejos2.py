# -*- coding: utf-8 -*-
"""Azulejos en Inventario, Ventas, Asistencia y Nomina.

   Se quedan FUERA a proposito:
   · Produccion, Clientes y Diseño traen una sola tarjeta. Un lanzador ahi
     seria un clic de mas para llegar a lo unico que hay.
   · Caja son dos tarjetas que se leen juntas —el dinero de hoy y los
     cortes anteriores—; separarlas obliga a ir y venir para cuadrar."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# ================= INVENTARIO =================
uno("""<section id="tab-inv" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Inventario del taller</h2>""",
    """<section id="tab-inv" hidden>
  """ + secciones.barra("inv", "Inventario") + """
  """ + secciones.lanzador("inv") + """
  <div class="card secOculta" data-inv="taller" style="margin-top:20px">
    <header><h2>Inventario del taller</h2>""",
    "el lanzador de inventario")

uno("""  <div class="card" id="cardInvIns">
    <header><h2>Consumibles</h2>""",
    """  <div class="card secOculta" data-inv="ins" id="cardInvIns">
    <header><h2>Consumibles</h2>""",
    "la tarjeta de consumibles")

uno("""  <div class="card">
    <header><h2>Lo que ya pediste</h2>""",
    """  <div class="card secOculta" data-inv="sol">
    <header><h2>Lo que ya pediste</h2>""",
    "la tarjeta de lo que ya pediste")

# ================= VENTAS =================
uno("""<section id="tab-ven" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Corte de ventas</h2>""",
    """<section id="tab-ven" hidden>
  """ + secciones.barra("ven", "Ventas") + """
  """ + secciones.lanzador("ven") + """
  <div class="card secOculta" data-ven="corte" style="margin-top:20px">
    <header><h2>Corte de ventas</h2>""",
    "el lanzador de ventas")

uno("""  <div class="card" id="cardComis" hidden>
    <header><h2>Comisiones del periodo</h2>""",
    """  <div class="card secOculta" data-ven="comis" id="cardComis" hidden>
    <header><h2>Comisiones del periodo</h2>""",
    "la tarjeta de comisiones")

uno("""  <div class="card" id="cardCxc">
    <header><h2>Cuentas por cobrar</h2>""",
    """  <div class="card secOculta" data-ven="cxc" id="cardCxc">
    <header><h2>Cuentas por cobrar</h2>""",
    "la tarjeta de cuentas por cobrar")

uno("""  <div class="card">
    <header><h2>Análisis</h2>""",
    """  <div class="card secOculta" data-ven="analisis">
    <header><h2>Análisis</h2>""",
    "la tarjeta de análisis")

uno("""  <div class="card">
    <header><h2>Detalle de ventas</h2>""",
    """  <div class="card secOculta" data-ven="detalle">
    <header><h2>Detalle de ventas</h2>""",
    "la tarjeta de detalle de ventas")

# ================= ASISTENCIA =================
uno("""<section id="tab-asi" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Reloj checador</h2>""",
    """<section id="tab-asi" hidden>
  """ + secciones.barra("asi", "Asistencia") + """
  """ + secciones.lanzador("asi") + """
  <div class="card secOculta" data-asi="reloj" style="margin-top:20px">
    <header><h2>Reloj checador</h2>""",
    "el lanzador de asistencia")

uno("""  <div class="card">
    <header><h2>Lo de hoy</h2>""",
    """  <div class="card secOculta" data-asi="hoy">
    <header><h2>Lo de hoy</h2>""",
    "la tarjeta de lo de hoy")

uno("""  <div class="card">
    <header><h2>Horas del periodo</h2>""",
    """  <div class="card secOculta" data-asi="horas">
    <header><h2>Horas del periodo</h2>""",
    "la tarjeta de horas del periodo")

# ================= NÓMINA =================
uno("""<section id="tab-nom" hidden>
  <div class="card" style="margin-top:20px" data-solo-admin>
    <header><h2>Nómina</h2>""",
    """<section id="tab-nom" hidden>
  """ + secciones.barra("nom", "Nómina") + """
  """ + secciones.lanzador("nom") + """
  <div class="card secOculta" data-nom="periodo" style="margin-top:20px" data-solo-admin>
    <header><h2>Nómina</h2>""",
    "el lanzador de nómina")

uno("""  <div class="card" data-solo-admin>
    <header><h2>Nóminas cerradas</h2>""",
    """  <div class="card secOculta" data-nom="cerradas" data-solo-admin>
    <header><h2>Nóminas cerradas</h2>""",
    "la tarjeta de nóminas cerradas")

# ================= los azulejos =================
uno("""/* Los azulejos de Ajustes.""",
    """/* Los azulejos de Inventario, Ventas, Asistencia y Nómina. */
registraLanzador("inv", [
  {id:"taller", nombre:"Inventario del taller", sub:"qué hay y qué falta", color:"#22C55E",
   icono:'<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5Z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
   card:'[data-inv="taller"]',
   cuenta:()=>{ try{ return faltantesInv().length; }catch(e){ return 0; } }},
  {id:"ins", nombre:"Consumibles", sub:"tinta, polvo, hilo", color:"#14B8A6",
   icono:'<path d="M12 3s6 6.4 6 10a6 6 0 0 1-12 0c0-3.6 6-10 6-10Z"/>',
   card:'[data-inv="ins"]', cuenta:()=>(cat.insumos||[]).length,
   alAbrir:()=>{ if(typeof renderInvInsumos === "function") renderInvInsumos(); }},
  {id:"sol", nombre:"Lo que ya pediste", sub:"tus solicitudes a compras", color:"#B26A00",
   icono:'<path d="M12 5v14M5 12h14"/>',
   card:'[data-inv="sol"]',
   cuenta:()=>{ try{ return solicitudes().filter(s=>s.estado==="pendiente").length; }catch(e){ return 0; } }}
], "Inventario");

registraLanzador("ven", [
  {id:"corte", nombre:"Corte de ventas", sub:"lo vendido del periodo", color:"#0680AB",
   icono:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
   card:'[data-ven="corte"]'},
  {id:"cxc", nombre:"Cuentas por cobrar", sub:"quién te debe", color:"#D6127F",
   icono:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 12h.01M18 12h.01"/>',
   card:'[data-ven="cxc"]',
   cuenta:()=>{ try{ return ventas.filter(v=>saldoDe(v) > 0).length; }catch(e){ return 0; } },
   alAbrir:()=>{ if(typeof renderCobranza === "function") renderCobranza(); }},
  {id:"comis", nombre:"Comisiones", sub:"quién vendió y cuánto se le debe", color:"#8B5CF6",
   icono:'<circle cx="9" cy="8" r="3.4"/><path d="M3 20v-1.4A3.6 3.6 0 0 1 6.6 15h4.8a3.6 3.6 0 0 1 3.6 3.6V20"/><path d="M18 8v8M15 11h6"/>',
   card:'[data-ven="comis"]', destapa:true, soloAdmin:true},
  {id:"detalle", nombre:"Detalle de ventas", sub:"venta por venta", color:"#64748B",
   icono:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/>',
   card:'[data-ven="detalle"]', cuenta:()=>(ventas||[]).length},
  {id:"analisis", nombre:"Análisis", sub:"lo que más deja", color:"#0E7C57",
   icono:'<path d="M3 3v18h18"/><path d="M7 14l3.5-4 3 3L20 6"/>',
   card:'[data-ven="analisis"]'}
], "Ventas");

registraLanzador("asi", [
  {id:"reloj", nombre:"Reloj checador", sub:"entradas y salidas con foto", color:"#0680AB",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
   card:'[data-asi="reloj"]'},
  {id:"hoy", nombre:"Lo de hoy", sub:"quién está dentro", color:"#0E7C57",
   icono:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M17 11l2 2 4-4"/>',
   card:'[data-asi="hoy"]'},
  {id:"horas", nombre:"Horas del periodo", sub:"cuánto trabajó cada quien", color:"#B26A00",
   icono:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 2v4M16 2v4M3 10h18"/>',
   card:'[data-asi="horas"]', soloAdmin:true}
], "Asistencia");

registraLanzador("nom", [
  {id:"periodo", nombre:"Nómina del periodo", sub:"lo que se paga ahora", color:"#D6127F",
   icono:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 12h.01M18 12h.01"/>',
   card:'[data-nom="periodo"]', soloAdmin:true},
  {id:"cerradas", nombre:"Nóminas cerradas", sub:"las ya pagadas", color:"#64748B",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
   card:'[data-nom="cerradas"]', soloAdmin:true,
   cuenta:()=>{ try{ return (nominas||[]).length; }catch(e){ return 0; } }}
], "Nómina");

/* Los azulejos de Ajustes.""",
    "los azulejos de las cuatro secciones")

uno("""  if(b.dataset.tab==="set") reiniciaSec("set");""",
    """  if(b.dataset.tab==="set") reiniciaSec("set");
  if(b.dataset.tab==="inv") reiniciaSec("inv");
  if(b.dataset.tab==="ven") reiniciaSec("ven");
  if(b.dataset.tab==="asi") reiniciaSec("asi");
  if(b.dataset.tab==="nom") reiniciaSec("nom");""",
    "reiniciar las cuatro secciones")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
