# -*- coding: utf-8 -*-
"""Compras con azulejos, y la requisicion filtrada por estado.

   Las requisiciones viven en una maquina de estados —porAutorizar,
   autorizada, enviada, recibida, pagada— y la tabla las traia todas
   revueltas. Lo que se quiere saber al entrar no es «cuantas hay»: es
   «cuales me toca autorizar» y «cuales estoy esperando»."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""<section id="tab-com" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Requisiciones de compra</h2>""",
    """<section id="tab-com" hidden>
  """ + secciones.barra("com", "Compras") + """
  """ + secciones.lanzador("com") + """
  <div class="card secOculta" data-com="req" style="margin-top:20px">
    <header><h2 id="compTitulo">Requisiciones de compra</h2>""",
    "el lanzador de compras")

uno("""  <div class="card" id="cardSolicitudes" hidden>""",
    """  <div class="card secOculta" data-com="sol" id="cardSolicitudes" hidden>""",
    "las solicitudes del taller")

uno("""  <div class="card">
    <header><h2>Proveedores</h2><button class="btn sm ghost" id="pvNuevo" style="margin-left:auto">+ Proveedor</button></header>""",
    """  <div class="card secOculta" data-com="prov">
    <header><h2>Proveedores</h2><button class="btn sm ghost" id="pvNuevo" style="margin-left:auto">+ Proveedor</button></header>""",
    "proveedores")

# el filtro por estado
uno("""/* Los azulejos del Archivo.""",
    """/* Los azulejos de Compras. Los cuatro primeros abren la MISMA tabla de
   requisiciones, filtrada por donde va cada una. El del taller y el de
   proveedores abren lo suyo. */
let comFiltro = "todas";
const COM_ET = {todas:"Todas las requisiciones", porAut:"Por autorizar",
                camino:"En camino", pagar:"Por pagar"};
function comPasa(r, f){
  const e = r.estado || "porAutorizar";
  if(f === "porAut")  return e === "porAutorizar";
  if(f === "camino")  return e === "autorizada" || e === "enviada";
  if(f === "pagar")   return e === "recibida";
  return true;
}
function comCuenta(f){ return (cat.requisiciones||[]).filter(r=>comPasa(r, f)).length; }
function comAbre(f){
  comFiltro = f;
  const t = $("#compTitulo"); if(t) t.textContent = COM_ET[f] || "Requisiciones de compra";
  if(typeof renderCompras === "function") renderCompras();
}

registraLanzador("com", [
  {id:"todas", nombre:"Requisiciones", sub:"todas, como van", color:"#64748B",
   icono:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/>',
   card:'[data-com="req"]', cuenta:()=>comCuenta("todas"), alAbrir:()=>comAbre("todas")},
  {id:"porAut", nombre:"Por autorizar", sub:"esperan tu visto bueno", color:"#B26A00",
   icono:'<path d="M9 12.5l2.2 2.2L15.5 10"/><circle cx="12" cy="12" r="9"/>',
   card:'[data-com="req"]', cuenta:()=>comCuenta("porAut"), alAbrir:()=>comAbre("porAut")},
  {id:"camino", nombre:"En camino", sub:"ya se pidieron", color:"#0680AB",
   icono:'<path d="M6 6h15l-1.6 9H7.6Z"/><path d="M6 6 5 3H2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17.5" cy="19.5" r="1.4"/>',
   card:'[data-com="req"]', cuenta:()=>comCuenta("camino"), alAbrir:()=>comAbre("camino")},
  {id:"pagar", nombre:"Por pagar", sub:"ya llegaron y se deben", color:"#D6127F",
   icono:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 12h.01M18 12h.01"/>',
   card:'[data-com="req"]', cuenta:()=>comCuenta("pagar"), alAbrir:()=>comAbre("pagar")},
  {id:"sol", nombre:"Pide el taller", sub:"lo que falta allá adentro", color:"#14B8A6",
   icono:'<path d="M12 5v14M5 12h14"/>',
   card:'[data-com="sol"]', destapa:true,
   cuenta:()=>(typeof solicitudes === "function"
     ? solicitudes().filter(s=>s.estado==="pendiente").length : 0),
   alAbrir:()=>{ if(typeof renderSolicitudesCompras === "function") renderSolicitudesCompras(); }},
  {id:"prov", nombre:"Proveedores", sub:"a quién le compras", color:"#8B5CF6",
   icono:'<path d="M3 21V9l9-6 9 6v12"/><path d="M9 21v-7h6v7"/>',
   card:'[data-com="prov"]', cuenta:()=>(cat.proveedores||[]).length}
], "Compras");

/* Los azulejos del Archivo.""",
    "los azulejos de compras")

uno("""  if(b.dataset.tab==="arc") reiniciaSec("arc");""",
    """  if(b.dataset.tab==="arc") reiniciaSec("arc");
  if(b.dataset.tab==="com") reiniciaSec("com");""",
    "al entrar a compras")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
