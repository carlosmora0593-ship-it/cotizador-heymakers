# -*- coding: utf-8 -*-
"""El folio de la factura se consume al TIMBRAR, no al capturar.

   Los dos sistemas tenian el mismo hueco: «Siguiente folio» se quedaba en
   1 para siempre, asi que todas las facturas se imprimian como A-000001.
   El folio del SAT se gasta cuando se timbra; una factura pendiente
   todavia no gasta ninguno, y uno gastado no se devuelve aunque despues
   se desmarque."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# El folio queda pegado a la factura en el momento de timbrarse.
uno("""  g.factura = datos;
  const i = guardadas.findIndex(x=>x.folio===folio);""",
    """  /* El folio se gasta al timbrar. Si ya traia uno, se respeta: una
     factura no cambia de folio porque se le corrija el RFC. */
  const previa = facturaDe(g) || {};
  datos.serie = previa.serie || "";
  if(datos.estado === "facturada" && !datos.serie){
    datos.serie = folioFacturaTxt();
    empresaFiscal().folioFactura = num(P.empresa.folioFactura, 1) + 1;
  }
  g.factura = datos;
  const i = guardadas.findIndex(x=>x.folio===folio);""",
    "el folio se gasta al timbrar")

uno("""    ["Serie y folio", folioFacturaTxt()],""",
    """    ["Serie y folio", f.serie ||
      "(se asigna al timbrarla; la siguiente sería " + folioFacturaTxt() + ")"],""",
    "la hoja no inventa el folio")

uno("""    v.factura.estado = v.factura.estado==="facturada" ? "pendiente" : "facturada";""",
    """    v.factura.estado = v.factura.estado==="facturada" ? "pendiente" : "facturada";
    if(v.factura.estado === "facturada" && !v.factura.serie){
      v.factura.serie = folioFacturaTxt();
      empresaFiscal().folioFactura = num(P.empresa.folioFactura, 1) + 1;
      persist();
    }""",
    "marcar como facturada gasta el folio")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
