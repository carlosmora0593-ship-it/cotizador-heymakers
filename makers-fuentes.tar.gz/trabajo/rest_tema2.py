# -*- coding: utf-8 -*-
"""Azulejos en Ajustes y Personal, y la tarjeta de apariencia."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones
R = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
t = R.read_text(encoding='utf-8')
hechos = []
def uno(v, n, et):
    global t
    c = t.count(v)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (et, c))
    t = t.replace(v, n, 1); hechos.append(et)

# --- Ajustes: lanzador + tarjeta de apariencia ---
uno("""<section id="tab-set" hidden>
  <div class="card">
    <header><h2>Tu negocio</h2>""",
    """<section id="tab-set" hidden>
  """ + secciones.barra("set", "Ajustes") + """
  """ + secciones.lanzador("set") + """
  <div class="card secOculta" data-set="apariencia">
    <header><h2>Apariencia</h2><span class="hint">cómo se ve el punto de venta</span></header>
    <div class="body">
      <p class="note" style="margin:0 0 14px">El tema es de <b>esta pantalla</b>, no de la cuenta: la caja
        puede estar en claro y la cocina en oscuro. Cada aparato guarda el suyo.</p>
      <div class="temaFila" id="temaFila"></div>
    </div>
  </div>
  <div class="card secOculta" data-set="negocio">
    <header><h2>Tu negocio</h2>""",
    "apariencia y lanzador en Ajustes")

for v, n, et in [
 ('  <div class="card">\n    <header><h2>Tickets e impresión</h2>',
  '  <div class="card secOculta" data-set="ticket">\n    <header><h2>Tickets e impresión</h2>', "tickets"),
 ('  <div class="card">\n    <header><h2>Apps de reparto</h2>',
  '  <div class="card secOculta" data-set="apps">\n    <header><h2>Apps de reparto</h2>', "apps"),
 ('  <div class="card">\n    <header><h2>Respaldo</h2>',
  '  <div class="card secOculta" data-set="respaldo">\n    <header><h2>Respaldo</h2>', "respaldo"),
 ('  <div class="card">\n    <header><h2>Esta pantalla</h2>',
  '  <div class="card secOculta" data-set="pantalla">\n    <header><h2>Esta pantalla</h2>', "esta pantalla"),
 ('  <div class="card">\n    <header><h2>Mesas y zonas</h2>',
  '  <div class="card secOculta" data-set="mesas">\n    <header><h2>Mesas y zonas</h2>', "mesas"),
 ('  <div class="card">\n    <header><h2>Equipo y claves</h2>',
  '  <div class="card secOculta" data-set="equipo">\n    <header><h2>Equipo y claves</h2>', "equipo"),
 ('  <div class="card">\n    <header><h2>Folios</h2>',
  '  <div class="card secOculta" data-set="folios">\n    <header><h2>Folios</h2>', "folios"),
]: uno(v, n, et)

# --- Personal ---
uno("""<section id="tab-personal" hidden>
  <div class="card">
    <header><h2>Reloj checador</h2>""",
    """<section id="tab-personal" hidden>
  """ + secciones.barra("personal", "Personal") + """
  """ + secciones.lanzador("personal") + """
  <div class="card secOculta" data-per="reloj">
    <header><h2>Reloj checador</h2>""",
    "lanzador en Personal")

for v, n, et in [
 ('  <div class="card">\n    <header><h2>Horas de hoy</h2>',
  '  <div class="card secOculta" data-per="horas">\n    <header><h2>Horas de hoy</h2>', "horas"),
 ('  <div class="card" id="cardRetardos" hidden>\n    <header><h2>Retardos</h2>',
  '  <div class="card secOculta" data-per="retardos" id="cardRetardos" hidden>\n    <header><h2>Retardos</h2>', "retardos"),
 ('  <div class="card" id="cardExpedientes" hidden>\n    <header><h2>Expedientes</h2>',
  '  <div class="card secOculta" data-per="exp" id="cardExpedientes" hidden>\n    <header><h2>Expedientes</h2>', "expedientes"),
 ('  <div class="card" id="cardRecibos" hidden>\n    <header><h2>Recibo de pago</h2>',
  '  <div class="card secOculta" data-per="recibo" id="cardRecibos" hidden>\n    <header><h2>Recibo de pago</h2>', "recibo"),
]: uno(v, n, et)

# --- registro de los azulejos ---
uno("""/* ---------- temas ---------- */""",
    """/* Los azulejos de Ajustes y de Personal. Ajustes traía OCHO tarjetas
   apiladas: la de folios quedaba a tres pantallas de scroll. */
function registraAzulejosRest(){
  registraLanzador("set", [
    {id:"apariencia", nombre:"Apariencia", sub:"claro u oscuro", color:"#D2541F",
     icono:'<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18Z" fill="currentColor" stroke="none"/>',
     card:'[data-set="apariencia"]', alAbrir:()=>pintaTemaRest()},
    {id:"negocio", nombre:"Tu negocio", sub:"nombre y datos", color:"#0680AB",
     icono:'<path d="M3 21V9l9-6 9 6v12"/><path d="M9 21v-7h6v7"/>', card:'[data-set="negocio"]'},
    {id:"ticket", nombre:"Tickets", sub:"impresión y formato", color:"#8B5CF6",
     icono:'<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2Z"/><path d="M9 8h6M9 12h6"/>', card:'[data-set="ticket"]'},
    {id:"apps", nombre:"Apps de reparto", sub:"Uber, Rappi, DiDi", color:"#0DBF5B",
     icono:'<path d="M6 6h15l-1.6 9H7.6Z"/><path d="M6 6 5 3H2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17.5" cy="19.5" r="1.4"/>',
     card:'[data-set="apps"]', cuenta:()=>appsActivas().length, alAbrir:()=>pintaAppsEdit()},
    {id:"mesas", nombre:"Mesas y zonas", sub:"el salón", color:"#3B82F6",
     icono:'<circle cx="12" cy="12" r="4"/><path d="M12 16v5M7 21h10M3 8h18"/>', card:'[data-set="mesas"]'},
    {id:"equipo", nombre:"Equipo", sub:"quién entra y con qué clave", color:"#D6127F",
     icono:'<circle cx="9" cy="8" r="3.4"/><path d="M3 20v-1.4A3.6 3.6 0 0 1 6.6 15h4.8a3.6 3.6 0 0 1 3.6 3.6V20"/><path d="M17 11h4M19 9v4"/>',
     card:'[data-set="equipo"]', cuenta:()=>EQUIPO.filter(u=>u.activo!==false).length},
    {id:"folios", nombre:"Folios", sub:"cómo se numeran", color:"#B26A00",
     icono:'<path d="M4 7h16M4 12h16M4 17h10"/>', card:'[data-set="folios"]'},
    {id:"respaldo", nombre:"Respaldo", sub:"bajar y restaurar", color:"#0E7C57",
     icono:'<path d="M12 3v12"/><path d="M8 11l4 4 4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>',
     card:'[data-set="respaldo"]'},
    {id:"pantalla", nombre:"Esta pantalla", sub:"impresora y estación", color:"#64748B",
     icono:'<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>', card:'[data-set="pantalla"]'}
  ], "Ajustes");

  registraLanzador("personal", [
    {id:"reloj", nombre:"Reloj checador", sub:"entradas y salidas", color:"#0680AB",
     icono:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>', card:'[data-per="reloj"]'},
    {id:"horas", nombre:"Horas de hoy", sub:"quién está trabajando", color:"#0E7C57",
     icono:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>', card:'[data-per="horas"]'},
    {id:"retardos", nombre:"Retardos", sub:"y sus justificaciones", color:"#B26A00", visible:()=>esGerente(), destapa:true,
     icono:'<path d="M12 3 2 20h20Z"/><path d="M12 9v5M12 17h.01"/>', card:'[data-per="retardos"]'},
    {id:"exp", nombre:"Expedientes", sub:"los papeles de cada quien", color:"#8B5CF6", visible:()=>esGerente(), destapa:true,
     icono:'<rect x="3" y="4" width="18" height="17" rx="2"/><circle cx="12" cy="11" r="2.4"/><path d="M8 18a4 4 0 0 1 8 0"/>',
     card:'[data-per="exp"]', cuenta:()=>EQUIPO.length},
    {id:"recibo", nombre:"Recibo de pago", sub:"por periodo", color:"#D6127F", visible:()=>esGerente(), destapa:true,
     icono:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/>', card:'[data-per="recibo"]'}
  ], "Personal");
}

/* ---------- temas ---------- */""",
    "registro de azulejos")

# arranque y entrada a cada pestaña
uno("""function vaA(k){""",
    """function vaA(k){
  if(k === "set" || k === "personal"){
    setTimeout(()=>{ try{ pintaLanzadorSec(k); reiniciaSec(k); }catch(e){} }, 0);
  }""",
    "al entrar a Ajustes o Personal")

R.write_text(t, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
