# -*- coding: utf-8 -*-
"""Mete los vales y el almacen de herramienta al cotizador.

   Todo es NUEVO: seccion nueva, colecciones nuevas, azulejos nuevos. Lo
   unico que toca de lo que ya habia es la caja del dia —para que el
   efectivo que sale quede en el corte, igual que la nomina— y el menu."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones, vales

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# ---------- 1. estilos ----------
uno("/* ---- lanzador dentro de una sección ---- */",
    vales.CSS.strip() + "\n/* ---- lanzador dentro de una sección ---- */",
    "estilos de los vales")

# ---------- 2. la sección ----------
html = (vales.HTML
        .replace("BARRA", secciones.barra("val", "Vales"))
        .replace("LANZADOR", secciones.lanzador("val")))
uno('<section id="tab-set" hidden>', html.strip() + '\n\n<section id="tab-set" hidden>',
    "la sección de vales")

# ---------- 3. el campo de archivo del comprobante ----------
uno('      <input type="file" id="fileIn" accept="application/json" hidden>',
    '      <input type="file" id="fileIn" accept="application/json" hidden>\n'
    '      <input type="file" id="valeArchivo" accept="image/png,image/jpeg,image/webp,application/pdf" hidden>',
    "el campo del comprobante")

# ---------- 4. la pestaña en el menú ----------
uno('        <button role="menuitem" data-tab="com" aria-selected="false"><b>Compras <span class="mbadge" hidden>0</span></b><small>Requisiciones, proveedores y facturas</small></button>',
    '        <button role="menuitem" data-tab="com" aria-selected="false"><b>Compras <span class="mbadge" hidden>0</span></b><small>Requisiciones, proveedores y facturas</small></button>\n'
    '        <button role="menuitem" data-tab="val" aria-selected="false"><b>Vales <span class="mbadge" id="valBadge" hidden>0</span></b><small>Herramienta y dinero que sale, con su firma</small></button>',
    "la entrada del menú")

uno('const TABS_TODAS = ["inicio","cot","cat","calc","inv","com","cli","arc","caj","pro","dis","sav","ven","asi","nom","set"];',
    'const TABS_TODAS = ["inicio","cot","cat","calc","inv","com","val","cli","arc","caj","pro","dis","sav","ven","asi","nom","set"];',
    "la pestaña en la lista")

# ---------- 5. quién la ve ----------
uno('''  admin:      {nombre:"Administrador", ve:["inicio","cot","sav","pro","dis","cli","arc","caj","ven","cat","calc","inv","com","asi","nom","set"]},
  ventas:     {nombre:"Ventas",        ve:["inicio","cot","sav","pro","dis","cli","arc","com","asi"]},
  diseno:     {nombre:"Diseño",        ve:["inicio","dis","pro","asi"]},
  produccion: {nombre:"Producción",    ve:["inicio","pro","inv","com","asi"]}''',
'''  admin:      {nombre:"Administrador", ve:["inicio","cot","sav","pro","dis","cli","arc","caj","ven","cat","calc","inv","com","val","asi","nom","set"]},
  ventas:     {nombre:"Ventas",        ve:["inicio","cot","sav","pro","dis","cli","arc","com","val","asi"]},
  diseno:     {nombre:"Diseño",        ve:["inicio","dis","pro","val","asi"]},
  produccion: {nombre:"Producción",    ve:["inicio","pro","inv","com","val","asi"]}''',
    "todos levantan vales, sólo el admin autoriza")

# ---------- 6. el motor ----------
uno("/* ---------- generar factura desde una cotización ---------- */",
    vales.JS.rstrip() + "\n" + vales.EVENTOS.rstrip() +
    "\n\n/* ---------- generar factura desde una cotización ---------- */",
    "el motor de los vales")

# ---------- 7. los azulejos ----------
uno('/* Los azulejos de Inventario, Ventas, Asistencia y Nómina. */',
'''/* Los azulejos de Vales. */
registraLanzador("val", [
  {id:"porauth", nombre:"Por autorizar", sub:"lo que está esperando firma", color:"#D6127F",
   icono:'<path d="M3 21h4l11-11a2.8 2.8 0 0 0-4-4L3 17Z"/><path d="M14.5 6.5 17.5 9.5"/>',
   card:'[data-val="porauth"]',
   cuenta:()=>{ try{ return valesPend().length; }catch(e){ return 0; } }},
  {id:"nuevo", nombre:"Levantar un vale", sub:"herramienta o dinero", color:"#0680AB",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
   card:'[data-val="nuevo"]'},
  {id:"almacen", nombre:"El almacén", sub:"qué hay y qué falta", color:"#0E7C57",
   icono:'<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5Z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
   card:'[data-val="almacen"]',
   cuenta:()=>{ try{ return herrBajoMin().length; }catch(e){ return 0; } }},
  {id:"prestado", nombre:"Quién trae qué", sub:"lo prestado sin devolver", color:"#B26A00",
   icono:'<circle cx="9" cy="8" r="3.4"/><path d="M3 20v-1.4A3.6 3.6 0 0 1 6.6 15h4.8a3.6 3.6 0 0 1 3.6 3.6V20"/><path d="M18 8v8M15 11h6"/>',
   card:'[data-val="prestado"]',
   cuenta:()=>{ try{ return prestados().length; }catch(e){ return 0; } }},
  {id:"hist", nombre:"Vales anteriores", sub:"lo que ya se cerró", color:"#64748B",
   icono:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
   card:'[data-val="hist"]',
   cuenta:()=>{ try{ return sinComprobar().length; }catch(e){ return 0; } }}
], "Vales");

/* Los azulejos de Inventario, Ventas, Asistencia y Nómina. */''',
    "los azulejos de vales")

# ---------- 8. engancharlo al cambio de pestaña ----------
uno('  if(b.dataset.tab==="set") reiniciaSec("set");',
    '  if(b.dataset.tab==="set") reiniciaSec("set");\n'
    '  if(b.dataset.tab==="val"){ renderVales(); reiniciaSec("val"); }',
    "pintar los vales al entrar")

# ---------- 9. el globito del menú ----------
uno('''  $("#catEstado").textContent = "Catálogo al día";''',
'''  try{ renderVales(); }catch(e){}
  $("#catEstado").textContent = "Catálogo al día";''',
    "pintar los vales al arrancar")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
