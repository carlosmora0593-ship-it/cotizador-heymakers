# -*- coding: utf-8 -*-
"""Pedidos por app, parte 2: cobro, corte y reporte por canal."""
import pathlib
R = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
t = R.read_text(encoding='utf-8')
hechos = []
def uno(v, n, et):
    global t
    c = t.count(v)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (et, c))
    t = t.replace(v, n, 1); hechos.append(et)

uno("""$("#comCobrar").addEventListener("click", ()=>{
  const c = comandaActual(); if(!c || !(c.lineas||[]).length) return;
  if(!turnoAbierto()){ toast("Abre el turno de caja antes de cobrar"); return; }""",
    """$("#comCobrar").addEventListener("click", ()=>{
  const c = comandaActual(); if(!c || !(c.lineas||[]).length) return;
  if(!turnoAbierto()){ toast("Abre el turno de caja antes de cobrar"); return; }
  /* Un pedido de app ya viene pagado por la plataforma: no hay propina que
     repartir, ni efectivo, ni cambio. */
  if(c.appId){ abreCobroApp(c); return; }""",
    "desviar el cobro de los pedidos de app")

uno("""/* ===================================================================
   TURNO DE CAJA
   =================================================================== */""",
    """/* ---- cerrar un pedido de app ---- */
function abreCobroApp(c){
  const s = sumaComanda(c);
  const total = s.total, pct = num(c.comisionPct), com = total * pct/100;
  const costo = (c.lineas||[]).reduce((x,l)=>{
    const p = (MENU.plats||[]).find(y=>y.id === l.platId);
    return x + num(p && p.costo) * num(l.cant,1);
  }, 0);
  const queda = total - com - costo;
  c.estado = "cuenta"; persist();
  $("#apCualApp").textContent = c.appNombre + " · " + c.folio;
  $("#apAppTotal").textContent = mx(total);
  $("#apAppDesglose").innerHTML =
    '<div class="appRen"><span class="nom"><i style="background:'+esc(c.appColor||"#888")+'"></i>' +
      esc(c.appNombre)+' se queda</span>' +
      '<span class="ci mal">−'+mx(com)+'<small>'+pct1(pct)+'</small></span>' +
      '<span class="ci">'+mx(total - com)+'<small>te depositan</small></span>' +
      '<span class="ci '+(queda>0?"bien":"mal")+'">'+mx(queda)+'<small>te queda</small></span></div>' +
    (costo ? '' : '<p class="note" style="margin:0">Captura el costo de tus platillos en el Menú para saber ' +
      'cuánto te queda de verdad. Sin eso, sólo se ve lo que te depositan.</p>');
  $("#modalApp").hidden = false;
}
$("#apAppCerrar").addEventListener("click", ()=>{ $("#modalApp").hidden = true; });
$("#apAppOk").addEventListener("click", ()=>{
  const c = comandaActual(); if(!c) return;
  const s = sumaComanda(c);
  c.estado = "cerrada"; c.cierra = horaAhora();
  c.subtotal = s.sub; c.servicio = s.serv; c.propina = 0; c.total = s.total;
  /* Un solo pago, de tipo app: no toca el efectivo del cajon. */
  c.pagos = [{tipo:"app", monto:s.total}];
  c.cambio = 0; c.efectivoCaja = 0;
  c.comision = s.total * num(c.comisionPct)/100;
  c.neto = s.total - c.comision;
  c.turnoId = (turnoAbierto()||{}).id || "";
  c.cobro = usuarioActual().nombre || "";
  persist();
  if(ESTACION.cuenta) imprimeCuenta(c, c.pagos, 0);
  $("#modalApp").hidden = true;
  comandaId = null;
  vaA("mesas");
  toast(c.appNombre + " " + mx(s.total) + " · te depositan " + mx(c.neto) + " · " + c.folio);
});

/* ===================================================================
   TURNO DE CAJA
   =================================================================== */""",
    "el cobro de app")

uno("""  const por = {efectivo:0, tarjeta:0, transferencia:0};
  let propinas = 0, total = 0, efectivoCaja = 0;
  cs.forEach(c=>{
    total += num(c.total); propinas += num(c.propina); efectivoCaja += num(c.efectivoCaja);
    (c.pagos||[]).forEach(p=>{ por[p.tipo] = num(por[p.tipo]) + num(p.monto); });
  });""",
    """  const por = {efectivo:0, tarjeta:0, transferencia:0, app:0};
  let propinas = 0, total = 0, efectivoCaja = 0, apps = 0, comisionApps = 0;
  cs.forEach(c=>{
    total += num(c.total); propinas += num(c.propina); efectivoCaja += num(c.efectivoCaja);
    if(c.appId){ apps += num(c.total); comisionApps += comisionDe(c); }
    (c.pagos||[]).forEach(p=>{ por[p.tipo] = num(por[p.tipo]) + num(p.monto); });
  });""",
    "el turno cuenta las apps aparte")

uno("""  return {cuentas:cs.length, total, propinas, por, efectivoCaja,
          movs, enCaja: num(t.fondo) + efectivoCaja + movs};""",
    """  return {cuentas:cs.length, total, propinas, por, efectivoCaja,
          apps, comisionApps, netoApps: apps - comisionApps, propio: total - apps,
          movs, enCaja: num(t.fondo) + efectivoCaja + movs};""",
    "el resumen del turno trae las apps")

R.write_text(t, encoding='utf-8')
print("Parte 2 lista. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
