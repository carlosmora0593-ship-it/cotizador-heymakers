# -*- coding: utf-8 -*-
"""El importador de catalogo, con su plantilla."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import importar

R = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = R.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    c = src.count(viejo)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, c))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""/* ---- importar catálogo ---- */""", "", "x") if False else None
uno(""".avisoStock{margin:0 16px 12px;""", importar.CSS + """
.avisoStock{margin:0 16px 12px;""", "estilos")

uno("""<div class="modal" id="modalArt" hidden>""",
    importar.MODAL + """
<div class="modal" id="modalArt" hidden>""",
    "el modal de importar")

uno("""      <button class="btn sm primary" id="catActualizar">Actualizar</button>
      <button class="btn sm ghost" data-add="articulos">+ Artículo</button>""",
    """      <button class="btn sm primary" id="catActualizar">Actualizar</button>
      <button class="btn sm ghost" id="catImportar">Importar de Excel</button>
      <button class="btn sm ghost" data-add="articulos">+ Artículo</button>""",
    "el botón en el catálogo")

uno("""function renderInsumos(){""", importar.JS + """
function renderInsumos(){""", "el motor de importación")

R.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
