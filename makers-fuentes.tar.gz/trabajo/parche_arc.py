# -*- coding: utf-8 -*-
"""Archivo con azulejos: pedidos por cliente, compras y expedientes.

   Son tres archivos distintos con tres duenos distintos —el cliente, el
   contador, el patron— y estaban apilados en la misma pantalla. El de
   expedientes ademas solo lo ve el administrador, asi que para todos los
   demas habia un hueco raro al final."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import secciones

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""<section id="tab-arc" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Archivo por cliente</h2>""",
    """<section id="tab-arc" hidden>
  """ + secciones.barra("arc", "Archivo") + """
  """ + secciones.lanzador("arc") + """
  <div class="card secOculta" data-arc="clientes" style="margin-top:20px">
    <header><h2>Archivo por cliente</h2>""",
    "el lanzador del archivo")

uno("""  <div class="card">
    <header><h2>Compras por mes</h2>""",
    """  <div class="card secOculta" data-arc="compras">
    <header><h2>Compras por mes</h2>""", "compras por mes")

uno("""  <div class="card" id="cardExp" data-solo-admin>""",
    """  <div class="card secOculta" data-arc="exp" id="cardExp" data-solo-admin>""", "expedientes")

uno("""/* Los azulejos de Cotizaciones.""",
    """/* Los azulejos del Archivo. Expedientes sólo lo ve el administrador, así
   que su azulejo tampoco se pinta para los demás: ofrecer una puerta que
   no abre es peor que no ofrecerla. */
registraLanzador("arc", [
  {id:"clientes", nombre:"Pedidos por cliente", sub:"carpeta de cada uno", color:"#0680AB",
   icono:'<path d="M3 7.5A1.5 1.5 0 0 1 4.5 6h4l2 2.5h9A1.5 1.5 0 0 1 21 10v8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18Z"/>',
   card:'[data-arc="clientes"]', cuenta:()=>{
     const s = new Set(); guardadas.forEach(g=>{ if((g.cliente||"").trim()) s.add(g.cliente.trim()); });
     return s.size; },
   alAbrir:()=>{ if(typeof renderArchivo === "function") renderArchivo(); }},
  {id:"compras", nombre:"Compras por mes", sub:"PDF y XML del proveedor", color:"#B26A00",
   icono:'<path d="M6 6h15l-1.6 9H7.6Z"/><path d="M6 6 5 3H2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17.5" cy="19.5" r="1.4"/>',
   card:'[data-arc="compras"]',
   alAbrir:()=>{ if(typeof renderCompArchivo === "function") renderCompArchivo(); }},
  {id:"exp", nombre:"Expedientes", sub:"papeles del personal", color:"#8B5CF6", soloAdmin:true,
   icono:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 4V2.5M16 4V2.5"/><circle cx="12" cy="11" r="2.4"/><path d="M8 18a4 4 0 0 1 8 0"/>',
   card:'[data-arc="exp"]',
   alAbrir:()=>{ if(typeof renderExpedientes === "function") renderExpedientes(); }}
], "Archivo");

/* Los azulejos de Cotizaciones.""",
    "los azulejos del archivo")

# un azulejo que no le toca al rol no se pinta
uno("""  w.innerHTML = cfg.tarjetas.map(t=>{
    let n = "";""",
    """  w.innerHTML = cfg.tarjetas.filter(t=>{
    if(!t.soloAdmin) return true;
    return typeof rolActual !== "function" || rolActual() === "admin";
  }).map(t=>{
    let n = "";""",
    "los azulejos respetan el rol")

uno("""  if(b.dataset.tab==="sav"){ renderSaved(); reiniciaSec("sav"); }""",
    """  if(b.dataset.tab==="sav"){ renderSaved(); reiniciaSec("sav"); }
  if(b.dataset.tab==="arc") reiniciaSec("arc");""",
    "al entrar al archivo")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
