# -*- coding: utf-8 -*-
"""Termina la tinta por canal: los dos controles que faltaban y su ropa.

   El parche anterior dejó la tabla pintada pero muda: el campo del litro
   no escribía nada y el botón de partir no hacía nada. Esto los conecta."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []

def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)

# ---------------------------------------------------------------- 1. estilos
uno(
""".armSepOri{align-items:end;gap:10px}""",
""".gotaIns{display:inline-block;width:11px;height:11px;border-radius:50%;
  margin-right:7px;vertical-align:middle;box-shadow:0 0 0 1px var(--linea) inset,
  0 0 0 1px color-mix(in srgb, var(--ink-1) 18%, transparent)}
.insRinde{line-height:1.25}
.insRinde .insM2{font-weight:650;font-variant-numeric:tabular-nums;color:var(--ink-1)}
.insRinde small{display:block;font-size:10.5px;color:var(--ink-3);
  font-variant-numeric:tabular-nums}
.armSepOri{align-items:end;gap:10px}""",
    "los estilos de la gota y del rinde")

# ------------------------------------------------- 2. el campo por litro/kilo
uno(
"""  const tr = e.target.closest("[data-ins]");
  if(tr && e.target.dataset.insf){
    const i = insumoDe(tr.dataset.ins); if(!i) return;
    const f = e.target.dataset.insf;
    i[f] = (f === "nombre") ? e.target.value : num(e.target.value);
    persist(); renderInvInsumos();
    if(f === "nombre" && $("#consCuerpo")) renderConsumos();
    return;
  }""",
"""  const tr = e.target.closest("[data-ins]");
  if(tr && e.target.dataset.insf){
    const i = insumoDe(tr.dataset.ins); if(!i) return;
    const f = e.target.dataset.insf;
    /* El litro y el mililitro son el mismo dato visto de dos formas. Quien
       compra piensa en el bote; quien calcula, en el mililitro. Se captura
       cualquiera de los dos y el otro se acomoda. */
    if(f === "costoMil"){
      i.costo = num(e.target.value) / 1000;
      const par = tr.querySelector('[data-insf="costo"]');
      if(par) par.value = Math.round(i.costo * 10000) / 10000;
    }else{
      i[f] = (f === "nombre") ? e.target.value : num(e.target.value);
      if(f === "costo"){
        const par = tr.querySelector('[data-insf="costoMil"]');
        if(par) par.value = Math.round(num(i.costo) * 1000 * 100) / 100;
      }
    }
    /* El rinde se repinta a mano: volver a dibujar la tabla completa le
       robaría el cursor a quien está capturando. */
    if(f === "existencia"){
      const celda = tr.querySelector(".insRinde");
      if(celda) celda.innerHTML = rindeIns(i);
    }
    persist(); renderInvInsumos();
    if(f === "nombre" && $("#consCuerpo")) renderConsumos();
    return;
  }""",
    "el precio por litro escribe el precio por mililitro")

# ------------------------------------------------------- 3. el botón de partir
uno(
"""  const d = e.target.closest("[data-insdel]");
  if(d){
    const i = insumoDe(d.dataset.insdel); if(!i) return;""",
"""  const pt = e.target.closest("[data-inspartir]");
  if(pt){
    const i = insumoDe(pt.dataset.inspartir); if(!i) return;
    const amarres = (cat.consumos||[]).filter(c=>c.insumoId===i.id).length;
    if(!confirm("¿Partir «" + (i.nombre||"esta tinta") + "» en cian, magenta, " +
      "amarillo, negro y blanco?\\n\\nEl precio se copia igual a los cinco y lo " +
      "ajustas por color." +
      (amarres ? "\\nSus " + amarres + " amarre(s) se reparten: 12% a cada color " +
                 "y 50% al blanco." : "") +
      "\\n\\nLa existencia queda en cero: lo que tienes de cada bote lo capturas tú."))
      return;
    parteTinta(i.id);
    return;
  }
  const d = e.target.closest("[data-insdel]");
  if(d){
    const i = insumoDe(d.dataset.insdel); if(!i) return;""",
    "el botón que parte la tinta en cinco")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
