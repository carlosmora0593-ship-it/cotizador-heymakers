# -*- coding: utf-8 -*-
"""Tema claro «Papel», al estilo de los paneles que mando Carlos.

   Fondo crema en vez de blanco puro: un blanco de verdad sobre pantalla
   grande cansa, y los paneles de los videos usan hueso. Las tarjetas si son
   blancas, y asi se despegan del fondo sin necesitar sombra fuerte.

   Las cuatro series son LAS MISMAS que ya trae el producto y que ya estan
   validadas con el script de dataviz: cyan, magenta, ambar y verde. Se
   reordenaron para que el par mas parecido no quede adyacente.
   Validacion sobre superficie clara:
     Lightness PASS · Chroma PASS · Normal-vision PASS (min 19.6)
     Contraste PASS · CVD WARN #0E7C57 vs #B26A00 7.0 protan
   El WARN es legal SOLO porque cada elemento de color lleva tambien su
   etiqueta de texto. Esa regla no se puede romper despues.

   El tema NO se vuelve el de fabrica: se suma a los que ya hay y cada quien
   escoge en Ajustes. Cambiarle la cara a todos sin avisar es de lo que mas
   molesta de un programa que ya se estaba usando."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""  heymakers:{nombre:"Hey Makers", acento:"#D6127F", amb:["#06A1D7","#F51B95","#FFEC30"]},""",
    """  papel:    {nombre:"Papel",       acento:"#D2541F", amb:["#D2541F","#B26A00","#0E7C57"],
             modo:"light", vars:{
    "--bg":"#F6F4EF", "--surface":"#FFFFFF", "--surface-2":"#F1EEE7",
    "--line":"#E2DED4", "--line-soft":"#EDEAE2",
    "--ink":"#1C1A17", "--ink-2":"#55514A", "--ink-3":"#8A857B",
    "--cyan":"#0680AB", "--cyan-soft":"#E2F0F7",
    "--good":"#0E7C57", "--good-soft":"#E2F1EB",
    "--warn":"#B26A00", "--warn-soft":"#F8EEDC",
    "--yellow":"#E3B505", "--yellow-ink":"#231A00",
    "--guinda":"#D2541F", "--guinda-2":"#A93D11",
    "--guinda-tenue":"#FAEBE3", "--guinda-medio":"#F3D6C7",
    "--serie-1":"#0680AB", "--serie-2":"#D6127F", "--serie-3":"#B26A00", "--serie-4":"#0E7C57",
    "--shadow":"0 1px 2px rgba(28,26,23,.06), 0 12px 28px -20px rgba(28,26,23,.30)"
  }},
  heymakers:{nombre:"Hey Makers", acento:"#D6127F", amb:["#06A1D7","#F51B95","#FFEC30"]},""",
    "la paleta Papel")

# En claro, los azulejos del lanzador se ven lavados con 20% de color: el
# fondo blanco se come la mezcla. Se suben las mezclas sólo en modo claro.
uno(""".lzIco{position:relative;display:grid;place-items:center;width:60px;height:60px;border-radius:17px;""",
    """[data-theme="light"] .lzIco{background:color-mix(in oklab, var(--lzc) 13%, #fff);
  border-color:color-mix(in oklab, var(--lzc) 30%, #fff)}
[data-theme="light"] .lzApp:hover .lzIco{background:color-mix(in oklab, var(--lzc) 20%, #fff)}
[data-theme="light"] .lzN{background:#fff}
.lzIco{position:relative;display:grid;place-items:center;width:60px;height:60px;border-radius:17px;""",
    "los azulejos en claro")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
