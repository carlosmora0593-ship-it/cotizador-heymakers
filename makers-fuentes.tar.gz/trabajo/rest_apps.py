# -*- coding: utf-8 -*-
"""Pedidos de Uber Eats, Rappi y DiDi Food.

   Hoy el restaurante teclea esos pedidos como si fueran venta de mostrador
   y al cierre del mes no sabe que la plataforma se llevo el 30%. Un platillo
   que deja 65% en mesa deja 35% por app, y eso no se ve en ningun lado.

   La comision se CONGELA en la comanda al abrirla: si manana Rappi sube al
   32%, los pedidos viejos siguen contando lo que de verdad costaron."""
import pathlib, sys
R = pathlib.Path('/home/claude/trabajo/makersrestaurant.html')
t = R.read_text(encoding='utf-8')
hechos = []
def uno(v, n, et):
    global t
    c = t.count(v)
    if c != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (et, c))
    t = t.replace(v, n, 1); hechos.append(et)

# ---------- estilos ----------
uno(""".llevarFila{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px}""",
    """.llevarFila{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.appsFila{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
.appsFila .et{font-size:11.5px;color:var(--ink-3);text-transform:uppercase;letter-spacing:.08em}
.btnApp{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);
  background:var(--surface-2);border-radius:999px;padding:7px 14px;cursor:pointer;
  font-family:"Fredoka";font-size:13px;color:var(--ink)}
.btnApp:hover{border-color:var(--accent)}
.btnApp i{width:9px;height:9px;border-radius:50%;display:block;font-style:normal}
.btnApp small{color:var(--ink-3);font-size:11px}
.appPill{display:inline-flex;align-items:center;gap:5px;font-size:11px;border-radius:999px;
  padding:2px 8px;background:var(--surface-2);border:1px solid var(--line);color:var(--ink-2)}
.appPill i{width:7px;height:7px;border-radius:50%;display:block;font-style:normal}
.appResumen{display:grid;gap:9px;margin-top:4px}
.appRen{display:grid;grid-template-columns:1fr auto auto auto;gap:10px;align-items:center;
  padding:11px 13px;border:1px solid var(--line);border-radius:12px;background:var(--surface-2)}
.appRen .nom{display:flex;align-items:center;gap:8px;font-family:"Fredoka";font-size:13.5px}
.appRen .ci{font-family:"IBM Plex Mono",monospace;font-size:13px;text-align:right;min-width:92px}
.appRen .ci small{display:block;font-family:"Fredoka";font-size:10px;color:var(--ink-3);
  text-transform:uppercase;letter-spacing:.06em}
.appRen .ci.mal{color:var(--mal)} .appRen .ci.bien{color:var(--good)}""",
    "estilos")

# ---------- parametros ----------
uno("""          tolerancia:10, cierreNomina:""};""",
    """          tolerancia:10, cierreNomina:"", apps:appsPorDefecto()};""",
    "P.apps")

uno("""function equipoPorDefecto(){""",
    """/* Las comisiones de arranque son las que se ven en el mercado mexicano y
   CADA restaurante negocia la suya: por eso se editan en Ajustes. */
function appsPorDefecto(){
  return [{id:"uber",  nombre:"Uber Eats",  comision:30, color:"#0DBF5B", activa:true},
          {id:"rappi", nombre:"Rappi",      comision:30, color:"#FF5A5F", activa:true},
          {id:"didi",  nombre:"DiDi Food",  comision:25, color:"#FF8A00", activa:true}];
}
const pct1 = v => (Math.round(num(v)*10)/10) + "%";
const appsActivas = () => (P.apps||[]).filter(a=>a.activa !== false);
const appDe = id => (P.apps||[]).find(a=>a.id === id) || null;
/* La comision que vale es la que quedo guardada en la comanda. */
const comisionDe = c => num(c.comisionPct) ? num(c.total) * num(c.comisionPct)/100 : 0;

function equipoPorDefecto(){""",
    "appsPorDefecto")

uno("""let P        = Object.assign(paramsPorDefecto(), lsGet("P", {}));""",
    """let P        = Object.assign(paramsPorDefecto(), lsGet("P", {}));
if(!Array.isArray(P.apps) || !P.apps.length) P.apps = appsPorDefecto();""",
    "P.apps para cuentas que ya existian")

# ---------- UI de mesas ----------
uno("""  <div class="llevarFila" id="llevarFila"></div>""",
    """  <div class="appsFila" id="appsFila"></div>
  <div class="llevarFila" id="llevarFila"></div>""",
    "fila de apps en mesas")

uno("""<div class="modal ancho" id="modalCobro" hidden>""",
    """<div class="modal" id="modalApp" hidden>
  <div class="card" style="width:min(460px,100%)">
    <header><h2>Cerrar pedido de app</h2><span class="hint" id="apCualApp"></span>
      <button class="btn sm" id="apAppCerrar" style="margin-left:auto">Cerrar</button></header>
    <div class="body">
      <div class="cobroTot"><span class="et">Lo que cobró la plataforma</span>
        <span class="v" id="apAppTotal">$0.00</span></div>
      <div class="appResumen" style="margin-top:14px" id="apAppDesglose"></div>
      <p class="note" style="margin-top:14px">Este dinero <b>no entra a tu caja</b>: la plataforma te lo
        deposita después, ya con su comisión descontada. Por eso no te pide efectivo ni cambio, y el corte
        del turno no lo va a buscar en el cajón.</p>
      <div class="row-actions" style="margin-top:16px">
        <button class="btn primary" id="apAppOk">Cerrar el pedido</button>
      </div>
    </div>
  </div>
</div>

<div class="modal ancho" id="modalCobro" hidden>""",
    "modal de cobro de app")

uno("""$("#mesaRapida").addEventListener("click", ()=> abreMesa("llevar"));""",
    """$("#mesaRapida").addEventListener("click", ()=> abreMesa("llevar"));

/* ---- pedidos que llegan por Uber, Rappi o DiDi ---- */
function pintaAppsFila(){
  const w = $("#appsFila"); if(!w) return;
  const act = appsActivas();
  if(!act.length){ w.innerHTML = ""; return; }
  w.innerHTML = '<span class="et">Pedido por app</span>' + act.map(a=>
    '<button class="btnApp" data-abreapp="'+esc(a.id)+'"><i style="background:'+esc(a.color||"#888")+'"></i>'+
    esc(a.nombre)+' <small>'+pct1(a.comision)+'</small></button>').join("");
}
$("#appsFila").addEventListener("click", e=>{
  const b = e.target.closest("[data-abreapp]"); if(!b) return;
  abreApp(b.dataset.abreapp);
});
function abreApp(appId){
  const a = appDe(appId); if(!a) return;
  if(!turnoAbierto()){ toast("Abre el turno de caja antes de tomar pedidos"); return; }
  const n = COMANDAS.filter(x=>x.appId === appId && x.fecha === hoyISO()).length + 1;
  const c = nuevaComanda({id:"llevar", nombre:a.nombre + " " + n, lugares:1});
  /* La comision se congela aqui. */
  c.appId = a.id; c.appNombre = a.nombre; c.appColor = a.color || "";
  c.comisionPct = num(a.comision);
  persist();
  comandaId = c.id; comensalVista = 1;
  vaA("comanda"); renderComanda();
}""",
    "abrir pedido de app")

uno("""  const ab = abiertas(), ll = llevarAbiertas().length;""",
    """  pintaAppsFila();
  const ab = abiertas(), ll = llevarAbiertas().length;""",
    "pintar la fila")

R.write_text(t, encoding='utf-8')
print("Parte 1 lista. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
