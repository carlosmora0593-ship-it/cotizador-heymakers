# -*- coding: utf-8 -*-
"""La tinta por canal en las otras cuatro tecnicas.

   El parche anterior dejo los cinco canales del DTF textil. Carlos pidio
   lo mismo para sublimacion, DTF UV y gran formato; y el DTG apuntaba a
   un insumo 'i1' que ya no existe, asi que ese oficio cargaba cero
   consumibles."""
import io

RUTA = "cotizador.html"
s = io.open(RUTA, encoding="utf-8").read()
hechos = []

def uno(viejo, nuevo, etiqueta):
    global s
    n = s.count(viejo)
    if n != 1:
        raise SystemExit("ANCLA '%s': %d coincidencias (esperaba 1)" % (etiqueta, n))
    s = s.replace(viejo, nuevo, 1)
    hechos.append(etiqueta)

# ------------------------------------------------------ 1. los insumos nuevos
uno(
"""  {id:"i2",nombre:"Polvo termoadhesivo",unidad:"g",costo:0.28,existencia:0,minimo:0},
  {id:"i3",nombre:"Bolsa de celofán",unidad:"pza",costo:1.2,existencia:0,minimo:0},
  {id:"i4",nombre:"Hilo de bordado",unidad:"m",costo:0.05,existencia:0,minimo:0}
 ],""",
"""  {id:"i2",nombre:"Polvo termoadhesivo",unidad:"g",costo:0.28,existencia:0,minimo:0},
  {id:"i3",nombre:"Bolsa de celofán",unidad:"pza",costo:1.2,existencia:0,minimo:0},
  {id:"i4",nombre:"Hilo de bordado",unidad:"m",costo:0.05,existencia:0,minimo:0},
  /* Sublimación: cuatro canales. No lleva blanco porque el blanco de una
     taza o de una playera de poliéster es la prenda, no la tinta. */
  {id:"i5c",nombre:"Tinta de sublimación · Cian",unidad:"ml",costo:0.45,existencia:0,minimo:0,canal:"c"},
  {id:"i5m",nombre:"Tinta de sublimación · Magenta",unidad:"ml",costo:0.45,existencia:0,minimo:0,canal:"m"},
  {id:"i5y",nombre:"Tinta de sublimación · Amarillo",unidad:"ml",costo:0.45,existencia:0,minimo:0,canal:"y"},
  {id:"i5k",nombre:"Tinta de sublimación · Negro",unidad:"ml",costo:0.45,existencia:0,minimo:0,canal:"k"},
  {id:"i6",nombre:"Cinta térmica",unidad:"m",costo:1.2,existencia:0,minimo:0},
  /* DTF UV: los cinco de siempre más el barniz, que es el que da el
     relieve y el que se lleva el gasto más grande de los seis. */
  {id:"i7c",nombre:"Tinta UV · Cian",unidad:"ml",costo:1.6,existencia:0,minimo:0,canal:"c"},
  {id:"i7m",nombre:"Tinta UV · Magenta",unidad:"ml",costo:1.6,existencia:0,minimo:0,canal:"m"},
  {id:"i7y",nombre:"Tinta UV · Amarillo",unidad:"ml",costo:1.6,existencia:0,minimo:0,canal:"y"},
  {id:"i7k",nombre:"Tinta UV · Negro",unidad:"ml",costo:1.6,existencia:0,minimo:0,canal:"k"},
  {id:"i7w",nombre:"Tinta UV · Blanco",unidad:"ml",costo:1.8,existencia:0,minimo:0,canal:"w"},
  {id:"i7v",nombre:"Barniz UV",unidad:"ml",costo:1.4,existencia:0,minimo:0,canal:"v"},
  /* Gran formato: eco-solvente, cuatro canales, y es la tinta más barata
     por mililitro de todas. */
  {id:"i8c",nombre:"Tinta eco-solvente · Cian",unidad:"ml",costo:0.28,existencia:0,minimo:0,canal:"c"},
  {id:"i8m",nombre:"Tinta eco-solvente · Magenta",unidad:"ml",costo:0.28,existencia:0,minimo:0,canal:"m"},
  {id:"i8y",nombre:"Tinta eco-solvente · Amarillo",unidad:"ml",costo:0.28,existencia:0,minimo:0,canal:"y"},
  {id:"i8k",nombre:"Tinta eco-solvente · Negro",unidad:"ml",costo:0.28,existencia:0,minimo:0,canal:"k"},
  /* DTG: no hay rollo que comprar, así que su tinta se amarra a la
     técnica y no a un servicio. */
  {id:"i9c",nombre:"Tinta DTG · Cian",unidad:"ml",costo:1.9,existencia:0,minimo:0,canal:"c"},
  {id:"i9m",nombre:"Tinta DTG · Magenta",unidad:"ml",costo:1.9,existencia:0,minimo:0,canal:"m"},
  {id:"i9y",nombre:"Tinta DTG · Amarillo",unidad:"ml",costo:1.9,existencia:0,minimo:0,canal:"y"},
  {id:"i9k",nombre:"Tinta DTG · Negro",unidad:"ml",costo:1.9,existencia:0,minimo:0,canal:"k"},
  {id:"i9w",nombre:"Tinta DTG · Blanco",unidad:"ml",costo:2.1,existencia:0,minimo:0,canal:"w"},
  {id:"i9p",nombre:"Pretratamiento DTG",unidad:"ml",costo:0.35,existencia:0,minimo:0}
 ],""",
    "los canales de sublimación, UV, gran formato y DTG")

# ------------------------------------------------------ 2. los amarres nuevos
uno(
"""  {id:"c2",ancla:"servicio",anclaId:"sv1",insumoId:"i2",cant:100,por:"m2"}
 ],""",
"""  {id:"c2",ancla:"servicio",anclaId:"sv1",insumoId:"i2",cant:100,por:"m2"},
  /* Sublimación: unos 17 ml por m² impreso. Se amarra al papel, que es
     el servicio por el que pasa el metro cuadrado. */
  {id:"c5c",ancla:"servicio",anclaId:"sv4",insumoId:"i5c",cant:4,por:"m2"},
  {id:"c5m",ancla:"servicio",anclaId:"sv4",insumoId:"i5m",cant:4,por:"m2"},
  {id:"c5y",ancla:"servicio",anclaId:"sv4",insumoId:"i5y",cant:4,por:"m2"},
  {id:"c5k",ancla:"servicio",anclaId:"sv4",insumoId:"i5k",cant:5,por:"m2"},
  {id:"c6",ancla:"tecnica",anclaId:"t3",insumoId:"i6",cant:0.3,por:"pieza"},
  /* DTF UV: 33 ml de color, 30 de blanco y 35 de barniz por m². El
     barniz y el blanco se llevan dos terceras partes del gasto. */
  {id:"c7c",ancla:"servicio",anclaId:"sv3",insumoId:"i7c",cant:8,por:"m2"},
  {id:"c7m",ancla:"servicio",anclaId:"sv3",insumoId:"i7m",cant:8,por:"m2"},
  {id:"c7y",ancla:"servicio",anclaId:"sv3",insumoId:"i7y",cant:8,por:"m2"},
  {id:"c7k",ancla:"servicio",anclaId:"sv3",insumoId:"i7k",cant:9,por:"m2"},
  {id:"c7w",ancla:"servicio",anclaId:"sv3",insumoId:"i7w",cant:30,por:"m2"},
  {id:"c7v",ancla:"servicio",anclaId:"sv3",insumoId:"i7v",cant:35,por:"m2"},
  /* Gran formato: 13 ml por m², y va en los dos materiales porque la
     misma máquina imprime la lona y el vinil. */
  {id:"c8cl",ancla:"servicio",anclaId:"sv6",insumoId:"i8c",cant:3,por:"m2"},
  {id:"c8ml",ancla:"servicio",anclaId:"sv6",insumoId:"i8m",cant:3,por:"m2"},
  {id:"c8yl",ancla:"servicio",anclaId:"sv6",insumoId:"i8y",cant:3,por:"m2"},
  {id:"c8kl",ancla:"servicio",anclaId:"sv6",insumoId:"i8k",cant:4,por:"m2"},
  {id:"c8cv",ancla:"servicio",anclaId:"sv7",insumoId:"i8c",cant:3,por:"m2"},
  {id:"c8mv",ancla:"servicio",anclaId:"sv7",insumoId:"i8m",cant:3,por:"m2"},
  {id:"c8yv",ancla:"servicio",anclaId:"sv7",insumoId:"i8y",cant:3,por:"m2"},
  {id:"c8kv",ancla:"servicio",anclaId:"sv7",insumoId:"i8k",cant:4,por:"m2"},
  /* DTG: 25 ml de color, 35 de blanco y 40 de pretratamiento por m² de
     la aplicación, no del rollo: aquí no hay rollo. */
  {id:"c9c",ancla:"tecnica",anclaId:"t8",insumoId:"i9c",cant:6,por:"m2"},
  {id:"c9m",ancla:"tecnica",anclaId:"t8",insumoId:"i9m",cant:6,por:"m2"},
  {id:"c9y",ancla:"tecnica",anclaId:"t8",insumoId:"i9y",cant:6,por:"m2"},
  {id:"c9k",ancla:"tecnica",anclaId:"t8",insumoId:"i9k",cant:7,por:"m2"},
  {id:"c9w",ancla:"tecnica",anclaId:"t8",insumoId:"i9w",cant:35,por:"m2"},
  {id:"c9p",ancla:"tecnica",anclaId:"t8",insumoId:"i9p",cant:40,por:"m2"}
 ],""",
    "los amarres de las cuatro técnicas")

# ------------------------------------- 3. los oficios cargan sus consumibles
uno(
"""   tecnicas:["t3"], servicios:["sv4"], insumos:[], familias:["Tazas","Termos","Oficina","Promocional","Textil"]},""",
"""   tecnicas:["t3"], servicios:["sv4"], insumos:["i5c","i5m","i5y","i5k","i6"],
   familias:["Tazas","Termos","Oficina","Promocional","Textil"]},""",
    "sublimación carga sus cuatro canales")

uno(
"""   tecnicas:["t2"], servicios:["sv3"], insumos:[], familias:["Termos","Promocional"]},""",
"""   tecnicas:["t2"], servicios:["sv3"], insumos:["i7c","i7m","i7y","i7k","i7w","i7v"],
   familias:["Termos","Promocional"]},""",
    "DTF UV carga sus cinco canales y el barniz")

uno(
"""   tecnicas:["t8"], servicios:[], insumos:["i1"], familias:["Textil"]},""",
"""   tecnicas:["t8"], servicios:[], insumos:["i9c","i9m","i9y","i9k","i9w","i9p"],
   familias:["Textil"]},""",
    "DTG ya no apunta a un insumo que no existe")

uno(
"""   tecnicas:[], servicios:["sv6","sv7"], insumos:[], familias:[]},""",
"""   tecnicas:[], servicios:["sv6","sv7"], insumos:["i8c","i8m","i8y","i8k"], familias:[]},""",
    "gran formato carga su eco-solvente")

# --------------------------- 4. el rinde tambien cuenta lo que va por pieza
uno(
"""function rindeIns(i){
  if(!i) return "";
  const cs = (cat.consumos||[]).filter(c=>c.insumoId === i.id && c.por === "m2" && num(c.cant) > 0);
  if(!cs.length) return '<span class="hint" style="color:var(--ink-3)">sin amarre</span>';
  const porM2 = cs.reduce((s,c)=>s+num(c.cant), 0);
  const m2 = num(i.existencia) / porM2;
  return '<span class="insM2">'+ (Math.round(m2*10)/10).toLocaleString("es-MX") +' m²</span>' +
         '<small>'+ (Math.round(porM2*10)/10) +' '+ abrevIns(i.unidad) +' el m²</small>';
}""",
"""function rindeIns(i){
  if(!i) return "";
  /* Lo que va por metro cuadrado rinde metros cuadrados; lo que va por
     pieza rinde piezas. La cinta térmica y las bolsas se cuentan así. */
  const mide = (por, cuanto) => {
    const cs = (cat.consumos||[]).filter(c=>c.insumoId === i.id && c.por === por && num(c.cant) > 0);
    if(!cs.length) return null;
    const cada = cs.reduce((s,c)=>s+num(c.cant), 0);
    const rinde = num(i.existencia) / cada;
    return '<span class="insM2">'+ (Math.round(rinde*10)/10).toLocaleString("es-MX") +' '+ cuanto +'</span>' +
           '<small>'+ (Math.round(cada*1000)/1000) +' '+ abrevIns(i.unidad) +' '+
           (por === "m2" ? "el m²" : "la pieza") +'</small>';
  };
  return mide("m2", "m²") || mide("pieza", "pzas") ||
    '<span class="hint" style="color:var(--ink-3)">sin amarre</span>';
}""",
    "el rinde cuenta piezas cuando no hay metros")

io.open(RUTA, "w", encoding="utf-8").write(s)
print("Listo. %d cambios:" % len(hechos))
for h in hechos:
    print("  · " + h)
