# -*- coding: utf-8 -*-
"""Cotizaciones con azulejos y fichas limpias."""
import pathlib, sys
sys.path.insert(0, '/home/claude/trabajo/piezas')
import cotizaciones, secciones

RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

# 1. estilos
uno("""/* ---- lanzador dentro de una sección ---- */""",
    cotizaciones.CSS + """
/* ---- lanzador dentro de una sección ---- */""", "estilos de las fichas")

# 2. la sección
uno("""<section id="tab-sav" hidden>
  <div class="card" style="margin-top:20px">
    <header><h2>Cotizaciones y pedidos</h2><span class="hint" id="savCount" style="margin-left:auto"></span><button class="btn sm" data-reporte="cotizaciones">Reporte Excel</button></header>
    <div class="body"><div class="saved" id="savedList"></div></div>
  </div>
</section>""",
    """<section id="tab-sav" hidden>
  """ + secciones.barra("sav", "Cotizaciones") + """
  """ + secciones.lanzador("sav") + """
  <div class="card secOculta" data-sav="lista" style="margin-top:20px">
    <header><h2 id="savTitulo">Cotizaciones y pedidos</h2><span class="hint" id="savCount" style="margin-left:auto"></span><button class="btn sm" data-reporte="cotizaciones">Reporte Excel</button></header>
    <div class="body"><div class="saved" id="savedList"></div></div>
  </div>
</section>""",
    "la sección de cotizaciones")

# 3. el render nuevo reemplaza al viejo
viejo_render = src[src.index("function renderSaved(){"):src.index("/* ---------- ajustes ---------- */")]
src = src.replace(viejo_render, cotizaciones.JS + "\n", 1); hechos.append("el render de cotizaciones")

# 4. los azulejos
uno("""/* Los azulejos del Catálogo.""",
    """/* Los azulejos de Cotizaciones. Aquí no esconden tarjetas distintas: todas
   abren la MISMA lista, filtrada. Por eso cada una fija el filtro al abrirse. */
registraLanzador("sav", [
  {id:"todas", nombre:"Todas", sub:"lo que has guardado", color:"#64748B",
   icono:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/>',
   card:'[data-sav="lista"]', cuenta:()=>savCuenta("todas"),
   alAbrir:()=>{ savFiltro="todas"; renderSaved(); }},
  {id:"cot", nombre:"Cotizaciones", sub:"todavía sin confirmar", color:"#0680AB",
   icono:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/>',
   card:'[data-sav="lista"]', cuenta:()=>savCuenta("cot"),
   alAbrir:()=>{ savFiltro="cot"; renderSaved(); }},
  {id:"ped", nombre:"Pedidos", sub:"ya confirmados", color:"#D6127F",
   icono:'<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5Z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
   card:'[data-sav="lista"]', cuenta:()=>savCuenta("ped"),
   alAbrir:()=>{ savFiltro="ped"; renderSaved(); }},
  {id:"fac", nombre:"Facturas", sub:"emitidas y por emitir", color:"#B26A00",
   icono:'<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2Z"/><path d="M9 8h6M9 12h6"/>',
   card:'[data-sav="lista"]', cuenta:()=>savCuenta("fac"),
   alAbrir:()=>{ savFiltro="fac"; renderSaved(); }},
  {id:"cxc", nombre:"Por cobrar", sub:"vendido sin factura", color:"#0E7C57",
   icono:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 12h.01M18 12h.01"/>',
   card:'[data-sav="lista"]', cuenta:()=>savCuenta("cxc"),
   alAbrir:()=>{ savFiltro="cxc"; renderSaved(); }}
], "Cotizaciones");

/* Los azulejos del Catálogo.""",
    "los azulejos de cotizaciones")

# 5. al entrar se ven los azulejos
uno("""  if(b.dataset.tab==="cat"){ renderCatalogo(); reiniciaSec("cat"); }""",
    """  if(b.dataset.tab==="cat"){ renderCatalogo(); reiniciaSec("cat"); }
  if(b.dataset.tab==="sav"){ renderSaved(); reiniciaSec("sav"); }""",
    "al entrar a cotizaciones")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
