# -*- coding: utf-8 -*-
"""Consumibles, parte 2: el descuento en los DOS caminos de confirmacion.

   Si solo se pusiera en uno, la mitad de los pedidos gastaria material sin
   descontarlo, y un inventario que se ve bien estando mal es peor que no
   tener inventario."""
import pathlib
RUTA = pathlib.Path('/home/claude/trabajo/cotizador.html')
src = RUTA.read_text(encoding='utf-8')
hechos = []
def uno(viejo, nuevo, etiqueta):
    global src
    n = src.count(viejo)
    if n != 1: raise SystemExit("ALTO en «%s»: aparece %d veces." % (etiqueta, n))
    src = src.replace(viejo, nuevo, 1); hechos.append(etiqueta)

uno("""  for(const p of calcDe(cot).partes){
    const art = cat.articulos.find(a=>a.id===p.q.articuloId);
    if(art && num(art.existencia) > 0)
      await moverInventario(art.id, "salida", p.r.qty, "Salida por pedido confirmado", true,
                            {folio: cot.op.folio, archivo: null});
  }""",
    """  const rC = calcDe(cot);
  for(const p of rC.partes){
    const art = cat.articulos.find(a=>a.id===p.q.articuloId);
    if(art && num(art.existencia) > 0)
      await moverInventario(art.id, "salida", p.r.qty, "Salida por pedido confirmado", true,
                            {folio: cot.op.folio, archivo: null});
  }
  const cons = descuentaInsumos(cot, rC, cot.op.folio);
  if(cons.lista.length) renderInvInsumos();""",
    "descontar al confirmar")

uno("""  toast("Pedido confirmado · orden "+cot.op.folio+(art && num(art.existencia)<0 ? " · ojo: existencia en negativo" : ""));""",
    """  toast("Pedido confirmado · orden "+cot.op.folio +
    (art && num(art.existencia)<0 ? " · ojo: existencia en negativo" : "") +
    (cons.cortos.length ? " · sin material: " + cons.cortos.join(", ") : ""));""",
    "el aviso dice qué consumible quedó corto")

uno("""  for(const p of calcDe(g).partes){
    const a = (cat.articulos||[]).find(a=>a.id===p.q.articuloId);
    if(a && num(a.existencia) > 0)
      await moverInventario(a.id, "salida", p.r.qty, "Salida por pedido cobrado", true,
                            {folio: g.op.folio, archivo: null});
  }""",
    """  const rG = calcDe(g);
  for(const p of rG.partes){
    const a = (cat.articulos||[]).find(a=>a.id===p.q.articuloId);
    if(a && num(a.existencia) > 0)
      await moverInventario(a.id, "salida", p.r.qty, "Salida por pedido cobrado", true,
                            {folio: g.op.folio, archivo: null});
  }
  descuentaInsumos(g, rG, g.op.folio);
  renderInvInsumos();""",
    "descontar al enviar a producción")

RUTA.write_text(src, encoding='utf-8')
print("Listo. %d cambios:" % len(hechos))
for h in hechos: print("  ·", h)
